import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:voisa/features/auth/presentation/screens/login_screen.dart';
import 'package:voisa/features/auth/presentation/screens/verification_screen.dart';
import 'package:voisa/features/home/data/shake_detector_service.dart';
import 'package:voisa/main.dart';
import 'package:voisa/navigation/main_shell.dart';

void main() {
  testWidgets('App builds successfully', (WidgetTester tester) async {
    await tester.pumpWidget(const VoisaApp());
    await tester.pump(const Duration(seconds: 2));
    await tester.pump();

    expect(find.byType(VoisaApp), findsOneWidget);
  });

  test('shake sensitivity maps higher sensitivity to a lower threshold', () {
    expect(ShakeDetectorService.thresholdForSensitivity(0), 20);
    expect(ShakeDetectorService.thresholdForSensitivity(0.5), 15);
    expect(ShakeDetectorService.thresholdForSensitivity(1), 10);
    expect(ShakeDetectorService.thresholdForSensitivity(-1), 20);
    expect(ShakeDetectorService.thresholdForSensitivity(2), 10);
  });

  testWidgets('auth fields keep the keyboard open when focus changes',
      (WidgetTester tester) async {
    await tester.pumpWidget(MaterialApp(
      home: LoginScreen(onLoginOverride: (_, __) async {}),
    ));

    await tester.tap(find.byKey(const ValueKey('auth-field-Email address')));
    await tester.pump();

    expect(tester.testTextInput.isVisible, isTrue);
    tester.testTextInput.enterText('me@example.com');
    await tester.pump();
    expect(
      find.descendant(
        of: find.byKey(const ValueKey('auth-field-Email address')),
        matching: find.text('me@example.com'),
      ),
      findsOneWidget,
    );

    tester.testTextInput.log.clear();

    await tester.tap(find.byKey(const ValueKey('auth-field-Password')));
    await tester.pump();

    final methods = tester.testTextInput.log.map((call) => call.method);
    expect(methods, isNot(contains('TextInput.clearClient')));
    expect(methods, isNot(contains('TextInput.hide')));
    expect(tester.testTextInput.isVisible, isTrue);

    tester.testTextInput.enterText('secret1');
    await tester.pump();

    await tester.tap(find.text('Sign In'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 100));

    expect(find.byType(MainShell), findsOneWidget);
  });

  testWidgets('verification fields keep the keyboard open when focus changes',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MaterialApp(home: VerificationScreen()));

    await tester.tap(find.byKey(const ValueKey('otp-box-0')));
    await tester.pump();

    expect(tester.testTextInput.isVisible, isTrue);
    tester.testTextInput.enterText('123456');
    await tester.pump();
    expect(find.text('1'), findsOneWidget);
    expect(find.text('6'), findsOneWidget);

    tester.testTextInput.log.clear();

    await tester.tap(find.byKey(const ValueKey('otp-box-1')));
    await tester.pump();

    final methods = tester.testTextInput.log.map((call) => call.method);
    expect(methods, isNot(contains('TextInput.clearClient')));
    expect(methods, isNot(contains('TextInput.hide')));
    expect(tester.testTextInput.isVisible, isTrue);
  });
}
