import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/theme/app_theme.dart';
import '../core/constants/app_constants.dart';
import '../features/home/data/shake_detector_service.dart';
import '../features/home/presentation/screens/home_screen.dart';
import '../features/notifications/presentation/screens/notifications_screen.dart';
import '../features/contacts/presentation/screens/contacts_screen.dart';
import '../features/settings/presentation/screens/settings_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  static const _shakeDetectionEnabledKey = 'shake_detection_enabled';
  static const _shakeSensitivityKey = 'shake_sensitivity';

  int _currentIndex = 0;
  bool _shakeDetectionEnabled = true;
  double _shakeSensitivity = ShakeDetectorService.defaultShakeSensitivity;

  @override
  void initState() {
    super.initState();
    _loadShakeSettings();
  }

  Future<void> _loadShakeSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final sensitivity = prefs.getDouble(_shakeSensitivityKey) ??
        ShakeDetectorService.defaultShakeSensitivity;

    if (!mounted) return;
    setState(() {
      _shakeDetectionEnabled = prefs.getBool(_shakeDetectionEnabledKey) ?? true;
      _shakeSensitivity = sensitivity
          .clamp(
            ShakeDetectorService.minShakeSensitivity,
            ShakeDetectorService.maxShakeSensitivity,
          )
          .toDouble();
    });
  }

  Future<void> _setShakeDetectionEnabled(bool value) async {
    setState(() => _shakeDetectionEnabled = value);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_shakeDetectionEnabledKey, value);
  }

  Future<void> _setShakeSensitivity(double value) async {
    final sensitivity = value
        .clamp(
          ShakeDetectorService.minShakeSensitivity,
          ShakeDetectorService.maxShakeSensitivity,
        )
        .toDouble();

    setState(() => _shakeSensitivity = sensitivity);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_shakeSensitivityKey, sensitivity);
  }

  @override
  Widget build(BuildContext context) {
    // Keep pages alive when switching tabs (IndexedStack pattern).
    final pages = [
      HomeScreen(
        shakeDetectionEnabled: _shakeDetectionEnabled,
        shakeSensitivity: _shakeSensitivity,
      ),
      const NotificationsScreen(),
      const ContactsScreen(),
      SettingsScreen(
        shakeDetectionEnabled: _shakeDetectionEnabled,
        shakeSensitivity: _shakeSensitivity,
        onShakeDetectionChanged: _setShakeDetectionEnabled,
        onShakeSensitivityChanged: _setShakeSensitivity,
      ),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: pages,
      ),
      bottomNavigationBar: _VoisaBottomNav(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
      ),
    );
  }
}

// ─── Bottom Navigation Bar ────────────────────────────────────────────────────

class _VoisaBottomNav extends StatelessWidget {
  const _VoisaBottomNav({
    required this.currentIndex,
    required this.onTap,
  });

  final int currentIndex;
  final ValueChanged<int> onTap;

  static const _items = [
    _NavItem(label: 'Home', icon: Icons.home_rounded),
    _NavItem(label: 'Notifications', icon: Icons.notifications_rounded),
    _NavItem(label: 'Contacts', icon: Icons.group_rounded),
    _NavItem(label: 'Settings', icon: Icons.menu_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.background,
        border: Border(
          top: BorderSide(color: AppColors.divider, width: 0.8),
        ),
      ),
      padding: EdgeInsets.only(
        top: AppSpacing.sm + 2,
        bottom: bottomPadding > 0 ? bottomPadding : AppSpacing.sm + 2,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(_items.length, (i) {
          return _NavItemWidget(
            item: _items[i],
            isActive: currentIndex == i,
            onTap: () => onTap(i),
          );
        }),
      ),
    );
  }
}

class _NavItem {
  const _NavItem({required this.label, required this.icon});
  final String label;
  final IconData icon;
}

class _NavItemWidget extends StatelessWidget {
  const _NavItemWidget({
    required this.item,
    required this.isActive,
    required this.onTap,
  });

  final _NavItem item;
  final bool isActive;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: item.label,
      button: true,
      selected: isActive,
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: SizedBox(
          width: 68,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedContainer(
                duration: AppDurations.normal,
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: isActive ? AppColors.navActive : AppColors.navIconBg,
                  borderRadius: BorderRadius.circular(AppRadius.sm),
                ),
                child: Icon(
                  item.icon,
                  color: Colors.white,
                  size: 22,
                ),
              ),
              const SizedBox(height: 4),
              AnimatedDefaultTextStyle(
                duration: AppDurations.normal,
                style: AppTextStyles.navLabel.copyWith(
                  color: isActive ? AppColors.navActive : AppColors.navInactive,
                  fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
                ),
                child: Text(item.label, maxLines: 1),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
