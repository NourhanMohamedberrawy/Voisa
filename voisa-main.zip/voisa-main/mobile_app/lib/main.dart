import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core/theme/app_theme.dart';
import 'core/utils/app_error_handler.dart';
import 'core/services/connectivity_service.dart';
import 'core/utils/app_logger.dart';
import 'features/onboarding/presentation/screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ── Error boundary ─────────────────────────────────────────────────────────
  AppErrorHandler.init();

  // ── Connectivity ───────────────────────────────────────────────────────────
  await ConnectivityService.instance.init();

  // ── Orientation lock ───────────────────────────────────────────────────────
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // ── Status bar ─────────────────────────────────────────────────────────────
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));

  AppLogger.info('App starting', context: 'main');

  runApp(const VoisaApp());
}

class VoisaApp extends StatelessWidget {
  const VoisaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Voisa',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: const SplashScreen(),
    );
  }
}
