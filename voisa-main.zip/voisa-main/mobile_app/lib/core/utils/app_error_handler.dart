import 'app_logger.dart';
import 'package:flutter/foundation.dart';

// ─── App Error Handler ────────────────────────────────────────────────────────
// Catches all unhandled Flutter framework errors and Dart async errors.
// Wire this in main() before runApp().
//
// TODO: when integrating crash reporting (Crashlytics / Sentry),
// add the real reporting calls inside each handler below.

class AppErrorHandler {
  AppErrorHandler._();

  static void init() {
    // Catches errors thrown inside the Flutter widget tree
    FlutterError.onError = (FlutterErrorDetails details) {
      AppLogger.error(
        'Uncaught Flutter error: ${details.exceptionAsString()}',
        context: 'FlutterError',
        error: details.exception,
        stackTrace: details.stack,
      );
      // In release, prevent the red screen of death from showing
      // FlutterError.presentError(details); // uncomment to keep default behavior in debug
    };

    // Catches errors thrown in async code outside the widget tree
    // (e.g. in isolates, platform channels, Futures without try-catch)
    PlatformDispatcher.instance.onError = (error, stack) {
      AppLogger.error(
        'Uncaught platform error',
        context: 'PlatformDispatcher',
        error: error,
        stackTrace: stack,
      );
      return true; // returning true marks the error as handled
    };
  }
}
