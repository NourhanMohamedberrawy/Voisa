// ─── App Logger ───────────────────────────────────────────────────────────────
// Observability hook. Swap the body of each method to integrate a real
// service: Firebase Crashlytics, Sentry, Datadog, etc.
//
// Usage:
//   AppLogger.info('SOS triggered', context: 'SosSection');
//   AppLogger.error('Poll failed', error: e, stackTrace: st);
//   AppLogger.event('distress_detected');

import 'package:flutter/foundation.dart';

enum _LogLevel { debug, info, warning, error }

class AppLogger {
  AppLogger._();

  // ── Public API ───────────────────────────────────────────────────────────────

  static void debug(String message, {String? context}) =>
      _log(_LogLevel.debug, message, context: context);

  static void info(String message, {String? context}) =>
      _log(_LogLevel.info, message, context: context);

  static void warning(String message, {String? context}) =>
      _log(_LogLevel.warning, message, context: context);

  static void error(
    String message, {
    String? context,
    Object? error,
    StackTrace? stackTrace,
  }) {
    _log(_LogLevel.error, message, context: context);

    // TODO: replace with real crash reporting, e.g.:
    // FirebaseCrashlytics.instance.recordError(error, stackTrace);
    if (error != null && kDebugMode) {
      debugPrint('  ↳ error: $error');
    }
    if (stackTrace != null && kDebugMode) {
      debugPrint('  ↳ stack: $stackTrace');
    }
  }

  /// Track a named analytics event with optional properties.
  /// TODO: replace body with real analytics, e.g.:
  /// FirebaseAnalytics.instance.logEvent(name: name, parameters: properties);
  static void event(String name, {Map<String, Object>? properties}) {
    if (kDebugMode) {
      final props = properties != null ? ' $properties' : '';
      debugPrint('[EVENT] $name$props');
    }
  }

  // ── Internal ─────────────────────────────────────────────────────────────────

  static void _log(_LogLevel level, String message, {String? context}) {
    if (!kDebugMode) return; // silence in release; real service handles it

    final prefix = switch (level) {
      _LogLevel.debug => '🔍 DEBUG',
      _LogLevel.info => 'ℹ️  INFO ',
      _LogLevel.warning => '⚠️  WARN ',
      _LogLevel.error => '🔴 ERROR',
    };
    final ctx = context != null ? ' [$context]' : '';
    debugPrint('$prefix$ctx: $message');
  }
}
