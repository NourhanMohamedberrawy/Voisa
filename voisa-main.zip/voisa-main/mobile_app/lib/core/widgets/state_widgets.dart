import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../constants/app_constants.dart';
import '../constants/app_strings.dart';
import '../state/ui_state.dart';

// ─── StateBuilder ─────────────────────────────────────────────────────────────
/// Drop-in widget that renders the correct UI for each UiState variant.
///
/// Usage:
///   StateBuilder<List<Contact>>(
///     state: _state,
///     onData: (contacts) => ContactList(contacts: contacts),
///   )
class StateBuilder<T> extends StatelessWidget {
  const StateBuilder({
    super.key,
    required this.state,
    required this.onData,
    this.onLoading,
    this.onEmpty,
    this.onError,
    this.onOffline,
  });

  final UiState<T> state;
  final Widget Function(T data) onData;
  final Widget Function()? onLoading;
  final Widget Function()? onEmpty;
  final Widget Function(String message, VoidCallback? onRetry)? onError;
  final Widget Function(VoidCallback? onRetry)? onOffline;

  @override
  Widget build(BuildContext context) {
    return switch (state) {
      UiStateLoading() => onLoading?.call() ?? const VoisaLoadingView(),
      UiStateData(:final data) => onData(data),
      UiStateEmpty(:final message) =>
        onEmpty?.call() ?? VoisaEmptyView(message: message),
      UiStateError(:final message, :final onRetry) =>
        onError?.call(message, onRetry) ??
            VoisaErrorView(message: message, onRetry: onRetry),
      UiStateOffline(:final onRetry) =>
        onOffline?.call(onRetry) ?? VoisaOfflineView(onRetry: onRetry),
    };
  }
}

// ─── Loading view ─────────────────────────────────────────────────────────────
class VoisaLoadingView extends StatelessWidget {
  const VoisaLoadingView({super.key, this.message});
  final String? message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(
            color: AppColors.primary,
            strokeWidth: 2.5,
          ),
          if (message != null) ...[
            const SizedBox(height: AppSpacing.md),
            Text(
              message!,
              style: AppTextStyles.caption,
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
}

// ─── Empty view ───────────────────────────────────────────────────────────────
class VoisaEmptyView extends StatelessWidget {
  const VoisaEmptyView({
    super.key,
    this.message,
    this.icon,
  });
  final String? message;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon ?? Icons.inbox_rounded,
              size: 52,
              color: AppColors.textSecondary.withValues(alpha: 0.4),
            ),
            const SizedBox(height: AppSpacing.md),
            Text(
              message ?? AppStrings.stateEmptyDefault,
              style: AppTextStyles.cardSubtitle,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Error view ───────────────────────────────────────────────────────────────
class VoisaErrorView extends StatelessWidget {
  const VoisaErrorView({
    super.key,
    this.message,
    this.onRetry,
  });
  final String? message;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.error_outline_rounded,
              size: 52,
              color: AppColors.textSecondary.withValues(alpha: 0.4),
            ),
            const SizedBox(height: AppSpacing.md),
            Text(
              message ?? AppStrings.stateErrorDefault,
              style: AppTextStyles.cardSubtitle,
              textAlign: TextAlign.center,
            ),
            if (onRetry != null) ...[
              const SizedBox(height: AppSpacing.lg),
              Semantics(
                label: AppStrings.stateErrorRetry,
                button: true,
                child: OutlinedButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh_rounded, size: 18),
                  label: const Text(AppStrings.stateErrorRetry),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primary,
                    side: const BorderSide(color: AppColors.primary),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppRadius.pill),
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ─── Offline view ─────────────────────────────────────────────────────────────
class VoisaOfflineView extends StatelessWidget {
  const VoisaOfflineView({super.key, this.onRetry});
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.wifi_off_rounded,
              size: 52,
              color: AppColors.textSecondary.withValues(alpha: 0.4),
            ),
            const SizedBox(height: AppSpacing.md),
            Text(
              AppStrings.stateOfflineDefault,
              style: AppTextStyles.cardSubtitle,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(
              AppStrings.stateOfflineBody,
              style: AppTextStyles.caption,
              textAlign: TextAlign.center,
            ),
            if (onRetry != null) ...[
              const SizedBox(height: AppSpacing.lg),
              Semantics(
                label: AppStrings.offlineRetry,
                button: true,
                child: OutlinedButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh_rounded, size: 18),
                  label: const Text(AppStrings.offlineRetry),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primary,
                    side: const BorderSide(color: AppColors.primary),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppRadius.pill),
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ─── Offline Banner ───────────────────────────────────────────────────────────
/// A non-intrusive banner shown at the top of any screen while offline.
/// Especially important for the home screen given the emergency context.
///
/// Usage: wrap your screen body in a Stack and overlay this conditionally.
class OfflineBanner extends StatelessWidget {
  const OfflineBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: AppStrings.offlineBanner,
      liveRegion: true,
      child: Container(
        width: double.infinity,
        color: AppColors.textPrimary,
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.screenH,
          vertical: AppSpacing.sm,
        ),
        child: Row(
          children: [
            const Icon(Icons.wifi_off_rounded, size: 16, color: Colors.white),
            const SizedBox(width: AppSpacing.sm),
            Expanded(
              child: Text(
                AppStrings.offlineBanner,
                style: AppTextStyles.caption.copyWith(color: Colors.white),
              ),
            ),
            Text(
              AppStrings.offlineEmergencyNote,
              style: AppTextStyles.caption.copyWith(
                color: Colors.white.withValues(alpha: 0.7),
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
