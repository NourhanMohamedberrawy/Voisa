// ─── App Strings ──────────────────────────────────────────────────────────────
// All user-facing strings live here.
// When you add localization (flutter_localizations + ARB files),
// replace each static const with a lookup from AppLocalizations.
// Pattern: AppStrings.someKey → AppLocalizations.of(context).someKey

class AppStrings {
  AppStrings._();

  // ── App general ─────────────────────────────────────────────────────────────
  static const String appName = 'Voisa';
  static const String appTagline = 'Your safety, always on.';

  // ── Onboarding / Welcome ────────────────────────────────────────────────────
  static const String welcomeHeadline = 'Safety in\nyour pocket.';
  static const String welcomeBody =
      'Voisa detects distress, alerts your contacts, '
      'and shares your location — all automatically.';
  static const String welcomeGetStarted = 'Get Started';
  static const String welcomeHaveAccount = 'I already have an account';

  static const String featureAiDetection = 'AI distress\ndetection';
  static const String featureLocation = 'Live location\nshared instantly';
  static const String featureContacts = 'Trusted contacts\nalways notified';

  // ── Auth ─────────────────────────────────────────────────────────────────────
  static const String loginHeadline = 'Welcome\nback.';
  static const String loginSubtitle =
      'Sign in to keep your safety network active.';
  static const String loginButton = 'Sign In';
  static const String loginNoAccount = "Don't have an account? ";
  static const String loginSignUp = 'Sign up';
  static const String loginForgotPassword = 'Forgot password?';

  static const String signUpHeadline = 'Create your\naccount.';
  static const String signUpSubtitle = 'Set up Voisa so it can protect you.';
  static const String signUpButton = 'Create Account';
  static const String signUpHaveAccount = 'Already have an account? ';
  static const String signUpSignIn = 'Sign in';

  static const String fieldName = 'Full name';
  static const String fieldEmail = 'Email address';
  static const String fieldPassword = 'Password';
  static const String fieldPhone = 'Phone number';
  static const String fieldRelation = 'Relation (e.g. Sister, Friend)';

  static const String forgotHeadline = 'Forgot\npassword?';
  static const String forgotSubtitle =
      "Enter your email and we'll send you a reset link.";
  static const String forgotSendButton = 'Send Reset Link';
  static const String forgotConfirmTitle = 'Check your email';
  static const String forgotBackButton = 'Back to Sign In';

  static const String verifyHeadline = 'Verify\nyour email.';
  static const String verifySubtitle =
      'We sent a 6-digit code to your email address. Enter it below.';
  static const String verifyButton = 'Verify';
  static const String verifyResend = "Didn't receive it? ";
  static const String verifyResendAction = 'Resend code';
  static const String verifyResendConfirm = 'Code resent.';
  static const String verifySkip = 'Skip verification';

  // ── Validation errors ────────────────────────────────────────────────────────
  static const String errorFillAllFields = 'Please fill in all fields.';
  static const String errorInvalidEmail = 'Please enter a valid email.';
  static const String errorPasswordLength =
      'Password must be at least 8 characters.';
  static const String errorIncompleteCode =
      'Please enter the complete 6-digit code.';
  static const String errorValidEmail = 'Please enter a valid email address.';

  // ── Permissions ──────────────────────────────────────────────────────────────
  static const String permMicTitle = 'Microphone access';
  static const String permMicReason =
      'Voisa listens for distress words like "help" to automatically trigger '
      'an emergency alert — even when you can\'t reach your phone.';
  static const String permMicButton = 'Allow Microphone';

  static const String permLocationTitle = 'Location access';
  static const String permLocationReason =
      'Your real-time location is shared with emergency contacts the moment '
      'an alert is triggered, so help can reach you faster.';
  static const String permLocationButton = 'Allow Location';

  static const String permNotifTitle = 'Notifications';
  static const String permNotifReason =
      'Receive instant alerts when a contact activates SOS or when Voisa '
      'detects a distress situation nearby.';
  static const String permNotifButton = 'Allow Notifications';

  static const String permSkip = 'Skip for now';

  // ── Contacts setup ───────────────────────────────────────────────────────────
  static const String contactsSetupHeadline = 'Add emergency\ncontacts.';
  static const String contactsSetupSubtitle =
      'These people will be alerted with your location the moment '
      'Voisa detects an emergency.';
  static const String contactsSetupAddButton = 'Add a Contact';
  static const String contactsSetupContinue = 'Continue to Voisa';
  static const String contactsSetupRequireOne = 'Add at least one contact';
  static const String contactsSetupRequireOneHint =
      'At least one emergency contact is required for your safety.';
  static const String contactsSetupEmptyHint =
      'No contacts added yet. Add at least one trusted person to continue.';
  static const String contactsAddSheetTitle = 'Add contact';
  static const String contactsAddButton = 'Add Contact';

  // ── Home screen ──────────────────────────────────────────────────────────────
  static const String homeGreeting = 'Hello,';
  static const String homeActiveAlerts = 'Active Alerts';
  static const String homeQuickActions = 'Quick Actions';
  static const String homeSosDanger = 'Are you in danger?';
  static const String homeSosSubtitle = 'Alert all emergency contacts now';
  static const String homeSosTapTo = 'Tap to';
  static const String homeSosLabel = 'SOS';
  static const String homeSimulateDistress = 'Simulate distress detection';

  static const String alertActivatedSos = 'Activated the ';
  static const String alertSosWord = 'SOS';
  static const String alertSosEnd = ' button';
  static const String alertLocation = 'Location';
  static const String alertCall = 'Call Now';

  // ── SOS sheet ────────────────────────────────────────────────────────────────
  static const String sosCountdownPrefix =
      'Your emergency contacts will be alerted in ';
  static const String sosSecond = 'second';
  static const String sosSeconds = 'seconds';
  static const String sosCancel = 'Cancel';
  static const String sosSend = 'Send';
  static const String sosHelpOnWay = 'Help is on the way';
  static const String sosAreYouSure = 'Are you sure?';
  static const String sosYes = 'Yes';
  static const String sosNo = 'No';

  // ── Distress sheet ───────────────────────────────────────────────────────────
  static const String distressDetected = 'Distress detected';
  static const String distressCountdownPrefix = 'Automatic alert in ';
  static const String distressCountdownSuffix = ' seconds';
  static const String distressLocationNote =
      'Your location and recent audio snippet will be sent';
  static const String distressSendAlert = 'Send alert';
  static const String distressCancelAlert = 'Cancel alert?';
  static const String distressYesCancel = 'Yes, cancel';
  static const String distressNoSend = 'No, send alert';
  static const String distressSending = 'Sending alert...';
  static const String distressSendingSubtitle =
      'Sending location, audio, and notifying contacts';
  static const String distressNotified = 'Emergency contacts notified';
  static const String distressContactAlerted = '1 contact was alerted';
  // ignore: non_constant_identifier_names  (used as a function substitute)
  static String distressContactsAlerted(int n) => '$n contacts were alerted';
  static const String distressViewAlert = 'View alert';
  static const String distressMarkSafe = 'Mark as safe';

  // ── Notifications screen ─────────────────────────────────────────────────────
  static const String notificationsTitle = 'Notifications';
  static const String notificationsToday = 'Today';
  static const String notificationsSeeAll = 'See All';
  static const String notificationsHistory = 'Click to see history';
  static const String notificationsSeeMore = 'See More';
  static const String notificationsAskLocation = 'Ask to share location';

  // ── Contacts screen ──────────────────────────────────────────────────────────
  static const String contactsTitle = 'Contacts';
  static const String contactsLocation = 'Location';
  static const String contactsMessage = 'Message';
  static const String contactsCall = 'Call Now';
  static const String contactsAdd = 'Add Contacts';
  static const String contactsRemove = 'Remove Contacts';
  static const String contactsPriority = 'Set Priority';
  static const String contactsEmptyTitle = 'No emergency contacts yet';
  static const String contactsEmptySubtitle =
      'Add trusted contacts so they can be alerted\nduring an emergency.';
  static const String contactsSearchHint = 'Search name or phone number';

  // ── Settings screen ──────────────────────────────────────────────────────────
  static const String settingsTitle = 'Settings';
  static const String settingsProfile = 'Profile';
  static const String settingsNotifications = 'Notifications';
  static const String settingsLocation = 'Location & Privacy';
  static const String settingsVoiceClip = 'Voice Clip Settings';
  static const String settingsAiDetection = 'AI Distress Detection';
  static const String settingsAbout = 'About Voisa';

  // ── Connectivity ─────────────────────────────────────────────────────────────
  static const String offlineBanner = 'No internet connection';
  static const String offlineRetry = 'Retry';
  static const String offlineEmergencyNote =
      'Emergency alerts may not reach contacts while offline.';

  // ── Generic UI states ────────────────────────────────────────────────────────
  static const String stateLoading = 'Loading…';
  static const String stateEmptyDefault = 'Nothing here yet.';
  static const String stateErrorDefault = 'Something went wrong.';
  static const String stateErrorRetry = 'Try Again';
  static const String stateOfflineDefault = 'You\'re offline.';
  static const String stateOfflineBody = 'Check your connection and try again.';
}
