import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// ─── Brand Palette ────────────────────────────────────────────────────────────
class AppColors {
  AppColors._();

  // Primary
  static const Color primary = Color(0xFFD94F2B);
  static const Color primaryDark = Color(0xFFB83C1E);

  // Emergency
  static const Color emergency = Color(0xFFC0392B);
  static const Color emergencyLight = Color(0xFFE74C3C);
  static const Color emergencySurface = Color(0xFFB71C1C);

  /// Shared emergency gradient — used on all red background cards/sheets.
  static const LinearGradient emergencyGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFF921F16),
      Color(0xFFE43E34),
    ],
  );

  // SOS bottom sheet background (matches screenshot dark red)
  static const Color sosSheetBg = Color(0xFFC0392B);

  // Neutrals
  static const Color background = Color(0xFFFDFCFB);
  static const Color surface = Color(0xFFEFEDE8);
  static const Color surfaceDark = Color(0xFFE2DED6);

  // Text
  static const Color textPrimary = Color(0xFF1A1A1A);
  static const Color textSecondary = Color(0xFF6B6560);
  static const Color textOnEmergency = Color(0xFFFDFCFB);
  static const Color textOnPrimary = Color(0xFFFDFCFB);

  // Divider / Border
  static const Color divider = Color(0xFFD5D0C8);

  // Bottom nav
  static const Color navActive = Color(0xFFEB653C);
  static const Color navInactive = Color(0xFF8D877E);
  static const Color navIconBg = Color(0xFFB0A89A);

  // Error/Destructive
  static const Color error = Color(0xFFE74C3C);
}

// ─── Typography — Montserrat ──────────────────────────────────────────────────
// Styles are getters (not const) because GoogleFonts returns runtime objects.
// Callers use AppTextStyles.body, AppTextStyles.body.copyWith(...) etc.
class AppTextStyles {
  AppTextStyles._();

  static TextStyle get displayLarge => GoogleFonts.montserrat(
        fontSize: 32,
        fontWeight: FontWeight.w800,
        color: AppColors.textPrimary,
        letterSpacing: -0.5,
      );

  static TextStyle get sectionTitle => GoogleFonts.montserrat(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: AppColors.textPrimary,
        letterSpacing: -0.2,
      );

  static TextStyle get cardTitle => GoogleFonts.montserrat(
        fontSize: 18,
        fontWeight: FontWeight.w600,
        color: AppColors.textPrimary,
      );

  static TextStyle get cardSubtitle => GoogleFonts.montserrat(
        fontSize: 16,
        fontWeight: FontWeight.w500,
        color: AppColors.textSecondary,
      );

  static TextStyle get body => GoogleFonts.montserrat(
        fontSize: 15,
        fontWeight: FontWeight.w400,
        color: AppColors.textPrimary,
        height: 1.4,
      );

  static TextStyle get bodyBold => GoogleFonts.montserrat(
        fontSize: 15,
        fontWeight: FontWeight.w700,
        color: AppColors.textPrimary,
      );

  static TextStyle get caption => GoogleFonts.montserrat(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        color: AppColors.textSecondary,
      );

  static TextStyle get buttonLabel => GoogleFonts.montserrat(
        fontSize: 15,
        fontWeight: FontWeight.w600,
        letterSpacing: 0.1,
      );

  static TextStyle get navLabel => GoogleFonts.montserrat(
        fontSize: 10,
        fontWeight: FontWeight.w500,
      );

  // Emergency-specific (white text on red)
  static TextStyle get emergencyTitle => GoogleFonts.montserrat(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: AppColors.textOnEmergency,
      );

  static TextStyle get emergencySubtitle => GoogleFonts.montserrat(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: AppColors.textOnEmergency,
      );

  static TextStyle get emergencyRelation => GoogleFonts.montserrat(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: AppColors.textOnEmergency,
      );

  static TextStyle get emergencyBody => GoogleFonts.montserrat(
        fontSize: 16,
        fontWeight: FontWeight.w500,
        color: AppColors.textOnEmergency,
        height: 1.4,
      );

  // SOS sheet specific styles
  static TextStyle get sosHeading => GoogleFonts.montserrat(
        fontSize: 22,
        fontWeight: FontWeight.w700,
        color: Colors.white,
        height: 1.3,
      );

  static TextStyle get sosSubheading => GoogleFonts.montserrat(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        color: Colors.white70,
      );

  static TextStyle get sosButtonLabel => GoogleFonts.montserrat(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        letterSpacing: 0.2,
      );
}

// ─── Theme Data ───────────────────────────────────────────────────────────────
class AppTheme {
  AppTheme._();

  static ThemeData get light {
    final base = ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.background,
      colorScheme: const ColorScheme.light(
        primary: AppColors.primary,
        surface: AppColors.surface,
        onPrimary: AppColors.textOnPrimary,
        onSurface: AppColors.textPrimary,
      ),
    );

    return base.copyWith(
      // Apply Montserrat to the entire Material text theme
      textTheme: GoogleFonts.montserratTextTheme(base.textTheme),
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.background,
        elevation: 0,
        scrolledUnderElevation: 0,
        titleTextStyle: AppTextStyles.sectionTitle,
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
      ),
      cardTheme: CardThemeData(
        color: AppColors.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(32),
        ),
        margin: EdgeInsets.zero,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: AppColors.textOnPrimary,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(32),
          ),
          textStyle: AppTextStyles.buttonLabel,
        ),
      ),
    );
  }
}
