import 'package:flutter/foundation.dart';
// ─── UI State Sealed Class ────────────────────────────────────────────────────
// Use this for any screen or section that loads async data.
//
// Example:
//   UiState<List<Contact>> _state = const UiStateLoading();
//
//   switch (_state) {
//     case UiStateLoading():  show spinner
//     case UiStateData(:final data): show list
//     case UiStateEmpty():  show empty view
//     case UiStateError(:final message): show error
//     case UiStateOffline(): show offline view
//   }

sealed class UiState<T> {
  const UiState();
}

final class UiStateLoading<T> extends UiState<T> {
  const UiStateLoading();
}

final class UiStateData<T> extends UiState<T> {
  const UiStateData(this.data);
  final T data;
}

final class UiStateEmpty<T> extends UiState<T> {
  const UiStateEmpty({this.message});
  final String? message;
}

final class UiStateError<T> extends UiState<T> {
  const UiStateError({required this.message, this.onRetry});
  final String message;
  final VoidCallback? onRetry;
}

final class UiStateOffline<T> extends UiState<T> {
  const UiStateOffline({this.onRetry});
  final VoidCallback? onRetry;
}
