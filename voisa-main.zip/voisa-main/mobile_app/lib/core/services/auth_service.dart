import 'package:shared_preferences/shared_preferences.dart';

import 'api_client.dart';
import 'api_endpoints.dart';

export 'api_client.dart' show ApiException;

class VerificationRequiredException extends ApiException {
  const VerificationRequiredException(super.message, this.email);

  final String email;
}

class AuthSession {
  const AuthSession({
    required this.token,
    required this.userId,
    required this.name,
    required this.email,
    required this.isEmailVerified,
  });

  final String token;
  final String userId;
  final String name;
  final String email;
  final bool isEmailVerified;
}

class AuthService {
  AuthService._();

  static final instance = AuthService._();

  static const _tokenKey = 'auth_token';
  static const _userIdKey = 'auth_user_id';
  static const _nameKey = 'auth_name';
  static const _emailKey = 'auth_email';

  late final ApiClient _api = ApiClient(tokenProvider: getToken);

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }

  Future<String?> getEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_emailKey);
  }

  Future<String?> getName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_nameKey);
  }

  Future<AuthSession> login({
    required String email,
    required String password,
  }) {
    return _authenticate(
      ApiEndpoints.authLogin,
      {'email': email, 'password': password},
    );
  }

  Future<void> register({
    required String name,
    required String email,
    required String password,
  }) async {
    await _api.post(
      ApiEndpoints.authRegister,
      body: {'name': name, 'email': email, 'password': password},
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_emailKey, email);
  }

  Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_userIdKey);
    await prefs.remove(_nameKey);
    await prefs.remove(_emailKey);
  }

  Future<void> deleteAccount() async {
    await _api.delete(ApiEndpoints.usersMe, authenticated: true);

    await clearSession();
  }

  Future<AuthSession> verifyEmail({
    required String email,
    required String code,
  }) async {
    final payload = await _api.post(
      ApiEndpoints.authVerifyEmail,
      body: {'email': email, 'code': code},
    );

    return _sessionFromPayload(payload);
  }

  Future<void> resendVerificationCode({required String email}) async {
    await _api.post(
      ApiEndpoints.authResendVerificationCode,
      body: {'email': email},
    );
  }

  Future<AuthSession> _authenticate(
    String path,
    Map<String, String> body,
  ) async {
    try {
      final payload = await _api.post(path, body: body);
      return _sessionFromPayload(payload);
    } on ApiException catch (e) {
      final data = e.data;
      if (data?['requiresVerification'] == true) {
        throw VerificationRequiredException(
          e.message,
          (data?['email'] ?? '').toString(),
        );
      }
      rethrow;
    }
  }

  Future<AuthSession> _sessionFromPayload(
    Map<String, dynamic> payload,
  ) async {
    if (payload['success'] == false) {
      final data = payload['data'] as Map<String, dynamic>?;
      if (data?['requiresVerification'] == true) {
        throw VerificationRequiredException(
          payload['message'] as String? ?? 'Please verify your email.',
          (data?['email'] ?? '').toString(),
        );
      }
      throw ApiException(
        payload['message'] as String? ?? 'Unable to authenticate.',
      );
    }

    final data = payload['data'] as Map<String, dynamic>?;
    final user = data?['user'] as Map<String, dynamic>?;
    final token = data?['token'] as String?;

    if (data == null || user == null || token == null || token.isEmpty) {
      throw const ApiException('Authentication response was incomplete.');
    }

    final session = AuthSession(
      token: token,
      userId: (user['_id'] ?? '').toString(),
      name: (user['name'] ?? '').toString(),
      email: (user['email'] ?? '').toString(),
      isEmailVerified: user['isEmailVerified'] == true,
    );

    await _saveSession(session);
    return session;
  }

  Future<void> _saveSession(AuthSession session) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, session.token);
    await prefs.setString(_userIdKey, session.userId);
    await prefs.setString(_nameKey, session.name);
    await prefs.setString(_emailKey, session.email);
  }
}
