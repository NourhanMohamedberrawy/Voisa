class ApiEndpoints {
  ApiEndpoints._();

  static const authLogin = '/api/auth/login';
  static const authRegister = '/api/auth/register';
  static const authVerifyEmail = '/api/auth/verify-email';
  static const authResendVerificationCode =
      '/api/auth/resend-verification-code';

  static const usersMe = '/api/users/me';
  static const usersContacts = '/api/users/contacts';

  static const eventsTrigger = '/api/events/trigger';
  static const eventsSquadReceived = '/api/events/squad/received';

  static String eventsCancel(String eventId) => '/api/events/$eventId/cancel';

  static const detectorStatus = '/status';
}
