import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'api_config.dart';

class ApiException implements Exception {
  const ApiException(
    this.message, {
    this.statusCode,
    this.isAuthError = false,
    this.data,
  });

  final String message;
  final int? statusCode;
  final bool isAuthError;
  final Map<String, dynamic>? data;

  @override
  String toString() => message;
}

class ApiClient {
  ApiClient({
    http.Client? client,
    Future<String?> Function()? tokenProvider,
    Duration timeout = const Duration(seconds: 12),
  })  : _client = client ?? http.Client(),
        _tokenProvider = tokenProvider,
        _timeout = timeout;

  final http.Client _client;
  final Future<String?> Function()? _tokenProvider;
  final Duration _timeout;

  Future<Map<String, dynamic>> get(
    String path, {
    bool authenticated = false,
  }) {
    return _send('GET', path, authenticated: authenticated);
  }

  Future<Map<String, dynamic>> post(
    String path, {
    Object? body,
    bool authenticated = false,
  }) {
    return _send('POST', path, body: body, authenticated: authenticated);
  }

  Future<Map<String, dynamic>> delete(
    String path, {
    Object? body,
    bool authenticated = false,
  }) {
    return _send('DELETE', path, body: body, authenticated: authenticated);
  }

  Future<Map<String, dynamic>> _send(
    String method,
    String path, {
    Object? body,
    bool authenticated = false,
  }) async {
    final request = http.Request(method, ApiConfig.backendUri(path));
    request.headers.addAll(await _headers(authenticated));
    if (body != null) request.body = jsonEncode(body);

    try {
      final streamed = await _client.send(request).timeout(_timeout);
      final response = await http.Response.fromStream(streamed);
      final payload = _decodeObject(response.body);

      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw ApiException(
          payload['message'] as String? ?? 'Request failed.',
          statusCode: response.statusCode,
          isAuthError: response.statusCode == 401 || response.statusCode == 403,
          data: payload['data'] as Map<String, dynamic>?,
        );
      }

      return payload;
    } on ApiException {
      rethrow;
    } on TimeoutException {
      throw const ApiException('The server took too long to respond.');
    } on SocketException {
      throw const ApiException('Could not connect to the backend.');
    } on FormatException {
      throw const ApiException('Server returned an invalid response.');
    } on http.ClientException {
      throw const ApiException('Could not connect to the backend.');
    }
  }

  Future<Map<String, String>> _headers(bool authenticated) async {
    final headers = {'Content-Type': 'application/json'};
    if (!authenticated) return headers;

    final token = await _tokenProvider?.call();
    if (token == null || token.isEmpty) {
      throw const ApiException('Please sign in again.', isAuthError: true);
    }

    headers['Authorization'] = 'Bearer $token';
    return headers;
  }

  Map<String, dynamic> _decodeObject(String body) {
    final decoded = jsonDecode(body);
    if (decoded is Map<String, dynamic>) return decoded;
    throw const FormatException('Expected JSON object');
  }
}
