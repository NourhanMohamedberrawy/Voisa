import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../utils/app_logger.dart';

// ─── Connectivity Service ─────────────────────────────────────────────────────
// Wraps connectivity_plus into a clean stream any widget can listen to.
//
// Add to pubspec.yaml:
//   connectivity_plus: ^6.0.3
//
// Usage:
//   ConnectivityService.instance.isOnline   // sync bool
//   ConnectivityService.instance.stream     // Stream<bool>

class ConnectivityService {
  ConnectivityService._();
  static final instance = ConnectivityService._();

  final _connectivity = Connectivity();
  final _controller = StreamController<bool>.broadcast();

  bool _isOnline = true;
  StreamSubscription? _sub;

  bool get isOnline => _isOnline;
  Stream<bool> get stream => _controller.stream;

  /// Call once in main() before runApp.
  Future<void> init() async {
    try {
      final result = await _connectivity.checkConnectivity();
      _isOnline = _isConnected(result);

      _sub = _connectivity.onConnectivityChanged.listen((result) {
        final online = _isConnected(result);
        if (online != _isOnline) {
          _isOnline = online;
          _controller.add(_isOnline);
          AppLogger.info(
            online ? 'Connection restored' : 'Connection lost',
            context: 'ConnectivityService',
          );
        }
      });
    } catch (e, st) {
      AppLogger.error('Connectivity init failed',
          context: 'ConnectivityService', error: e, stackTrace: st);
    }
  }

  void dispose() {
    _sub?.cancel();
    _controller.close();
  }

  bool _isConnected(List<ConnectivityResult> results) =>
      results.any((r) => r != ConnectivityResult.none);
}
