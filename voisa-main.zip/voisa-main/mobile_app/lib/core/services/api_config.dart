class ApiConfig {
  ApiConfig._();

  static const String backendBaseUrl = String.fromEnvironment(
    'VOISA_API_BASE_URL',
    defaultValue: 'http://localhost:3000',
  );

  static const String detectorBaseUrl = String.fromEnvironment(
    'VOISA_DETECTOR_BASE_URL',
    defaultValue: 'http://localhost:8888',
  );

  static Uri backendUri(String path) => _join(backendBaseUrl, path);

  static Uri detectorUri(String path) => _join(detectorBaseUrl, path);

  static Uri _join(String baseUrl, String path) {
    final cleanBase = baseUrl.replaceFirst(RegExp(r'/+$'), '');
    final cleanPath = path.startsWith('/') ? path : '/$path';
    return Uri.parse('$cleanBase$cleanPath');
  }
}
