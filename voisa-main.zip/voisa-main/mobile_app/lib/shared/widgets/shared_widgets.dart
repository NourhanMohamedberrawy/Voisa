import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:voisa/core/theme/app_theme.dart';
import 'package:voisa/core/constants/app_constants.dart';

// ─── Contact Avatar ───────────────────────────────────────────────────────────
class ContactAvatar extends StatelessWidget {
  const ContactAvatar({
    super.key,
    this.imageUrl,
    this.imageBytes,
    this.name = '',
    this.color,
    this.radius = 24,
  });

  final String? imageUrl;
  final Uint8List? imageBytes;
  final String name;
  final Color? color;
  final double radius;

  @override
  Widget build(BuildContext context) {
    // Network image takes priority
    if (imageUrl != null && imageUrl!.isNotEmpty) {
      return CircleAvatar(
        radius: radius,
        backgroundImage: NetworkImage(imageUrl!),
        backgroundColor: AppColors.surfaceDark,
      );
    }

    // Memory image from device contacts
    if (imageBytes != null && imageBytes!.isNotEmpty) {
      return CircleAvatar(
        radius: radius,
        backgroundImage: MemoryImage(imageBytes!),
        backgroundColor: AppColors.surfaceDark,
      );
    }

    // Initials fallback
    final initial = name.isNotEmpty ? name[0].toUpperCase() : '?';
    final bg = color ?? AppColors.navIconBg;
    return Semantics(
      label: name.isNotEmpty ? 'Contact: $name' : 'Contact avatar',
      child: CircleAvatar(
        radius: radius,
        backgroundColor: bg,
        child: Text(
          initial,
          style: TextStyle(
            color: Colors.white,
            fontSize: radius * 0.75,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}

// ─── Section Header ───────────────────────────────────────────────────────────
class SectionHeader extends StatelessWidget {
  const SectionHeader({
    super.key,
    required this.title,
    this.trailing,
    this.trailingLabel,
    this.onTrailingTap,
  });

  final String title;
  final Widget? trailing;
  final String? trailingLabel;
  final VoidCallback? onTrailingTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: AppTextStyles.sectionTitle),
        if (trailingLabel != null)
          Semantics(
            label: trailingLabel,
            button: true,
            child: GestureDetector(
              onTap: onTrailingTap,
              child: Text(
                trailingLabel!,
                style: AppTextStyles.caption.copyWith(
                  color: AppColors.textSecondary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          )
        else if (trailing != null)
          trailing!,
      ],
    );
  }
}

// ─── Primary Button ───────────────────────────────────────────────────────────
class PrimaryButton extends StatelessWidget {
  const PrimaryButton({
    super.key,
    required this.label,
    required this.onTap,
    this.icon,
    this.isOutlined = false,
    this.color,
    this.textColor,
    this.width,
    this.height = 48,
    this.fontSize = 15,
    this.semanticsLabel,
  });

  final String label;
  final VoidCallback onTap;
  final IconData? icon;
  final bool isOutlined;
  final Color? color;
  final Color? textColor;
  final double? width;
  final double height;
  final double fontSize;

  /// Override the accessibility label when the visible text
  /// is not descriptive enough (e.g. icon-only buttons).
  final String? semanticsLabel;

  @override
  Widget build(BuildContext context) {
    final bg = color ?? AppColors.primary;
    final fg = textColor ?? Colors.white;

    // Use MediaQuery text scale to keep button text readable but
    // prevent overflow at very large accessibility text sizes.
    final effectiveFontSize = fontSize.clamp(
      12.0,
      fontSize * 1.2,
    );

    Widget button = SizedBox(
      width: width,
      height: height,
      child: isOutlined
          ? OutlinedButton.icon(
              onPressed: onTap,
              icon: icon != null
                  ? Icon(icon, size: 18, color: fg)
                  : const SizedBox.shrink(),
              label: Text(
                label,
                style: AppTextStyles.buttonLabel.copyWith(
                  color: fg,
                  fontSize: effectiveFontSize,
                ),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: bg, width: 1.5),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                ),
              ),
            )
          : ElevatedButton.icon(
              onPressed: onTap,
              icon: icon != null
                  ? Icon(icon, size: 18, color: fg)
                  : const SizedBox.shrink(),
              label: Text(
                label,
                style: AppTextStyles.buttonLabel.copyWith(
                  color: fg,
                  fontSize: effectiveFontSize,
                ),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: bg,
                foregroundColor: fg,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                ),
              ),
            ),
    );

    if (semanticsLabel != null) {
      button = Semantics(label: semanticsLabel, button: true, child: button);
    }

    return button;
  }
}

// ─── Voisa Card ───────────────────────────────────────────────────────────────
class VoisaCard extends StatelessWidget {
  const VoisaCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(AppSpacing.md),
    this.color,
    this.borderRadius,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? color;
  final BorderRadiusGeometry? borderRadius;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: color ?? AppColors.surface,
        borderRadius: borderRadius ?? BorderRadius.circular(AppRadius.lg),
      ),
      padding: padding,
      child: child,
    );
  }
}

// ─── Waveform Visual (static placeholder) ────────────────────────────────────
class WaveformBar extends StatelessWidget {
  const WaveformBar({super.key, this.color = Colors.white});

  final Color color;

  static const List<double> _heights = [
    14,
    22,
    10,
    28,
    18,
    32,
    12,
    24,
    16,
    30,
    20,
    26,
    8,
    28,
    14,
    22,
    32,
    18,
    24,
    12,
    20,
    30,
    16,
    22,
    28,
    10,
    26,
    18,
    14,
    24,
    18,
    24,
    12,
    20,
    30,
    16,
    22,
    28,
    10,
    6,
  ];

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: 'Audio waveform',
      excludeSemantics: true, // decorative — exclude child nodes
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: _heights.map((h) {
          return Container(
            width: 3,
            height: h,
            margin: const EdgeInsets.symmetric(horizontal: 1.5),
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(2),
            ),
          );
        }).toList(),
      ),
    );
  }
}
