import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import '../../../auth/presentation/screens/login_screen.dart';
import '../../../auth/presentation/screens/signup_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final topPadding = MediaQuery.of(context).padding.top;
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Padding(
        padding: EdgeInsets.only(
          top: topPadding + AppSpacing.lg,
          left: AppSpacing.screenH,
          right: AppSpacing.screenH,
          bottom: bottomPadding + AppSpacing.lg,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Logo row
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF921F16), Color(0xFFE43E34)],
                ),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Icon(Icons.shield_rounded,
                  color: Colors.white, size: 26),
            ),
            const Spacer(),

            // Hero illustration area
            Center(
              child: _WelcomeIllustration(size: size),
            ),
            const Spacer(),

            // Headline
            Text(
              'Safety in\nyour pocket.',
              style: AppTextStyles.displayLarge.copyWith(
                fontSize: 34,
                height: 1.15,
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            Text(
              'Voisa detects distress, alerts your contacts, '
              'and shares your location — all automatically.',
              style: AppTextStyles.body.copyWith(
                color: AppColors.textSecondary,
                height: 1.5,
              ),
            ),
            const SizedBox(height: AppSpacing.xl),

            // CTA buttons
            PrimaryButton(
              label: 'Get Started',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SignUpScreen()),
              ),
              width: double.infinity,
              height: 52,
            ),
            const SizedBox(height: AppSpacing.md),
            PrimaryButton(
              label: 'I already have an account',
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              ),
              isOutlined: true,
              color: AppColors.primary,
              textColor: AppColors.primary,
              width: double.infinity,
              height: 52,
            ),
          ],
        ),
      ),
    );
  }
}

class _WelcomeIllustration extends StatelessWidget {
  const _WelcomeIllustration({required this.size});
  final Size size;

  @override
  Widget build(BuildContext context) {
    // Three feature hint cards arranged to suggest the app's value
    return const SizedBox(
      height: 220,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Back card — location
          Positioned(
            left: 0,
            top: 20,
            child: _HintCard(
              icon: Icons.location_on_rounded,
              label: 'Live location\nshared instantly',
              color: AppColors.surface,
              iconColor: AppColors.primary,
            ),
          ),
          // Back card — contacts
          Positioned(
            right: 0,
            top: 20,
            child: _HintCard(
              icon: Icons.group_rounded,
              label: 'Trusted contacts\nalways notified',
              color: AppColors.surface,
              iconColor: AppColors.primary,
            ),
          ),
          // Front center card — SOS
          _HintCard(
            icon: Icons.shield_rounded,
            label: 'AI distress\ndetection',
            color: AppColors.primary,
            iconColor: Colors.white,
            labelColor: Colors.white,
            elevated: true,
          ),
        ],
      ),
    );
  }
}

class _HintCard extends StatelessWidget {
  const _HintCard({
    required this.icon,
    required this.label,
    required this.color,
    required this.iconColor,
    this.labelColor,
    this.elevated = false,
  });

  final IconData icon;
  final String label;
  final Color color;
  final Color iconColor;
  final Color? labelColor;
  final bool elevated;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 130,
      padding: const EdgeInsets.all(AppSpacing.md),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        boxShadow: elevated
            ? [
                BoxShadow(
                  color: AppColors.primary.withValues(alpha: 0.25),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                )
              ]
            : null,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: iconColor, size: 26),
          const SizedBox(height: AppSpacing.sm),
          Text(
            label,
            style: AppTextStyles.caption.copyWith(
              color: labelColor ?? AppColors.textSecondary,
              fontWeight: FontWeight.w600,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }
}
