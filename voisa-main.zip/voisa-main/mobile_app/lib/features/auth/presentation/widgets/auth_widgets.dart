import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:voisa/core/constants/app_constants.dart';
import 'package:voisa/core/theme/app_theme.dart';

void dismissKeyboardIfFocusDidNotMove() {
  final focusedNode = FocusManager.instance.primaryFocus;

  WidgetsBinding.instance.addPostFrameCallback((_) {
    if (focusedNode?.context != null &&
        FocusManager.instance.primaryFocus == focusedNode) {
      focusedNode?.unfocus();
    }
  });
}

class AuthKeyboardScope extends StatefulWidget {
  const AuthKeyboardScope({super.key, required this.child});

  final Widget child;

  static _AuthKeyboardController? _maybeOf(BuildContext context) {
    return context
        .dependOnInheritedWidgetOfExactType<_AuthKeyboardScopeData>()
        ?.controller;
  }

  @override
  State<AuthKeyboardScope> createState() => _AuthKeyboardScopeState();
}

class _AuthKeyboardScopeState extends State<AuthKeyboardScope> {
  late final _AuthKeyboardController _controller;

  @override
  void initState() {
    super.initState();
    _controller = _AuthKeyboardController();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _AuthKeyboardScopeData(
      controller: _controller,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          widget.child,
          Positioned(
            left: -4,
            top: 0,
            width: 1,
            height: 1,
            child: IgnorePointer(
              child: AnimatedBuilder(
                animation: _controller,
                builder: (context, _) {
                  return TextField(
                    controller: _controller.inputController,
                    focusNode: _controller.focusNode,
                    groupId: AuthTextField,
                    keyboardType: _controller.keyboardType,
                    obscureText: _controller.obscureText,
                    inputFormatters: _controller.inputFormatters,
                    maxLength: _controller.maxLength,
                    enableSuggestions: false,
                    autocorrect: false,
                    showCursor: false,
                    onTapOutside: (_) => dismissKeyboardIfFocusDidNotMove(),
                    style: const TextStyle(
                      color: Colors.transparent,
                      fontSize: 1,
                      height: 1,
                    ),
                    cursorColor: Colors.transparent,
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      counterText: '',
                      contentPadding: EdgeInsets.zero,
                      isCollapsed: true,
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AuthKeyboardScopeData
    extends InheritedNotifier<_AuthKeyboardController> {
  const _AuthKeyboardScopeData({
    required this.controller,
    required super.child,
  }) : super(notifier: controller);

  final _AuthKeyboardController controller;
}

class _AuthKeyboardController extends ChangeNotifier {
  _AuthKeyboardController() {
    focusNode.addListener(notifyListeners);
    inputController.addListener(_syncInputToActiveController);
  }

  final TextEditingController inputController = TextEditingController();
  final FocusNode focusNode = FocusNode();

  TextEditingController? activeController;
  TextInputType? keyboardType;
  bool obscureText = false;
  List<TextInputFormatter>? inputFormatters;
  int? maxLength;
  bool _isSyncing = false;

  void activate({
    required TextEditingController controller,
    required TextInputType? keyboardType,
    required bool obscureText,
    List<TextInputFormatter>? inputFormatters,
    int? maxLength,
  }) {
    activeController = controller;
    this.keyboardType = keyboardType;
    this.obscureText = obscureText;
    this.inputFormatters = inputFormatters;
    this.maxLength = maxLength;

    _isSyncing = true;
    inputController.value = TextEditingValue(
      text: controller.text,
      selection: TextSelection.collapsed(offset: controller.text.length),
    );
    _isSyncing = false;

    focusNode.requestFocus();
    notifyListeners();
  }

  void _syncInputToActiveController() {
    if (_isSyncing || activeController == null) return;

    final active = activeController!;
    if (active.value == inputController.value) return;

    active.value = inputController.value;
  }

  @override
  void dispose() {
    inputController.removeListener(_syncInputToActiveController);
    focusNode.removeListener(notifyListeners);
    inputController.dispose();
    focusNode.dispose();
    super.dispose();
  }
}

class AuthTextField extends StatelessWidget {
  const AuthTextField({
    super.key,
    required this.controller,
    required this.label,
    this.keyboardType,
    this.obscureText = false,
    this.suffixIcon,
  });

  final TextEditingController controller;
  final String label;
  final TextInputType? keyboardType;
  final bool obscureText;
  final Widget? suffixIcon;

  @override
  Widget build(BuildContext context) {
    final keyboardScope = AuthKeyboardScope._maybeOf(context);
    if (keyboardScope != null) {
      return _SyncedAuthTextField(
        controller: controller,
        keyboardScope: keyboardScope,
        label: label,
        keyboardType: keyboardType,
        obscureText: obscureText,
        suffixIcon: suffixIcon,
      );
    }

    return TextField(
      controller: controller,
      groupId: AuthTextField,
      keyboardType: keyboardType,
      obscureText: obscureText,
      onTapOutside: (_) => dismissKeyboardIfFocusDidNotMove(),
      style: AppTextStyles.body,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: AppTextStyles.body.copyWith(color: AppColors.textSecondary),
        filled: true,
        fillColor: AppColors.surface,
        suffixIcon: suffixIcon,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md,
          vertical: AppSpacing.md,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppRadius.md),
          borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
        ),
      ),
    );
  }
}

class _SyncedAuthTextField extends StatefulWidget {
  const _SyncedAuthTextField({
    required this.controller,
    required this.keyboardScope,
    required this.label,
    required this.obscureText,
    this.keyboardType,
    this.suffixIcon,
  });

  final TextEditingController controller;
  final _AuthKeyboardController keyboardScope;
  final String label;
  final TextInputType? keyboardType;
  final bool obscureText;
  final Widget? suffixIcon;

  @override
  State<_SyncedAuthTextField> createState() => _SyncedAuthTextFieldState();
}

class _SyncedAuthTextFieldState extends State<_SyncedAuthTextField> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_handleControllerChanged);
  }

  @override
  void didUpdateWidget(_SyncedAuthTextField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.removeListener(_handleControllerChanged);
      widget.controller.addListener(_handleControllerChanged);
    }
  }

  @override
  void dispose() {
    widget.controller.removeListener(_handleControllerChanged);
    super.dispose();
  }

  void _handleControllerChanged() {
    if (mounted) setState(() {});
  }

  void _activate() {
    widget.keyboardScope.activate(
      controller: widget.controller,
      keyboardType: widget.keyboardType,
      obscureText: widget.obscureText,
    );
  }

  @override
  Widget build(BuildContext context) {
    final isFocused =
        widget.keyboardScope.activeController == widget.controller &&
            widget.keyboardScope.focusNode.hasFocus;
    final text = widget.controller.text;
    final displayText =
        widget.obscureText ? List.filled(text.length, '*').join() : text;

    return TextFieldTapRegion(
      groupId: AuthTextField,
      child: Semantics(
        textField: true,
        focused: isFocused,
        label: widget.label,
        value: text,
        child: GestureDetector(
          key: ValueKey('auth-field-${widget.label}'),
          behavior: HitTestBehavior.opaque,
          onTap: _activate,
          child: InputDecorator(
            isFocused: isFocused,
            isEmpty: text.isEmpty,
            decoration: InputDecoration(
              labelText: widget.label,
              labelStyle:
                  AppTextStyles.body.copyWith(color: AppColors.textSecondary),
              filled: true,
              fillColor: AppColors.surface,
              suffixIcon: widget.suffixIcon,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.md,
                vertical: AppSpacing.md,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppRadius.md),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppRadius.md),
                borderSide:
                    const BorderSide(color: AppColors.primary, width: 1.5),
              ),
            ),
            child: Text(
              displayText.isEmpty ? ' ' : displayText,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTextStyles.body,
            ),
          ),
        ),
      ),
    );
  }
}

class AuthErrorMessage extends StatelessWidget {
  const AuthErrorMessage({super.key, required this.message});
  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.md,
        vertical: AppSpacing.sm,
      ),
      decoration: BoxDecoration(
        color: AppColors.emergency.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(AppRadius.md),
      ),
      child: Text(
        message,
        style: AppTextStyles.caption.copyWith(
          color: AppColors.emergency,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}
