import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import '../../../auth/presentation/widgets/auth_widgets.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _emailController = TextEditingController();
  String? _errorMessage;
  bool _sent = false;

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  void _onSend() {
    final email = _emailController.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      setState(() => _errorMessage = 'Please enter a valid email address.');
      return;
    }
    setState(() {
      _errorMessage = null;
      _sent = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: AuthKeyboardScope(
        child: Padding(
          padding: EdgeInsets.only(
            top: topPadding + AppSpacing.lg,
            left: AppSpacing.screenH,
            right: AppSpacing.screenH,
            bottom: bottomPadding + AppSpacing.lg,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: const Icon(Icons.arrow_back_rounded,
                    color: AppColors.textPrimary, size: 24),
              ),
              const SizedBox(height: AppSpacing.xl),
              Text('Forgot\npassword?',
                  style: AppTextStyles.displayLarge.copyWith(height: 1.15)),
              const SizedBox(height: AppSpacing.sm),
              Text(
                'Enter your email and we\'ll send you a reset link.',
                style:
                    AppTextStyles.body.copyWith(color: AppColors.textSecondary),
              ),
              const SizedBox(height: AppSpacing.xl),
              if (!_sent) ...[
                AuthTextField(
                  controller: _emailController,
                  label: 'Email address',
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: AppSpacing.lg),
                if (_errorMessage != null) ...[
                  AuthErrorMessage(message: _errorMessage!),
                  const SizedBox(height: AppSpacing.md),
                ],
                PrimaryButton(
                  label: 'Send Reset Link',
                  onTap: _onSend,
                  width: double.infinity,
                  height: 52,
                ),
              ] else ...[
                // Confirmation state
                VoisaCard(
                  padding: const EdgeInsets.all(AppSpacing.lg),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: AppColors.primary.withValues(alpha: 0.1),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.mark_email_read_rounded,
                            color: AppColors.primary, size: 22),
                      ),
                      const SizedBox(width: AppSpacing.md),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Check your email',
                                style: AppTextStyles.cardTitle
                                    .copyWith(fontSize: 16)),
                            const SizedBox(height: 2),
                            Text(
                              'A reset link was sent to ${_emailController.text.trim()}',
                              style: AppTextStyles.caption,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.lg),
                PrimaryButton(
                  label: 'Back to Sign In',
                  onTap: () => Navigator.of(context).pop(),
                  width: double.infinity,
                  height: 52,
                  isOutlined: true,
                  color: AppColors.primary,
                  textColor: AppColors.primary,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
