import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import '../../../../navigation/main_shell.dart';
import 'signup_screen.dart';
import 'forgot_password_screen.dart';
import '../../../auth/presentation/widgets/auth_widgets.dart';

typedef LoginHandler = Future<void> Function(String email, String password);

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, this.onLoginOverride});

  final LoginHandler? onLoginOverride;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  String? _errorMessage;
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _onLogin() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text;

    if (_isLoading) return;
    if (email.isEmpty || password.isEmpty) {
      setState(() => _errorMessage = 'Please fill in all fields.');
      return;
    }
    if (!email.contains('@')) {
      setState(() => _errorMessage = 'Please enter a valid email.');
      return;
    }
    setState(() {
      _errorMessage = null;
      _isLoading = true;
    });

    try {
      final login = widget.onLoginOverride;
      if (login != null) {
        await login(email, password);
      } else {
        await AuthService.instance.login(email: email, password: password);
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _errorMessage = e.message);
      return;
    } catch (_) {
      if (!mounted) return;
      setState(() => _errorMessage = 'Could not connect to the backend.');
      return;
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }

    if (!mounted) return;

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainShell()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: AuthKeyboardScope(
        child: SingleChildScrollView(
          padding: EdgeInsets.only(
            top: topPadding + AppSpacing.lg,
            left: AppSpacing.screenH,
            right: AppSpacing.screenH,
            bottom: bottomPadding + AppSpacing.lg,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Back button
              GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: const Icon(Icons.arrow_back_rounded,
                    color: AppColors.textPrimary, size: 24),
              ),
              const SizedBox(height: AppSpacing.xl),

              Text('Welcome\nback.',
                  style: AppTextStyles.displayLarge.copyWith(height: 1.15)),
              const SizedBox(height: AppSpacing.sm),
              Text(
                'Sign in to keep your safety network active.',
                style:
                    AppTextStyles.body.copyWith(color: AppColors.textSecondary),
              ),
              const SizedBox(height: AppSpacing.xl),

              // Email
              AuthTextField(
                controller: _emailController,
                label: 'Email address',
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: AppSpacing.md),

              // Password
              AuthTextField(
                controller: _passwordController,
                label: 'Password',
                obscureText: _obscurePassword,
                suffixIcon: GestureDetector(
                  onTap: () =>
                      setState(() => _obscurePassword = !_obscurePassword),
                  child: Icon(
                    _obscurePassword
                        ? Icons.visibility_off_rounded
                        : Icons.visibility_rounded,
                    color: AppColors.textSecondary,
                    size: 20,
                  ),
                ),
              ),
              const SizedBox(height: AppSpacing.sm),

              // Forgot password
              Align(
                alignment: Alignment.centerRight,
                child: GestureDetector(
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                        builder: (_) => const ForgotPasswordScreen()),
                  ),
                  child: Text(
                    'Forgot password?',
                    style: AppTextStyles.caption.copyWith(
                      color: AppColors.primary,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: AppSpacing.lg),

              // Error
              if (_errorMessage != null) ...[
                AuthErrorMessage(message: _errorMessage!),
                const SizedBox(height: AppSpacing.md),
              ],

              // Login button
              PrimaryButton(
                label: _isLoading ? 'Signing In...' : 'Sign In',
                onTap: _isLoading ? () {} : _onLogin,
                width: double.infinity,
                height: 52,
              ),
              const SizedBox(height: AppSpacing.xl),

              // Sign up link
              Center(
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (_) => const SignUpScreen()),
                  ),
                  child: RichText(
                    text: TextSpan(
                      style: AppTextStyles.body
                          .copyWith(color: AppColors.textSecondary),
                      children: [
                        const TextSpan(text: "Don't have an account? "),
                        TextSpan(
                          text: 'Sign up',
                          style: AppTextStyles.bodyBold
                              .copyWith(color: AppColors.primary),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
