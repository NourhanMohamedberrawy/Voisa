import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import 'login_screen.dart';
import 'verification_screen.dart';
import '../../../auth/presentation/widgets/auth_widgets.dart';

typedef SignUpHandler = Future<void> Function(
  String name,
  String email,
  String password,
);

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key, this.onSignUpOverride});

  final SignUpHandler? onSignUpOverride;

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;
  String? _errorMessage;
  bool _isLoading = false;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _onSignUp() async {
    final name = _nameController.text.trim();
    final email = _emailController.text.trim();
    final password = _passwordController.text;

    if (_isLoading) return;
    if (name.isEmpty || email.isEmpty || password.isEmpty) {
      setState(() => _errorMessage = 'Please fill in all fields.');
      return;
    }
    if (!email.contains('@')) {
      setState(() => _errorMessage = 'Please enter a valid email.');
      return;
    }
    if (password.length < 8) {
      setState(() => _errorMessage = 'Password must be at least 8 characters.');
      return;
    }
    setState(() {
      _errorMessage = null;
      _isLoading = true;
    });

    try {
      final signUp = widget.onSignUpOverride;
      if (signUp != null) {
        await signUp(name, email, password);
      } else {
        await AuthService.instance.register(
          name: name,
          email: email,
          password: password,
        );
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _errorMessage = e.message);
      return;
    } catch (_) {
      if (!mounted) return;
      setState(() => _errorMessage = 'Could not connect to the backend.');
      return;
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }

    if (!mounted) return;

    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => VerificationScreen(email: email)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: AuthKeyboardScope(
        child: SingleChildScrollView(
          padding: EdgeInsets.only(
            top: topPadding + AppSpacing.lg,
            left: AppSpacing.screenH,
            right: AppSpacing.screenH,
            bottom: bottomPadding + AppSpacing.lg,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: const Icon(Icons.arrow_back_rounded,
                    color: AppColors.textPrimary, size: 24),
              ),
              const SizedBox(height: AppSpacing.xl),
              Text('Create your\naccount.',
                  style: AppTextStyles.displayLarge.copyWith(height: 1.15)),
              const SizedBox(height: AppSpacing.sm),
              Text(
                'Set up Voisa so it can protect you.',
                style:
                    AppTextStyles.body.copyWith(color: AppColors.textSecondary),
              ),
              const SizedBox(height: AppSpacing.xl),
              AuthTextField(controller: _nameController, label: 'Full name'),
              const SizedBox(height: AppSpacing.md),
              AuthTextField(
                controller: _emailController,
                label: 'Email address',
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: AppSpacing.md),
              AuthTextField(
                controller: _passwordController,
                label: 'Password',
                obscureText: _obscurePassword,
                suffixIcon: GestureDetector(
                  onTap: () =>
                      setState(() => _obscurePassword = !_obscurePassword),
                  child: Icon(
                    _obscurePassword
                        ? Icons.visibility_off_rounded
                        : Icons.visibility_rounded,
                    color: AppColors.textSecondary,
                    size: 20,
                  ),
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
              if (_errorMessage != null) ...[
                AuthErrorMessage(message: _errorMessage!),
                const SizedBox(height: AppSpacing.md),
              ],
              PrimaryButton(
                label: _isLoading ? 'Creating Account...' : 'Create Account',
                onTap: _isLoading ? () {} : _onSignUp,
                width: double.infinity,
                height: 52,
              ),
              const SizedBox(height: AppSpacing.xl),
              Center(
                child: GestureDetector(
                  onTap: () => Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                  ),
                  child: RichText(
                    text: TextSpan(
                      style: AppTextStyles.body
                          .copyWith(color: AppColors.textSecondary),
                      children: [
                        const TextSpan(text: 'Already have an account? '),
                        TextSpan(
                          text: 'Sign in',
                          style: AppTextStyles.bodyBold
                              .copyWith(color: AppColors.primary),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
