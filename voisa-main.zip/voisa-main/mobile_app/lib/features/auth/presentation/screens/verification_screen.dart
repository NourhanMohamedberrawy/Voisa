import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../core/utils/app_feedback.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import '../../../setup/presentation/screens/contacts_setup_screen.dart';
import '../../../auth/presentation/widgets/auth_widgets.dart';

class VerificationScreen extends StatefulWidget {
  const VerificationScreen({super.key, this.email});

  final String? email;

  @override
  State<VerificationScreen> createState() => _VerificationScreenState();
}

class _VerificationScreenState extends State<VerificationScreen> {
  final TextEditingController _codeController = TextEditingController();
  final FocusNode _codeFocusNode = FocusNode();
  String? _email;
  String? _errorMessage;
  bool _isVerifying = false;
  bool _isResending = false;

  @override
  void initState() {
    super.initState();
    _email = widget.email;
    if (_email == null || _email!.isEmpty) {
      AuthService.instance.getEmail().then((email) {
        if (!mounted) return;
        setState(() => _email = email);
      });
    }
  }

  @override
  void dispose() {
    _codeController.dispose();
    _codeFocusNode.dispose();
    super.dispose();
  }

  Future<void> _onVerify() async {
    final code = _codeController.text;
    final email = _email;

    if (_isVerifying) return;
    if (email == null || email.isEmpty) {
      setState(() => _errorMessage = 'Email missing. Please sign up again.');
      return;
    }
    if (code.length < 6) {
      setState(() => _errorMessage = 'Please enter the complete 6-digit code.');
      return;
    }
    setState(() {
      _errorMessage = null;
      _isVerifying = true;
    });

    try {
      await AuthService.instance.verifyEmail(email: email, code: code);
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _errorMessage = e.message);
      return;
    } catch (_) {
      if (!mounted) return;
      setState(() => _errorMessage = 'Could not verify the code.');
      return;
    } finally {
      if (mounted) setState(() => _isVerifying = false);
    }

    if (!mounted) return;

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const ContactsSetupScreen()),
      (_) => false,
    );
  }

  Future<void> _onResendCode() async {
    final email = _email;
    if (_isResending) return;
    if (email == null || email.isEmpty) {
      setState(() => _errorMessage = 'Email missing. Please sign up again.');
      return;
    }

    setState(() {
      _errorMessage = null;
      _isResending = true;
    });

    try {
      await AuthService.instance.resendVerificationCode(email: email);
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _errorMessage = e.message);
      return;
    } catch (_) {
      if (!mounted) return;
      setState(() => _errorMessage = 'Could not resend the code.');
      return;
    } finally {
      if (mounted) setState(() => _isResending = false);
    }

    if (!mounted) return;
    AppFeedback.showSuccess(context, 'Code resent.');
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned(
            left: -4,
            top: 0,
            width: 1,
            height: 1,
            child: IgnorePointer(
              child: TextField(
                controller: _codeController,
                focusNode: _codeFocusNode,
                groupId: AuthTextField,
                keyboardType: TextInputType.number,
                maxLength: 6,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                onChanged: (_) => setState(() {}),
                onTapOutside: (_) => dismissKeyboardIfFocusDidNotMove(),
                showCursor: false,
                style: const TextStyle(
                  color: Colors.transparent,
                  fontSize: 1,
                  height: 1,
                ),
                cursorColor: Colors.transparent,
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  counterText: '',
                  contentPadding: EdgeInsets.zero,
                  isCollapsed: true,
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              top: topPadding + AppSpacing.lg,
              left: AppSpacing.screenH,
              right: AppSpacing.screenH,
              bottom: bottomPadding + AppSpacing.lg,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: const Icon(Icons.arrow_back_rounded,
                      color: AppColors.textPrimary, size: 24),
                ),
                const SizedBox(height: AppSpacing.xl),

                Text('Verify\nyour email.',
                    style: AppTextStyles.displayLarge.copyWith(height: 1.15)),
                const SizedBox(height: AppSpacing.sm),
                Text(
                  'We sent a 6-digit code to your email address. Enter it below.',
                  style: AppTextStyles.body
                      .copyWith(color: AppColors.textSecondary),
                ),
                const SizedBox(height: AppSpacing.xl),

                // OTP boxes
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: List.generate(6, (i) {
                    return _OtpBox(
                      index: i,
                      controller: _codeController,
                      focusNode: _codeFocusNode,
                    );
                  }),
                ),
                const SizedBox(height: AppSpacing.lg),

                if (_errorMessage != null) ...[
                  AuthErrorMessage(message: _errorMessage!),
                  const SizedBox(height: AppSpacing.md),
                ],

                PrimaryButton(
                  label: _isVerifying ? 'Verifying...' : 'Verify',
                  onTap: _isVerifying ? () {} : _onVerify,
                  width: double.infinity,
                  height: 52,
                ),
                const SizedBox(height: AppSpacing.lg),

                Center(
                  child: GestureDetector(
                    onTap: _isResending ? null : _onResendCode,
                    child: RichText(
                      text: TextSpan(
                        style: AppTextStyles.body
                            .copyWith(color: AppColors.textSecondary),
                        children: [
                          const TextSpan(text: "Didn't receive it? "),
                          TextSpan(
                            text: _isResending ? 'Resending...' : 'Resend code',
                            style: AppTextStyles.bodyBold
                                .copyWith(color: AppColors.primary),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _OtpBox extends StatelessWidget {
  const _OtpBox({
    required this.index,
    required this.controller,
    required this.focusNode,
  });

  final int index;
  final TextEditingController controller;
  final FocusNode focusNode;

  void _activate() {
    final offset =
        index < controller.text.length ? index : controller.text.length;
    controller.selection = TextSelection.collapsed(offset: offset);
    focusNode.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    final text = controller.text;
    final digit = index < text.length ? text[index] : '';
    final isFocused = focusNode.hasFocus &&
        (controller.selection.baseOffset == index ||
            (digit.isEmpty && index == text.length));

    return TextFieldTapRegion(
      groupId: AuthTextField,
      child: GestureDetector(
        key: ValueKey('otp-box-$index'),
        behavior: HitTestBehavior.opaque,
        onTap: _activate,
        child: SizedBox(
          width: 46,
          height: 56,
          child: InputDecorator(
            isFocused: isFocused,
            isEmpty: digit.isEmpty,
            decoration: InputDecoration(
              counterText: '',
              filled: true,
              fillColor: AppColors.surface,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppRadius.md),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(AppRadius.md),
                borderSide:
                    const BorderSide(color: AppColors.primary, width: 2),
              ),
              contentPadding: EdgeInsets.zero,
            ),
            child: Center(
              child: Text(
                digit,
                style: AppTextStyles.cardTitle.copyWith(fontSize: 22),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
