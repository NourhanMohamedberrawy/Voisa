import 'package:flutter/material.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../core/utils/app_feedback.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../home/data/shake_detector_service.dart';
import '../../../onboarding/presentation/screens/welcome_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({
    super.key,
    this.shakeDetectionEnabled = true,
    this.shakeSensitivity = ShakeDetectorService.defaultShakeSensitivity,
    required this.onShakeDetectionChanged,
    required this.onShakeSensitivityChanged,
  });

  final bool shakeDetectionEnabled;
  final double shakeSensitivity;
  final ValueChanged<bool> onShakeDetectionChanged;
  final ValueChanged<double> onShakeSensitivityChanged;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _isDeletingAccount = false;

  Future<void> _logout() async {
    await AuthService.instance.clearSession();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const WelcomeScreen()),
      (_) => false,
    );
  }

  Future<void> _deleteAccount() async {
    final confirmed = await AppFeedback.confirmDestructive(
      context,
      title: 'Delete account?',
      message:
          'This permanently removes your account and safety data from Voisa.',
    );

    if (!confirmed || _isDeletingAccount) return;

    setState(() => _isDeletingAccount = true);
    try {
      await AuthService.instance.deleteAccount();
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const WelcomeScreen()),
        (_) => false,
      );
    } on ApiException catch (e) {
      if (!mounted) return;
      _showError(e.message);
    } catch (_) {
      if (!mounted) return;
      _showError('Could not delete account.');
    } finally {
      if (mounted) setState(() => _isDeletingAccount = false);
    }
  }

  void _showError(String message) {
    AppFeedback.showError(context, message);
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.only(
          top: topPadding + AppSpacing.md,
          left: AppSpacing.screenH,
          right: AppSpacing.screenH,
          bottom: AppSpacing.xl,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Settings', style: AppTextStyles.displayLarge),
            const SizedBox(height: AppSpacing.lg),
            _SettingsTile(
              icon: Icons.person_rounded,
              label: 'Profile',
              onTap: () {},
            ),
            _SettingsTile(
              icon: Icons.notifications_rounded,
              label: 'Notifications',
              onTap: () {},
            ),
            _SettingsTile(
              icon: Icons.location_on_rounded,
              label: 'Location & Privacy',
              onTap: () {},
            ),
            _SettingsTile(
              icon: Icons.mic_rounded,
              label: 'Voice Clip Settings',
              onTap: () {},
            ),
            _SettingsToggleTile(
              icon: Icons.vibration_rounded,
              label: 'Shake to Alert',
              subtitle: 'Shake phone to trigger emergency',
              value: widget.shakeDetectionEnabled,
              onToggle: widget.onShakeDetectionChanged,
            ),
            _SettingsSliderTile(
              icon: Icons.tune_rounded,
              label: 'Shake Sensitivity',
              value: widget.shakeSensitivity,
              enabled: widget.shakeDetectionEnabled,
              onChanged: widget.onShakeSensitivityChanged,
            ),
            _SettingsTile(
              icon: Icons.shield_rounded,
              label: 'AI Distress Detection',
              onTap: () {},
            ),
            _SettingsTile(
              icon: Icons.info_rounded,
              label: 'About Voisa',
              onTap: () {},
            ),
            const SizedBox(height: AppSpacing.lg),
            _SettingsTile(
              icon: Icons.logout_rounded,
              label: 'Log out',
              color: AppColors.textSecondary,
              showChevron: false,
              onTap: _logout,
            ),
            _SettingsTile(
              icon: Icons.delete_forever_rounded,
              label:
                  _isDeletingAccount ? 'Deleting account...' : 'Delete account',
              color: AppColors.error,
              showChevron: false,
              onTap: _isDeletingAccount ? () {} : _deleteAccount,
            ),
          ],
        ),
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  const _SettingsTile({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color = AppColors.primary,
    this.showChevron = true,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color color;
  final bool showChevron;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          onTap: onTap,
          contentPadding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.xs, vertical: AppSpacing.xs),
          leading: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(AppRadius.sm),
            ),
            child: Icon(icon, size: 20, color: color),
          ),
          title: Text(label, style: AppTextStyles.body.copyWith(color: color)),
          trailing: showChevron
              ? const Icon(Icons.chevron_right_rounded,
                  size: 20, color: AppColors.textSecondary)
              : null,
        ),
        const Divider(color: AppColors.divider, thickness: 0.8, height: 1),
      ],
    );
  }
}

class _SettingsToggleTile extends StatelessWidget {
  const _SettingsToggleTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.value,
    required this.onToggle,
  });

  final IconData icon;
  final String label;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onToggle;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          contentPadding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.xs, vertical: AppSpacing.xs),
          leading: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(AppRadius.sm),
            ),
            child: Icon(icon, size: 20, color: AppColors.primary),
          ),
          title: Text(label, style: AppTextStyles.body),
          subtitle: Text(
            subtitle,
            style: AppTextStyles.caption.copyWith(fontSize: 12),
          ),
          trailing: Switch(
            value: value,
            onChanged: onToggle,
            activeThumbColor: AppColors.primary,
          ),
        ),
        const Divider(color: AppColors.divider, thickness: 0.8, height: 1),
      ],
    );
  }
}

class _SettingsSliderTile extends StatelessWidget {
  const _SettingsSliderTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.enabled,
    required this.onChanged,
  });

  final IconData icon;
  final String label;
  final double value;
  final bool enabled;
  final ValueChanged<double> onChanged;

  String get _sensitivityLabel {
    if (value < 0.25) return 'Low';
    if (value < 0.5) return 'Moderate';
    if (value < 0.75) return 'High';
    return 'Very high';
  }

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.55,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.xs,
              vertical: AppSpacing.sm,
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(AppRadius.sm),
                      ),
                      child: Icon(icon, size: 20, color: AppColors.primary),
                    ),
                    const SizedBox(width: AppSpacing.md),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(label, style: AppTextStyles.body),
                          Text(
                            enabled
                                ? _sensitivityLabel
                                : 'Turn on shake alerts',
                            style: AppTextStyles.caption.copyWith(fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 72,
                      child: Text(
                        '${(value * 100).round()}%',
                        textAlign: TextAlign.end,
                        style: AppTextStyles.caption.copyWith(
                          color: AppColors.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                Slider(
                  value: value
                      .clamp(
                        ShakeDetectorService.minShakeSensitivity,
                        ShakeDetectorService.maxShakeSensitivity,
                      )
                      .toDouble(),
                  min: ShakeDetectorService.minShakeSensitivity,
                  max: ShakeDetectorService.maxShakeSensitivity,
                  divisions: 4,
                  label: _sensitivityLabel,
                  activeColor: AppColors.primary,
                  inactiveColor: AppColors.divider,
                  onChanged: enabled ? onChanged : null,
                ),
              ],
            ),
          ),
          const Divider(color: AppColors.divider, thickness: 0.8, height: 1),
        ],
      ),
    );
  }
}
