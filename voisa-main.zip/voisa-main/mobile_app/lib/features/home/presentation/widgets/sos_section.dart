import 'dart:async';
import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import '../../data/sos_service.dart';

// ─── SOS Flow State ───────────────────────────────────────────────────────────
//
// Idle  ──tap──►  Countdown(3)  ──tick──►  Countdown(2)  ──tick──►  Countdown(1)
//                     │                                                    │
//                   Cancel                                      auto-fires ▼
//                     │                          Send (any step) ──►    Sent
//                     ▼                                                    │
//                   Idle  ◄──Yes──  CancelConfirm  ◄──Cancel──────────────┘
//                                        │
//                                       No
//                                        ▼
//                                       Sent

typedef SendSosCallback = Future<SosAlertResult> Function();
typedef CancelSosCallback = Future<void> Function(String eventId);

enum _SosPhase { idle, countdown, sending, sent, cancelConfirm, error }

// ─── Public card — rendered in the home screen scroll ─────────────────────────
class SosTriggerCard extends StatelessWidget {
  const SosTriggerCard({super.key, required this.onSosTapped});

  final VoidCallback onSosTapped;

  @override
  Widget build(BuildContext context) {
    return VoisaCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.md,
        vertical: AppSpacing.lg,
      ),
      child: SizedBox(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Are you in danger?', style: AppTextStyles.cardTitle),
            const SizedBox(height: 0),
            Text(
              'Alert all emergency contacts now',
              style: AppTextStyles.cardSubtitle,
            ),
            const SizedBox(height: AppSpacing.md),
            _SosRingButton(onTap: onSosTapped),
            const SizedBox(height: AppSpacing.md),
          ],
        ),
      ),
    );
  }
}

// ─── Ring button — no state, purely display ───────────────────────────────────
class _SosRingButton extends StatelessWidget {
  const _SosRingButton({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 306,
        height: 306,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: AppColors.emergency, width: 2.5),
          color: AppColors.surface,
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Tap to',
                style: AppTextStyles.body.copyWith(
                  color: AppColors.primary,
                  fontSize: 22,
                ),
              ),
              Text(
                'SOS',
                style: AppTextStyles.displayLarge.copyWith(
                  color: AppColors.primary,
                  fontSize: 32,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Public entry point — call this when the SOS button is tapped ─────────────
Future<void> showSosBottomSheet(
  BuildContext context, {
  int contactCount = 3,
  required SendSosCallback onSendSos,
  required CancelSosCallback onCancelSos,
}) {
  return showModalBottomSheet(
    context: context,
    isDismissible: false, // intentional — user must make a decision
    enableDrag: false, // no accidental drag-to-dismiss in an emergency
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withValues(alpha: 0.6),
    builder: (_) => _SosBottomSheet(
      contactCount: contactCount,
      onSendSos: onSendSos,
      onCancelSos: onCancelSos,
    ),
  );
}

// ─── Bottom Sheet — owns timer and all phase transitions ──────────────────────
class _SosBottomSheet extends StatefulWidget {
  const _SosBottomSheet({
    required this.contactCount,
    required this.onSendSos,
    required this.onCancelSos,
  });

  final int contactCount;
  final SendSosCallback onSendSos;
  final CancelSosCallback onCancelSos;

  @override
  State<_SosBottomSheet> createState() => _SosBottomSheetState();
}

class _SosBottomSheetState extends State<_SosBottomSheet> {
  _SosPhase _phase = _SosPhase.countdown;
  int _secondsLeft = 3;
  int? _sentContactCount;
  String? _eventId;
  String? _errorMessage;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startCountdown();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // ── Timer ─────────────────────────────────────────────────────────────────────

  void _startCountdown() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      if (_secondsLeft <= 1) {
        t.cancel();
        _sendSos();
      } else {
        setState(() => _secondsLeft--);
      }
    });
  }

  Future<void> _sendSos() async {
    _timer?.cancel();
    setState(() {
      _phase = _SosPhase.sending;
      _errorMessage = null;
    });

    try {
      final result = await widget.onSendSos();
      if (!mounted) return;
      setState(() {
        _eventId = result.eventId;
        _sentContactCount = result.squadAlertedCount;
        _phase = _SosPhase.sent;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = e.toString();
        _phase = _SosPhase.error;
      });
    }
  }

  // ── Actions ───────────────────────────────────────────────────────────────────

  void _onCancelCountdown() {
    _timer?.cancel();
    // Nothing was sent — safe to close immediately
    if (mounted) Navigator.of(context).pop();
  }

  void _onSendNow() {
    _timer?.cancel();
    _sendSos();
  }

  void _onCancelSent() {
    // Alert already sent — ask for confirmation before recalling
    setState(() => _phase = _SosPhase.cancelConfirm);
  }

  Future<void> _onConfirmCancel() async {
    final eventId = _eventId;
    if (eventId == null) {
      if (mounted) Navigator.of(context).pop();
      return;
    }

    try {
      await widget.onCancelSos(eventId);
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = e.toString();
        _phase = _SosPhase.error;
      });
    }
  }

  void _onDenyCancel() {
    // User chose "No" — go back to Sent state
    setState(() => _phase = _SosPhase.sent);
  }

  // ── Build ─────────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          gradient: AppColors.emergencyGradient,
          borderRadius: BorderRadius.circular(AppRadius.xl),
        ),
        padding: EdgeInsets.only(
          left: AppSpacing.lg,
          right: AppSpacing.lg,
          top: AppSpacing.lg,
          bottom: AppSpacing.lg + bottomPadding,
        ),
        child: _buildPhaseContent(),
      ),
    );
  }

  Widget _buildPhaseContent() {
    switch (_phase) {
      case _SosPhase.countdown:
        return _CountdownContent(
          secondsLeft: _secondsLeft,
          onCancel: _onCancelCountdown,
          onSend: _onSendNow,
        );
      case _SosPhase.sending:
        return const _SendingContent();
      case _SosPhase.sent:
        return _SentContent(
          contactCount: _sentContactCount ?? widget.contactCount,
          onCancel: _onCancelSent,
        );
      case _SosPhase.cancelConfirm:
        return _CancelConfirmContent(
          onConfirm: _onConfirmCancel,
          onDeny: _onDenyCancel,
        );
      case _SosPhase.idle:
        return const SizedBox.shrink();
      case _SosPhase.error:
        return _ErrorContent(
          message: _errorMessage ?? 'Unable to send alert.',
          onRetry: _sendSos,
          onClose: () => Navigator.of(context).pop(),
        );
    }
  }
}

// ─── Countdown content ────────────────────────────────────────────────────────
class _CountdownContent extends StatelessWidget {
  const _CountdownContent({
    required this.secondsLeft,
    required this.onCancel,
    required this.onSend,
  });

  final int secondsLeft;
  final VoidCallback onCancel;
  final VoidCallback onSend;

  @override
  Widget build(BuildContext context) {
    final label = secondsLeft == 1 ? 'second' : 'seconds';
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Your emergency contacts will be alerted in $secondsLeft $label',
          style: AppTextStyles.sosHeading,
        ),
        const SizedBox(height: AppSpacing.lg),
        Row(
          children: [
            Expanded(
              child: _SosButton(
                label: 'Cancel',
                isOutlined: true,
                onTap: onCancel,
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: _SosButton(
                label: 'Send',
                isOutlined: false,
                onTap: onSend,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ─── Sending content ─────────────────────────────────────────────────────────
class _SendingContent extends StatelessWidget {
  const _SendingContent();

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Sending alert...', style: AppTextStyles.sosHeading),
        const SizedBox(height: 4),
        Text(
          'Sharing your location with the safety server',
          style: AppTextStyles.sosSubheading,
        ),
        const SizedBox(height: AppSpacing.lg),
        ClipRRect(
          borderRadius: BorderRadius.circular(AppRadius.pill),
          child: const LinearProgressIndicator(
            minHeight: 10,
            backgroundColor: Colors.white24,
            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
          ),
        ),
      ],
    );
  }
}

// ─── Sent content ─────────────────────────────────────────────────────────────
class _SentContent extends StatelessWidget {
  const _SentContent({required this.contactCount, required this.onCancel});

  final int contactCount;
  final VoidCallback onCancel;

  @override
  Widget build(BuildContext context) {
    final sub = contactCount == 1
        ? '1 contact was alerted'
        : '$contactCount contacts were alerted';

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Help is on the way', style: AppTextStyles.sosHeading),
        const SizedBox(height: 4),
        Text(sub, style: AppTextStyles.sosSubheading),
        const SizedBox(height: AppSpacing.lg),
        SizedBox(
          width: double.infinity,
          child: _SosButton(
            label: 'Cancel',
            isOutlined: true,
            onTap: onCancel,
          ),
        ),
      ],
    );
  }
}

// ─── Error content ────────────────────────────────────────────────────────────
class _ErrorContent extends StatelessWidget {
  const _ErrorContent({
    required this.message,
    required this.onRetry,
    required this.onClose,
  });

  final String message;
  final VoidCallback onRetry;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Alert not sent', style: AppTextStyles.sosHeading),
        const SizedBox(height: 4),
        Text(message, style: AppTextStyles.sosSubheading),
        const SizedBox(height: AppSpacing.lg),
        Row(
          children: [
            Expanded(
              child: _SosButton(
                label: 'Close',
                isOutlined: true,
                onTap: onClose,
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: _SosButton(
                label: 'Retry',
                isOutlined: false,
                onTap: onRetry,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ─── Cancel confirmation content ──────────────────────────────────────────────
class _CancelConfirmContent extends StatelessWidget {
  const _CancelConfirmContent({
    required this.onConfirm,
    required this.onDeny,
  });

  final VoidCallback onConfirm;
  final VoidCallback onDeny;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Are you sure?', style: AppTextStyles.sosHeading),
        const SizedBox(height: AppSpacing.lg),
        Row(
          children: [
            Expanded(
              child: _SosButton(
                label: 'Yes',
                isOutlined: false,
                onTap: onConfirm,
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: _SosButton(
                label: 'No',
                isOutlined: true,
                onTap: onDeny,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ─── Shared button — used across all SOS sheet phases ─────────────────────────
class _SosButton extends StatelessWidget {
  const _SosButton({
    required this.label,
    required this.isOutlined,
    required this.onTap,
  });

  final String label;
  final bool isOutlined;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(AppRadius.pill),
    );

    if (isOutlined) {
      return OutlinedButton(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 24),
          side: const BorderSide(color: Colors.white, width: 1.5),
          shape: shape,
        ),
        child: Text(
          label,
          style: AppTextStyles.sosButtonLabel.copyWith(color: Colors.white),
        ),
      );
    }

    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: AppColors.emergency,
        elevation: 0,
        padding: const EdgeInsets.symmetric(vertical: 16),
        shape: shape,
      ),
      child: Text(
        label,
        style: AppTextStyles.sosButtonLabel.copyWith(
          color: AppColors.emergency,
        ),
      ),
    );
  }
}
