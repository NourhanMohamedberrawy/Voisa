import 'dart:async';
import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../data/sos_service.dart';

typedef SendDistressAlertCallback = Future<SosAlertResult> Function();
typedef MarkSafeCallback = Future<void> Function(String eventId);

// ─── Phase Enum ───────────────────────────────────────────────────────────────
enum _DistressPhase {
  detected, // "Distress detected" countdown card
  cancelConfirm, // "Cancel alert?" confirmation
  sending, // "Sending alert..." progress card
  notified, // "Emergency contacts notified"
  failed, // backend or location error
}

// ─── Public Entry Point ───────────────────────────────────────────────────────
/// Call this when the AI detects distress (or from the debug trigger).
/// [contactCount] will come from your contacts repository.
/// [userName] / [userImageUrl] are used for the map pin avatar.
Future<void> showDistressAlertSheet(
  BuildContext context, {
  int contactCount = 3,
  String userName = 'there',
  String? userImageUrl,
  required SendDistressAlertCallback onSendAlert,
  required MarkSafeCallback onMarkSafe,
}) {
  return showModalBottomSheet(
    context: context,
    isDismissible: false,
    enableDrag: false,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withValues(alpha: 0.65),
    builder: (_) => _DistressAlertSheet(
      contactCount: contactCount,
      userName: userName,
      userImageUrl: userImageUrl,
      onSendAlert: onSendAlert,
      onMarkSafe: onMarkSafe,
    ),
  );
}

// ─── Sheet Widget ─────────────────────────────────────────────────────────────
class _DistressAlertSheet extends StatefulWidget {
  const _DistressAlertSheet({
    required this.contactCount,
    required this.userName,
    required this.onSendAlert,
    required this.onMarkSafe,
    this.userImageUrl,
  });

  final int contactCount;
  final String userName;
  final String? userImageUrl;
  final SendDistressAlertCallback onSendAlert;
  final MarkSafeCallback onMarkSafe;

  @override
  State<_DistressAlertSheet> createState() => _DistressAlertSheetState();
}

class _DistressAlertSheetState extends State<_DistressAlertSheet> {
  _DistressPhase _phase = _DistressPhase.detected;
  int _secondsLeft = 5;
  double _sendingProgress = 0.0;
  int? _sentContactCount;
  String? _eventId;
  String? _errorMessage;
  Timer? _countdownTimer;
  Timer? _progressTimer;

  @override
  void initState() {
    super.initState();
    _startCountdown();
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _progressTimer?.cancel();
    super.dispose();
  }

  // ── Countdown ─────────────────────────────────────────────────────────────

  void _startCountdown() {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      if (_secondsLeft <= 1) {
        t.cancel();
        _triggerSend();
      } else {
        setState(() => _secondsLeft--);
      }
    });
  }

  // ── Actions ───────────────────────────────────────────────────────────────

  void _onCancel() {
    _countdownTimer?.cancel();
    setState(() => _phase = _DistressPhase.cancelConfirm);
  }

  void _onSendAlert() {
    _countdownTimer?.cancel();
    _triggerSend();
  }

  void _onYesCancel() {
    // False alarm — dismiss entirely, return to normal app state
    if (mounted) Navigator.of(context).pop();
  }

  void _onNoSendAlert() {
    // User changed their mind — send immediately
    _triggerSend();
  }

  void _triggerSend() {
    setState(() {
      _phase = _DistressPhase.sending;
      _sendingProgress = 0.0;
    });
    _startSendingProgress();
  }

  void _startSendingProgress() {
    _progressTimer?.cancel();
    // Animate progress from 0→1 over ~2 seconds (40 ticks × 50ms)
    int ticks = 0;
    const totalTicks = 40;
    _progressTimer =
        Timer.periodic(const Duration(milliseconds: 50), (t) async {
      if (!mounted) {
        t.cancel();
        return;
      }
      ticks++;
      setState(() => _sendingProgress = ticks / totalTicks);
      if (ticks >= totalTicks) {
        t.cancel();
        await _sendAlertToBackend();
      }
    });
  }

  Future<void> _sendAlertToBackend() async {
    try {
      final result = await widget.onSendAlert();
      if (!mounted) return;
      setState(() {
        _eventId = result.eventId;
        _sentContactCount = result.squadAlertedCount;
        _phase = _DistressPhase.notified;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = e.toString();
        _phase = _DistressPhase.failed;
      });
    }
  }

  Future<void> _onMarkAsSafe() async {
    final eventId = _eventId;
    if (eventId != null) {
      try {
        await widget.onMarkSafe(eventId);
      } catch (_) {
        // The user is safe locally; backend retry can be added later.
      }
    }
    if (mounted) Navigator.of(context).pop();
  }

  void _onViewAlert() {
    // TODO: Navigate to the active alert detail screen
    // Placeholder: dismiss for now
    if (mounted) Navigator.of(context).pop();
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.all(AppSpacing.md),
        decoration: BoxDecoration(
          gradient: AppColors.emergencyGradient,
          borderRadius: BorderRadius.circular(AppRadius.xl),
        ),
        padding: EdgeInsets.only(
          left: AppSpacing.lg,
          right: AppSpacing.lg,
          top: AppSpacing.lg,
          bottom: AppSpacing.lg + bottomPadding,
        ),
        child: _buildPhase(),
      ),
    );
  }

  Widget _buildPhase() {
    switch (_phase) {
      case _DistressPhase.detected:
        return _DetectedContent(
          secondsLeft: _secondsLeft,
          userName: widget.userName,
          userImageUrl: widget.userImageUrl,
          onCancel: _onCancel,
          onSendAlert: _onSendAlert,
        );
      case _DistressPhase.cancelConfirm:
        return _CancelConfirmContent(
          onYesCancel: _onYesCancel,
          onNoSendAlert: _onNoSendAlert,
        );
      case _DistressPhase.sending:
        return _SendingContent(progress: _sendingProgress);
      case _DistressPhase.notified:
        return _NotifiedContent(
          contactCount: _sentContactCount ?? widget.contactCount,
          onViewAlert: _onViewAlert,
          onMarkAsSafe: _onMarkAsSafe,
        );
      case _DistressPhase.failed:
        return _FailedContent(
          message: _errorMessage ?? 'Unable to send alert.',
          onRetry: _triggerSend,
          onCancel: () => Navigator.of(context).pop(),
        );
    }
  }
}

// ─── Phase 1: Distress Detected ───────────────────────────────────────────────
class _DetectedContent extends StatelessWidget {
  const _DetectedContent({
    required this.secondsLeft,
    required this.userName,
    this.userImageUrl,
    required this.onCancel,
    required this.onSendAlert,
  });

  final int secondsLeft;
  final String userName;
  final String? userImageUrl;
  final VoidCallback onCancel;
  final VoidCallback onSendAlert;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Title
        Text('Distress detected', style: AppTextStyles.sosHeading),
        const SizedBox(height: 4),

        // Countdown subtitle
        RichText(
          text: TextSpan(
            style: AppTextStyles.sosSubheading,
            children: [
              const TextSpan(text: 'Automatic alert in '),
              TextSpan(
                text: '$secondsLeft seconds',
                style: AppTextStyles.sosSubheading.copyWith(
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: AppSpacing.md),

        // Map preview with user avatar pin
        _MapWithPin(userName: userName, userImageUrl: userImageUrl),
        const SizedBox(height: AppSpacing.md),

        // Info line
        Text(
          'Your location and recent audio snippet will be sent',
          style: AppTextStyles.sosSubheading,
        ),
        const SizedBox(height: AppSpacing.lg),

        // Buttons
        Row(
          children: [
            Expanded(
              child: _DistressButton(
                label: 'Cancel',
                isOutlined: true,
                onTap: onCancel,
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: _DistressButton(
                label: 'Send alert',
                isOutlined: false,
                onTap: onSendAlert,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ─── Map Placeholder with Avatar Pin ─────────────────────────────────────────
class _MapWithPin extends StatelessWidget {
  const _MapWithPin({required this.userName, this.userImageUrl});

  final String userName;
  final String? userImageUrl;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(AppRadius.md),
      child: Container(
        height: 200,
        width: double.infinity,
        // Neutral map-like background — replace with real map widget later
        color: const Color(0xFFD6E4D0),
        child: Stack(
          children: [
            // Grid lines to suggest a map
            CustomPaint(
              size: const Size(double.infinity, 200),
              painter: _MapGridPainter(),
            ),
            // Center pin with avatar
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.emergency, width: 3),
                      color: AppColors.surfaceDark,
                    ),
                    child: ClipOval(
                      child: userImageUrl != null
                          ? Image.network(userImageUrl!, fit: BoxFit.cover)
                          : Center(
                              child: Text(
                                userName.isNotEmpty
                                    ? userName[0].toUpperCase()
                                    : '?',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Simple grid painter to give a map-like appearance
class _MapGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final roadPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.85)
      ..strokeWidth = 8
      ..style = PaintingStyle.stroke;

    final minorPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.5)
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke;

    // Major horizontal roads
    for (final y in [40.0, 95.0, 155.0]) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), roadPaint);
    }
    // Major vertical roads
    for (final x in [60.0, 140.0, 230.0, 310.0]) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), roadPaint);
    }
    // Minor roads
    for (final y in [20.0, 65.0, 120.0, 175.0]) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), minorPaint);
    }
    for (final x in [20.0, 100.0, 185.0, 270.0, 360.0]) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), minorPaint);
    }

    // Green park patch
    final parkPaint = Paint()
      ..color = const Color(0xFFA8C89A).withValues(alpha: 0.6)
      ..style = PaintingStyle.fill;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(155, 50, 70, 80),
        const Radius.circular(6),
      ),
      parkPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ─── Phase 2: Cancel Confirmation ────────────────────────────────────────────
class _CancelConfirmContent extends StatelessWidget {
  const _CancelConfirmContent({
    required this.onYesCancel,
    required this.onNoSendAlert,
  });

  final VoidCallback onYesCancel;
  final VoidCallback onNoSendAlert;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Cancel alert?', style: AppTextStyles.sosHeading),
        const SizedBox(height: AppSpacing.lg),
        Row(
          children: [
            Expanded(
              child: _DistressButton(
                label: 'Yes, cancel',
                isOutlined: false,
                onTap: onYesCancel,
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: _DistressButton(
                label: 'No, send alert',
                isOutlined: true,
                onTap: onNoSendAlert,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ─── Phase 3: Sending ─────────────────────────────────────────────────────────
class _SendingContent extends StatelessWidget {
  const _SendingContent({required this.progress});
  final double progress;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Sending alert...', style: AppTextStyles.sosHeading),
        const SizedBox(height: 4),
        Text(
          'Sending location, audio, and notifying contacts',
          style: AppTextStyles.sosSubheading,
        ),
        const SizedBox(height: AppSpacing.lg),
        ClipRRect(
          borderRadius: BorderRadius.circular(AppRadius.pill),
          child: LinearProgressIndicator(
            value: progress,
            minHeight: 10,
            backgroundColor: Colors.white.withValues(alpha: 0.25),
            valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
          ),
        ),
        const SizedBox(height: AppSpacing.sm),
      ],
    );
  }
}

// ─── Phase 4: Notified ────────────────────────────────────────────────────────
class _NotifiedContent extends StatelessWidget {
  const _NotifiedContent({
    required this.contactCount,
    required this.onViewAlert,
    required this.onMarkAsSafe,
  });

  final int contactCount;
  final VoidCallback onViewAlert;
  final VoidCallback onMarkAsSafe;

  @override
  Widget build(BuildContext context) {
    final sub = contactCount == 1
        ? '1 contact was alerted'
        : '$contactCount contacts were alerted';

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Emergency contacts notified', style: AppTextStyles.sosHeading),
        const SizedBox(height: 4),
        Text(sub, style: AppTextStyles.sosSubheading),
        const SizedBox(height: AppSpacing.lg),
        Row(
          children: [
            Expanded(
              child: _DistressButton(
                label: 'View alert',
                isOutlined: false,
                onTap: onViewAlert,
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: _DistressButton(
                label: 'Mark as safe',
                isOutlined: true,
                onTap: onMarkAsSafe,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ─── Failed ──────────────────────────────────────────────────────────────────
class _FailedContent extends StatelessWidget {
  const _FailedContent({
    required this.message,
    required this.onRetry,
    required this.onCancel,
  });

  final String message;
  final VoidCallback onRetry;
  final VoidCallback onCancel;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Alert not sent', style: AppTextStyles.sosHeading),
        const SizedBox(height: 4),
        Text(message, style: AppTextStyles.sosSubheading),
        const SizedBox(height: AppSpacing.lg),
        Row(
          children: [
            Expanded(
              child: _DistressButton(
                label: 'Cancel',
                isOutlined: true,
                onTap: onCancel,
              ),
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: _DistressButton(
                label: 'Retry',
                isOutlined: false,
                onTap: onRetry,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

// ─── Shared Button ────────────────────────────────────────────────────────────
/// Mirrors _SosButton in sos_section.dart — same visual language.
class _DistressButton extends StatelessWidget {
  const _DistressButton({
    required this.label,
    required this.isOutlined,
    required this.onTap,
  });

  final String label;
  final bool isOutlined;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(AppRadius.pill),
    );
    if (isOutlined) {
      return OutlinedButton(
        onPressed: onTap,
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 18),
          side: const BorderSide(color: Colors.white, width: 1.5),
          shape: shape,
        ),
        child: Text(
          label,
          style: AppTextStyles.sosButtonLabel.copyWith(color: Colors.white),
        ),
      );
    }
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        foregroundColor: AppColors.emergency,
        elevation: 0,
        padding: const EdgeInsets.symmetric(vertical: 18),
        shape: shape,
      ),
      child: Text(
        label,
        style: AppTextStyles.sosButtonLabel.copyWith(
          color: AppColors.emergency,
        ),
      ),
    );
  }
}
