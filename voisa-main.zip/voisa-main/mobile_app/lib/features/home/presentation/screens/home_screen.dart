// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import '../widgets/sos_section.dart';
import '../widgets/distress_alert_sheet.dart';
import '../../data/distress_detector_service.dart';
import '../../data/shake_detector_service.dart';
import '../../data/sos_service.dart';

// ─── Temporary data model ─────────────────────────────────────────────────────
// TODO: replace with a real model from your data layer
class ActiveAlert {
  const ActiveAlert({
    required this.name,
    required this.relation,
    required this.timeAgo,
    this.imageUrl,
  });
  final String name;
  final String relation;
  final String timeAgo;
  final String? imageUrl;
}

// ─── Home Screen ──────────────────────────────────────────────────────────────
class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    this.shakeDetectionEnabled = true,
    this.shakeSensitivity = ShakeDetectorService.defaultShakeSensitivity,
  });

  final bool shakeDetectionEnabled;
  final double shakeSensitivity;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // TODO: Replace with state from provider/bloc
  final List<ActiveAlert> _alerts = [];
  final SosService _sosService = SosService();
  late final DistressDetectorService _voiceDetector;
  late final ShakeDetectorService _shakeDetector;
  String _userName = 'there';

  @override
  void initState() {
    super.initState();
    _loadUserName();

    // Voice detection (Porcupine)
    _voiceDetector = DistressDetectorService(
      onDetected: _onVoiceDistressDetected,
    );
    _voiceDetector.start();

    _shakeDetector = ShakeDetectorService(
      onShake: _onShakeDistressDetected,
      shakeThreshold: ShakeDetectorService.thresholdForSensitivity(
        widget.shakeSensitivity,
      ),
    );

    if (widget.shakeDetectionEnabled) {
      _shakeDetector.start();
    }
  }

  Future<void> _loadUserName() async {
    final name = await AuthService.instance.getName();
    if (!mounted) return;
    setState(() => _userName = (name == null || name.isEmpty) ? 'there' : name);
  }

  @override
  void didUpdateWidget(covariant HomeScreen oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.shakeSensitivity != widget.shakeSensitivity) {
      _shakeDetector.updateSensitivity(widget.shakeSensitivity);
    }

    if (oldWidget.shakeDetectionEnabled != widget.shakeDetectionEnabled) {
      if (widget.shakeDetectionEnabled) {
        _shakeDetector.start();
      } else {
        _shakeDetector.stop();
      }
    }
  }

  @override
  void dispose() {
    _voiceDetector.stop();
    _shakeDetector.stop();
    super.dispose();
  }

  Future<void> _onVoiceDistressDetected() async {
    if (!mounted) return;

    // Mark both detectors as having sheet open
    _voiceDetector.markSheetOpen();
    _shakeDetector.markSheetOpen();

    await showDistressAlertSheet(
      context,
      contactCount: 3,
      userName: _userName,
      onSendAlert: () => _sosService.triggerAlert(triggerType: 'keyword'),
      onMarkSafe: _sosService.cancelAlert,
    );

    // Mark both as closed when done
    _voiceDetector.markSheetClosed();
    _shakeDetector.markSheetClosed();
  }

  Future<void> _onShakeDistressDetected() async {
    if (!mounted) return;

    // Mark both detectors as having sheet open
    _voiceDetector.markSheetOpen();
    _shakeDetector.markSheetOpen();

    await showDistressAlertSheet(
      context,
      contactCount: 3,
      userName: _userName,
      onSendAlert: () => _sosService.triggerAlert(triggerType: 'shake'),
      onMarkSafe: _sosService.cancelAlert,
    );

    // Mark both as closed when done
    _voiceDetector.markSheetClosed();
    _shakeDetector.markSheetClosed();
  }

  void _onSosTapped() {
    showSosBottomSheet(
      context,
      contactCount: 3,
      onSendSos: () => _sosService.triggerAlert(triggerType: 'manual'),
      onCancelSos: _sosService.cancelAlert,
    );
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.only(
          top: topPadding + AppSpacing.md,
          left: AppSpacing.screenH,
          right: AppSpacing.screenH,
          bottom: AppSpacing.xl,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Greeting ─────────────────────────────────────────────────
            _GreetingRow(
              userName: _userName,
              onSimulateDistress: () async {
                await showDistressAlertSheet(
                  context,
                  contactCount: 3,
                  userName: _userName,
                  onSendAlert: () =>
                      _sosService.triggerAlert(triggerType: 'keyword'),
                  onMarkSafe: _sosService.cancelAlert,
                );
              },
            ),
            const SizedBox(height: AppSpacing.lg),

            // ── Active Alerts ─────────────────────────────────────────────
            if (_alerts.isNotEmpty) ...[
              const SectionHeader(title: 'Active Alerts'),
              const SizedBox(height: AppSpacing.md),
              ..._alerts.map(
                (alert) => Padding(
                  padding: const EdgeInsets.only(bottom: AppSpacing.md),
                  child: _ActiveAlertCard(
                    alert: alert,
                    onDismiss: () => setState(
                      () => _alerts.removeWhere((a) => a.name == alert.name),
                    ),
                    onLocation: () {
                      // TODO: url_launcher → Google Maps with contact's location
                    },
                    onCall: () {
                      // TODO: url_launcher → tel:<number>
                    },
                  ),
                ),
              ),
              const SizedBox(height: AppSpacing.md),
            ],

            // ── Quick Actions / SOS ───────────────────────────────────────
            const SectionHeader(title: 'Quick Actions'),
            const SizedBox(height: AppSpacing.md),
            SosTriggerCard(onSosTapped: _onSosTapped),
          ],
        ),
      ),
    );
  }
}

// ─── Greeting Row ─────────────────────────────────────────────────────────────
class _GreetingRow extends StatelessWidget {
  const _GreetingRow({
    required this.userName,
    required this.onSimulateDistress, // ← new
  });

  final String userName;
  final VoidCallback onSimulateDistress; // ← new

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Hello,',
              style: AppTextStyles.body.copyWith(
                fontWeight: FontWeight.w900,
                fontSize: 16,
                color: AppColors.textPrimary,
              ),
            ),
            Text(
              userName,
              style: AppTextStyles.body.copyWith(
                fontSize: 16,
                color: AppColors.textSecondary,
              ),
            ),
          ],
        ),

        // Right side: debug trigger + avatar
        Row(
          children: [
            // ── DEBUG TRIGGER ── remove before shipping ──────────────────
            Tooltip(
              message: 'Simulate distress detection',
              child: GestureDetector(
                onTap: onSimulateDistress,
                child: Container(
                  width: 38,
                  height: 38,
                  margin: const EdgeInsets.only(right: AppSpacing.sm),
                  decoration: BoxDecoration(
                    color: AppColors.emergency.withValues(alpha: 0.12),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppColors.emergency.withValues(alpha: 0.4),
                      width: 1.2,
                    ),
                  ),
                  child: const Icon(
                    Icons.mic_rounded,
                    size: 18,
                    color: AppColors.emergency,
                  ),
                ),
              ),
            ),
            // ── END DEBUG TRIGGER ────────────────────────────────────────
            ContactAvatar(
              name: userName,
              radius: 22,
              color: AppColors.primary,
            ),
          ],
        ),
      ],
    );
  }
}

// ─── Active Alert Card ────────────────────────────────────────────────────────
class _ActiveAlertCard extends StatefulWidget {
  const _ActiveAlertCard({
    required this.alert,
    required this.onDismiss,
    required this.onLocation,
    required this.onCall,
  });

  final ActiveAlert alert;
  final VoidCallback onDismiss;
  final VoidCallback onLocation;
  final VoidCallback onCall;

  @override
  State<_ActiveAlertCard> createState() => _ActiveAlertCardState();
}

class _ActiveAlertCardState extends State<_ActiveAlertCard> {
  bool _isPlaying = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: AppColors.emergencyGradient,
        borderRadius: BorderRadius.circular(AppRadius.lg),
      ),
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              ContactAvatar(
                imageUrl: widget.alert.imageUrl,
                name: widget.alert.name,
                radius: 22,
                color: AppColors.primaryDark,
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.alert.name,
                      style: AppTextStyles.emergencyTitle,
                    ),
                    Text(
                      widget.alert.relation,
                      style: AppTextStyles.emergencyRelation,
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: widget.onDismiss,
                child: Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: AppColors.emergencyLight.withValues(alpha: 0.5),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.close_rounded,
                    size: 16,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),

          // Alert body
          RichText(
            text: TextSpan(
              style: AppTextStyles.emergencyBody,
              children: [
                const TextSpan(text: 'Activated the '),
                TextSpan(
                  text: 'SOS',
                  style: AppTextStyles.emergencyBody.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const TextSpan(text: ' button'),
              ],
            ),
          ),
          Text(widget.alert.timeAgo, style: AppTextStyles.emergencySubtitle),
          const SizedBox(height: AppSpacing.md),

          // Voice clip row
          Row(
            children: [
              const Expanded(child: WaveformBar(color: Colors.white)),
              const SizedBox(width: AppSpacing.md),
              GestureDetector(
                onTap: () => setState(() => _isPlaying = !_isPlaying),
                child: Icon(
                  _isPlaying
                      ? Icons.pause_circle_filled_rounded
                      : Icons.play_circle_filled_rounded,
                  color: Colors.white,
                  size: 36,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),

          // Location / Call buttons
          Row(
            children: [
              Expanded(
                child: _AlertActionButton(
                  label: 'Location',
                  icon: Icons.location_on_rounded,
                  isOutlined: true,
                  onTap: widget.onLocation,
                ),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: _AlertActionButton(
                  label: 'Call Now',
                  icon: Icons.phone_rounded,
                  isOutlined: false,
                  onTap: widget.onCall,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AlertActionButton extends StatelessWidget {
  const _AlertActionButton({
    required this.label,
    required this.icon,
    required this.isOutlined,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final bool isOutlined;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(AppRadius.pill),
    );
    return SizedBox(
      height: 44,
      child: isOutlined
          ? OutlinedButton.icon(
              onPressed: onTap,
              icon: Icon(icon, size: 16, color: Colors.white),
              label: Text(
                label,
                style: AppTextStyles.buttonLabel.copyWith(
                  color: Colors.white,
                  fontSize: 14,
                ),
              ),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.white, width: 1.5),
                shape: shape,
              ),
            )
          : ElevatedButton.icon(
              onPressed: onTap,
              icon: Icon(icon, size: 16, color: Colors.white),
              label: Text(
                label,
                style: AppTextStyles.buttonLabel.copyWith(
                  color: Colors.white,
                  fontSize: 14,
                ),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white.withValues(alpha: 0.2),
                foregroundColor: Colors.white,
                elevation: 0,
                shape: shape,
              ),
            ),
    );
  }
}
