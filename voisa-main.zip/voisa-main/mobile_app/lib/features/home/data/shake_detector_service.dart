import 'dart:async';
import 'dart:math' show sqrt;
import 'package:flutter/services.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../../../../core/utils/app_logger.dart';

// ─── Shake Detector Service ───────────────────────────────────────────────────
// Detects intentional phone shakes using accelerometer data.
// Guards against false positives with intensity threshold and cooldown.
//
// Usage:
//   final shakeDetector = ShakeDetectorService(
//     onShake: () => showDistressAlertSheet(context),
//   );
//   shakeDetector.start();
//   shakeDetector.stop(); // when disposing

class ShakeDetectorService {
  ShakeDetectorService({
    required this.onShake,
    this.shakeThreshold = defaultShakeThreshold,
    this.cooldownDuration = const Duration(seconds: 4),
    this.minShakeEvents =
        3, // Number of rapid accelerometer events to count as shake
  });

  static const double defaultShakeSensitivity = 0.5;
  static const double minShakeSensitivity = 0.0;
  static const double maxShakeSensitivity = 1.0;
  static const double minShakeThreshold = 10.0;
  static const double maxShakeThreshold = 20.0;
  static const double defaultShakeThreshold = 15.0;

  final FutureOr<void> Function() onShake;
  double shakeThreshold;
  final Duration cooldownDuration;
  final int minShakeEvents;

  StreamSubscription<AccelerometerEvent>? _subscription;
  bool _active = false;
  bool _sheetOpen = false;
  bool _inCooldown = false;

  // Track rapid accelerometer spikes
  int _shakeCount = 0;
  DateTime? _lastShakeTime;

  // ── Public API ───────────────────────────────────────────────────────────────

  static double thresholdForSensitivity(double sensitivity) {
    final normalized =
        sensitivity.clamp(minShakeSensitivity, maxShakeSensitivity).toDouble();
    return maxShakeThreshold -
        ((maxShakeThreshold - minShakeThreshold) * normalized);
  }

  void updateSensitivity(double sensitivity) {
    shakeThreshold = thresholdForSensitivity(sensitivity);
    _shakeCount = 0;
    _lastShakeTime = null;
  }

  void start() {
    if (_active) return;
    _active = true;
    AppLogger.info('Shake detector started', context: 'ShakeDetector');

    _subscription = accelerometerEventStream().listen(
      _onAccelerometerEvent,
      onError: (e) {
        AppLogger.error('Accelerometer error: $e', context: 'ShakeDetector');
      },
    );
  }

  void stop() {
    _active = false;
    _subscription?.cancel();
    _subscription = null;
    _shakeCount = 0;
    _lastShakeTime = null;
    AppLogger.info('Shake detector stopped', context: 'ShakeDetector');
  }

  /// Call when distress sheet opens to prevent re-triggering
  void markSheetOpen() {
    _sheetOpen = true;
  }

  /// Call when distress sheet closes
  void markSheetClosed() {
    _sheetOpen = false;
  }

  // ── Internal ───────────────────────────────────────────────────────────────

  void _onAccelerometerEvent(AccelerometerEvent event) {
    if (!_active || _sheetOpen || _inCooldown) return;

    // Calculate acceleration magnitude (ignoring gravity, focusing on sudden motion)
    final magnitude =
        sqrt(event.x * event.x + event.y * event.y + event.z * event.z);

    // Subtract gravity (~9.8) and get the delta
    final delta = (magnitude - 9.8).abs();

    if (delta > shakeThreshold) {
      final now = DateTime.now();

      // Check if this is part of a rapid sequence (within 500ms of last shake)
      if (_lastShakeTime != null &&
          now.difference(_lastShakeTime!).inMilliseconds < 500) {
        _shakeCount++;
      } else {
        _shakeCount = 1; // Reset if too much time passed
      }
      _lastShakeTime = now;

      // Only trigger after enough rapid shake events (prevents accidental bumps)
      if (_shakeCount >= minShakeEvents) {
        _triggerShake();
      }
    }
  }

  Future<void> _triggerShake() async {
    _shakeCount = 0;
    _inCooldown = true;
    markSheetOpen();

    AppLogger.event('distress_detected', properties: {'source': 'shake'});

    // Haptic feedback to confirm shake was registered
    await HapticFeedback.heavyImpact();
    await Future.delayed(const Duration(milliseconds: 50));
    await HapticFeedback.heavyImpact();

    try {
      await Future.sync(onShake);
    } finally {
      markSheetClosed();
      // Start cooldown to prevent immediate re-trigger
      Future.delayed(cooldownDuration, () {
        _inCooldown = false;
      });
    }
  }
}
