import 'package:geolocator/geolocator.dart';

import '../../../../core/services/api_client.dart';
import '../../../../core/services/api_endpoints.dart';
import '../../../../core/services/auth_service.dart';

class SosAlertResult {
  const SosAlertResult({
    required this.eventId,
    required this.squadAlertedCount,
    required this.message,
  });

  final String eventId;
  final int squadAlertedCount;
  final String message;
}

class SosService {
  SosService({AuthService? authService})
      : _authService = authService ?? AuthService.instance;

  final AuthService _authService;
  late final ApiClient _api = ApiClient(tokenProvider: _authService.getToken);

  Future<SosAlertResult> triggerAlert({
    required String triggerType,
  }) async {
    final location = await _currentLocation();
    final idempotencyKey =
        '${triggerType}_${DateTime.now().toUtc().microsecondsSinceEpoch}';

    final payload = await _api.post(
      ApiEndpoints.eventsTrigger,
      body: {
        'idempotencyKey': idempotencyKey,
        'triggerType': triggerType,
        'lat': location.latitude,
        'lng': location.longitude,
        'timestamp': DateTime.now().toUtc().toIso8601String(),
      },
      authenticated: true,
    );

    final data = payload['data'] as Map<String, dynamic>?;
    final event = data?['event'] as Map<String, dynamic>?;
    final eventId = (event?['_id'] ?? '').toString();

    if (eventId.isEmpty) {
      throw const ApiException('Alert response did not include an event ID.');
    }

    return SosAlertResult(
      eventId: eventId,
      squadAlertedCount: data?['squadAlertedCount'] as int? ?? 0,
      message: payload['message'] as String? ?? 'Alert sent.',
    );
  }

  Future<void> cancelAlert(
    String eventId, {
    String reason = 'false_alarm',
  }) async {
    await _api.post(
      ApiEndpoints.eventsCancel(eventId),
      body: {'reason': reason},
      authenticated: true,
    );
  }

  Future<Position> _currentLocation() async {
    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      throw const ApiException('Location services are turned off.');
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      throw const ApiException('Location permission is required for SOS.');
    }

    return Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    ).timeout(const Duration(seconds: 10));
  }
}
