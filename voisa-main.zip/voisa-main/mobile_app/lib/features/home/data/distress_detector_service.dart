import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:voisa/core/services/api_config.dart';
import 'package:voisa/core/services/api_endpoints.dart';
import 'package:voisa/core/utils/app_logger.dart';

// ─── Distress Detector Service ────────────────────────────────────────────────
// Polls the Python Porcupine HTTP server every second.
// Guards against double-triggering with [_sheetOpen].
//
// For a real device on local Wi-Fi:
//   Change host to your computer's LAN IP, e.g. '192.168.1.42'

class DistressDetectorService {
  DistressDetectorService({
    required this.onDetected,
    this.pollInterval = const Duration(seconds: 1),
  });

  final FutureOr<void> Function() onDetected;
  final Duration pollInterval;

  Timer? _timer;
  bool _active = false;

  /// Prevents re-triggering while the distress sheet is already visible.
  /// Set to true when the sheet opens; false when it closes.
  bool _sheetOpen = false;

  // ── Public API ───────────────────────────────────────────────────────────────

  void start() {
    if (_active) return;
    _active = true;
    AppLogger.info('Detector polling started', context: 'DistressDetector');
    _timer = Timer.periodic(pollInterval, (_) => _poll());
  }

  void stop() {
    _active = false;
    _timer?.cancel();
    _timer = null;
    AppLogger.info('Detector polling stopped', context: 'DistressDetector');
  }

  /// Call this when the distress sheet is presented so polling won't
  /// fire a second sheet while the first is still open.
  void markSheetOpen() {
    _sheetOpen = true;
  }

  /// Call this when the distress sheet is dismissed (any outcome).
  void markSheetClosed() {
    _sheetOpen = false;
  }

  // ── Internal ─────────────────────────────────────────────────────────────────

  Future<void> _poll() async {
    if (_sheetOpen) return; // guard: sheet already visible

    try {
      final uri = ApiConfig.detectorUri(ApiEndpoints.detectorStatus);
      final response =
          await http.get(uri).timeout(const Duration(milliseconds: 800));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        if (data['triggered'] == true) {
          AppLogger.event('distress_detected',
              properties: {'source': 'porcupine'});
          markSheetOpen();

          try {
            await Future.sync(onDetected);
          } finally {
            // Allow future detections after the sheet/action finishes.
            markSheetClosed();
          }
        }
      }
    } catch (e) {
      // Server not reachable — fail silently in production.
      // The debug mic button on home screen still works as a manual trigger.
      AppLogger.debug('Poll failed — server unreachable',
          context: 'DistressDetector');
    }
  }
}
