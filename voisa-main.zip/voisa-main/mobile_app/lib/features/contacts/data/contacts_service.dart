import 'package:flutter_contacts/flutter_contacts.dart';

import '../../../../core/services/api_client.dart';
import '../../../../core/services/api_endpoints.dart';
import '../../../../core/services/auth_service.dart';

class EmergencyContact {
  const EmergencyContact({
    required this.id,
    required this.name,
    required this.phone,
    required this.relation,
    this.deviceContactId,
  });

  final String id;
  final String name;
  final String phone;
  final String relation;
  final String? deviceContactId;

  factory EmergencyContact.fromJson(Map<String, dynamic> json) {
    return EmergencyContact(
      id: (json['_id'] ?? json['id'] ?? '').toString(),
      name: (json['name'] ?? '').toString(),
      phone: (json['phone'] ?? '').toString(),
      relation: (json['relation'] ?? 'Contact').toString(),
      deviceContactId: json['deviceContactId']?.toString(),
    );
  }
}

class ContactsService {
  ContactsService({AuthService? authService})
      : _authService = authService ?? AuthService.instance;

  final AuthService _authService;
  late final ApiClient _api = ApiClient(tokenProvider: _authService.getToken);

  Future<List<EmergencyContact>> fetchContacts() async {
    final payload = await _api.get(
      ApiEndpoints.usersContacts,
      authenticated: true,
    );

    return _contactsFromPayload(payload);
  }

  Future<List<EmergencyContact>> addDeviceContacts(
    List<Contact> contacts,
  ) async {
    final payload = contacts.map((contact) {
      return {
        'deviceContactId': contact.id,
        'name': contact.displayName,
        'phone': contact.phones.isNotEmpty ? contact.phones.first.number : '',
        'relation': 'Contact',
      };
    }).toList();

    final response = await _api.post(
      ApiEndpoints.usersContacts,
      body: {'contacts': payload},
      authenticated: true,
    );

    return _contactsFromPayload(response);
  }

  Future<List<EmergencyContact>> removeContacts(List<String> contactIds) async {
    final response = await _api.delete(
      ApiEndpoints.usersContacts,
      body: {'contactIds': contactIds},
      authenticated: true,
    );

    return _contactsFromPayload(response);
  }

  List<EmergencyContact> _contactsFromPayload(Map<String, dynamic> payload) {
    final data = payload['data'] as Map<String, dynamic>?;
    final contacts = data?['contacts'] as List<dynamic>? ?? [];

    return contacts
        .whereType<Map<String, dynamic>>()
        .map(EmergencyContact.fromJson)
        .where((contact) => contact.id.isNotEmpty)
        .toList();
  }
}
