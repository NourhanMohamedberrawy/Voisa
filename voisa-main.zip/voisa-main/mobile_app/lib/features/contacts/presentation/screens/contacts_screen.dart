import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../core/utils/app_feedback.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/widgets/state_widgets.dart';
import '../../data/contacts_service.dart';
import '../../../../shared/widgets/shared_widgets.dart';

Future<List<Contact>?> pickDeviceContacts(BuildContext context) {
  return Navigator.push<List<Contact>>(
    context,
    MaterialPageRoute(builder: (_) => const _ContactsPickerScreen()),
  );
}

// ─── Contacts Screen ──────────────────────────────────────────────────────────
class ContactsScreen extends StatefulWidget {
  const ContactsScreen({super.key});

  @override
  State<ContactsScreen> createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  final ContactsService _contactsService = ContactsService();
  List<EmergencyContact> _contacts = [];
  bool _isLoading = true;
  String? _errorMessage;

  // Remove mode state
  bool _isRemoveMode = false;
  final Set<String> _selectedForRemoval = {};

  @override
  void initState() {
    super.initState();
    _loadEmergencyContacts();
  }

  Future<void> _loadEmergencyContacts() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final contacts = await _contactsService.fetchContacts();
      if (!mounted) return;
      setState(() => _contacts = contacts);
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() => _errorMessage = e.message);
    } catch (_) {
      if (!mounted) return;
      setState(() => _errorMessage = 'Could not load contacts.');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _enterRemoveMode() {
    setState(() {
      _isRemoveMode = true;
      _selectedForRemoval.clear();
    });
  }

  void _cancelRemoveMode() {
    setState(() {
      _isRemoveMode = false;
      _selectedForRemoval.clear();
    });
  }

  void _toggleContactSelection(String id) {
    setState(() {
      if (_selectedForRemoval.contains(id)) {
        _selectedForRemoval.remove(id);
      } else {
        _selectedForRemoval.add(id);
      }
    });
  }

  void _selectAllForRemoval() {
    setState(() {
      if (_selectedForRemoval.length == _contacts.length) {
        _selectedForRemoval.clear();
      } else {
        _selectedForRemoval.addAll(_contacts.map((c) => c.id));
      }
    });
  }

  Future<void> _confirmRemoveSelected() async {
    if (_selectedForRemoval.isEmpty) return;

    final confirmed = await AppFeedback.confirmDestructive(
      context,
      title:
          'Remove ${_selectedForRemoval.length} contact${_selectedForRemoval.length == 1 ? '' : 's'}?',
      message:
          'These contacts will be removed from your emergency contacts list.',
      confirmLabel: 'Remove',
    );

    if (confirmed) {
      final ids = _selectedForRemoval.toList();
      try {
        final contacts = await _contactsService.removeContacts(ids);
        if (!mounted) return;
        setState(() {
          _contacts = contacts;
          _isRemoveMode = false;
          _selectedForRemoval.clear();
        });
      } on ApiException catch (e) {
        _showError(e.message);
      } catch (_) {
        _showError('Could not remove contacts.');
      }
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    AppFeedback.showError(context, message);
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: EdgeInsets.only(
                top: topPadding + AppSpacing.md,
                left: AppSpacing.screenH,
                right: AppSpacing.screenH,
                bottom: AppSpacing.md,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Contacts', style: AppTextStyles.displayLarge),
                  const SizedBox(height: AppSpacing.lg),
                  if (_isLoading)
                    const SizedBox(
                      height: 220,
                      child: VoisaLoadingView(),
                    )
                  else if (_errorMessage != null)
                    SizedBox(
                      height: 260,
                      child: VoisaErrorView(
                        message: _errorMessage!,
                        onRetry: _loadEmergencyContacts,
                      ),
                    )
                  else if (_contacts.isEmpty)
                    _EmptyContactsState()
                  else
                    ..._contacts.map(
                      (c) => Padding(
                        padding: const EdgeInsets.only(bottom: AppSpacing.md),
                        child: _ContactCard(
                          contact: c,
                          isRemoveMode: _isRemoveMode,
                          isSelected: _selectedForRemoval.contains(c.id),
                          onToggleSelection: () =>
                              _toggleContactSelection(c.id),
                          onLocation: () => _onLocation(c),
                          onMessage: () => _onMessage(c),
                          onCall: () => _onCall(c),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),

          // ── Bottom Action Bar ─────────────────────────────────────────
          _isRemoveMode
              ? _RemoveModeActionBar(
                  selectedCount: _selectedForRemoval.length,
                  totalCount: _contacts.length,
                  onCancel: _cancelRemoveMode,
                  onSelectAll: _selectAllForRemoval,
                  onRemove: _confirmRemoveSelected,
                  bottomPadding: bottomPadding,
                )
              : _ContactsActionBar(
                  onAdd: _onAddContact,
                  onRemove: _enterRemoveMode,
                  onSetPriority: _onSetPriority,
                  bottomPadding: bottomPadding,
                ),
        ],
      ),
    );
  }

  // Action handlers — TODO: connect to real logic
  void _onLocation(EmergencyContact c) {
    // Open Google Maps to last known location of the contact
    // url_launcher: maps.google.com/?q=<lat>,<lng>
  }

  void _onMessage(EmergencyContact c) {
    // Open SMS / in-app messaging
  }

  void _onCall(EmergencyContact c) {
    // url_launcher: tel:<phone_number>
  }

  void _onAddContact() async {
    final selectedContacts = await pickDeviceContacts(context);

    if (selectedContacts != null && selectedContacts.isNotEmpty) {
      try {
        final contacts =
            await _contactsService.addDeviceContacts(selectedContacts);
        if (!mounted) return;
        setState(() => _contacts = contacts);
      } on ApiException catch (e) {
        _showError(e.message);
      } catch (_) {
        _showError('Could not add contacts.');
      }
    }
  }

  // Remove mode is now handled by _enterRemoveMode()

  void _onSetPriority() {
    // TODO: drag-to-reorder contacts or assign priority levels
  }
}

// ─── Contact Card ─────────────────────────────────────────────────────────────
class _ContactCard extends StatelessWidget {
  const _ContactCard({
    required this.contact,
    this.isRemoveMode = false,
    this.isSelected = false,
    this.onToggleSelection,
    required this.onLocation,
    required this.onMessage,
    required this.onCall,
  });

  final EmergencyContact contact;
  final bool isRemoveMode;
  final bool isSelected;
  final VoidCallback? onToggleSelection;
  final VoidCallback onLocation;
  final VoidCallback onMessage;
  final VoidCallback onCall;

  @override
  Widget build(BuildContext context) {
    return VoisaCard(
      padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.md, vertical: AppSpacing.md),
      child: Column(
        children: [
          // Avatar + name row with optional selection checkbox
          Row(
            children: [
              if (isRemoveMode)
                Padding(
                  padding: const EdgeInsets.only(right: AppSpacing.md),
                  child: Checkbox(
                    value: isSelected,
                    onChanged: (_) => onToggleSelection?.call(),
                    activeColor: AppColors.primary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppRadius.sm),
                    ),
                  ),
                ),
              ContactAvatar(
                name: contact.name,
                radius: 26,
                color: Color(0xFF3D3D3D + (contact.id.hashCode % 0xFFFFFF)),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(contact.name, style: AppTextStyles.cardTitle),
                    Text(
                      '${contact.relation} · ${contact.phone}',
                      style: AppTextStyles.cardSubtitle,
                    ),
                  ],
                ),
              ),
              if (isRemoveMode)
                GestureDetector(
                  onTap: onToggleSelection,
                  behavior: HitTestBehavior.opaque,
                  child: Container(
                    padding: const EdgeInsets.all(AppSpacing.sm),
                    child: Icon(
                      isSelected ? Icons.check_circle : Icons.circle_outlined,
                      color: isSelected ? AppColors.primary : AppColors.divider,
                      size: 28,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: AppSpacing.md),

          // Action buttons - hidden in remove mode
          if (!isRemoveMode)
            IntrinsicHeight(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _ContactAction(label: 'Location', onTap: onLocation),
                  const VerticalDivider(
                      color: AppColors.divider, thickness: 1, width: 1),
                  _ContactAction(label: 'Message', onTap: onMessage),
                  const VerticalDivider(
                      color: AppColors.divider, thickness: 1, width: 1),
                  _ContactAction(label: 'Call Now', onTap: onCall),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _ContactAction extends StatelessWidget {
  const _ContactAction({required this.label, required this.onTap});
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
          child: Center(
            child: Text(
              label,
              style: AppTextStyles.body.copyWith(
                color: AppColors.textSecondary,
                fontSize: 14,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Remove Mode Action Bar ───────────────────────────────────────────────────
class _RemoveModeActionBar extends StatelessWidget {
  const _RemoveModeActionBar({
    required this.selectedCount,
    required this.totalCount,
    required this.onCancel,
    required this.onSelectAll,
    required this.onRemove,
    required this.bottomPadding,
  });

  final int selectedCount;
  final int totalCount;
  final VoidCallback onCancel;
  final VoidCallback onSelectAll;
  final VoidCallback onRemove;
  final double bottomPadding;

  @override
  Widget build(BuildContext context) {
    final allSelected = selectedCount == totalCount && totalCount > 0;

    return Container(
      padding: EdgeInsets.only(
        left: AppSpacing.screenH,
        right: AppSpacing.screenH,
        top: AppSpacing.md,
        bottom: AppSpacing.md + bottomPadding,
      ),
      decoration: const BoxDecoration(
        color: AppColors.background,
        border: Border(top: BorderSide(color: AppColors.divider, width: 0.8)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Selection info row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '$selectedCount selected',
                  style: AppTextStyles.cardTitle.copyWith(fontSize: 16),
                ),
                TextButton.icon(
                  onPressed: onSelectAll,
                  icon: Icon(
                    allSelected ? Icons.deselect : Icons.select_all,
                    size: 18,
                    color: AppColors.primary,
                  ),
                  label: Text(
                    allSelected ? 'Deselect all' : 'Select all',
                    style: AppTextStyles.buttonLabel.copyWith(
                      color: AppColors.primary,
                      fontSize: 14,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            // Action buttons row
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onCancel,
                    icon: const Icon(Icons.close_rounded, size: 18),
                    label: const Text('Cancel'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.textSecondary,
                      side: const BorderSide(color: AppColors.divider),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(AppRadius.pill),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: selectedCount > 0 ? onRemove : null,
                    icon: const Icon(Icons.delete_outline_rounded, size: 18),
                    label: Text(
                        'Remove${selectedCount > 0 ? ' ($selectedCount)' : ''}'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.error,
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: AppColors.divider,
                      disabledForegroundColor: AppColors.textSecondary,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(AppRadius.pill),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Contacts Action Bar ──────────────────────────────────────────────────────
class _ContactsActionBar extends StatelessWidget {
  const _ContactsActionBar({
    required this.onAdd,
    required this.onRemove,
    required this.onSetPriority,
    required this.bottomPadding,
  });

  final VoidCallback onAdd;
  final VoidCallback onRemove;
  final VoidCallback onSetPriority;
  final double bottomPadding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        left: AppSpacing.screenH,
        right: AppSpacing.screenH,
        top: AppSpacing.md,
        bottom: AppSpacing.md + bottomPadding,
      ),
      decoration: const BoxDecoration(
        color: AppColors.background,
        border: Border(top: BorderSide(color: AppColors.divider, width: 0.8)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        child: Row(
          children: [
            _ActionBarButton(
              label: 'Add Contacts',
              icon: Icons.add,
              onTap: onAdd,
            ),
            const SizedBox(width: AppSpacing.md),
            _ActionBarButton(
              label: 'Remove Contacts',
              icon: Icons.remove,
              onTap: onRemove,
            ),
            const SizedBox(width: AppSpacing.md),
            _ActionBarButton(
              label: 'Set Priority',
              icon: Icons.star_rounded,
              onTap: onSetPriority,
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionBarButton extends StatelessWidget {
  const _ActionBarButton({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18, color: Colors.white),
      label: Text(label,
          style: AppTextStyles.buttonLabel.copyWith(color: Colors.white)),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        elevation: 0,
        padding:
            const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: 14),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.pill),
        ),
      ),
    );
  }
}

// ─── Empty State ──────────────────────────────────────────────────────────────
class _EmptyContactsState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: AppSpacing.xxl),
        child: Column(
          children: [
            Icon(Icons.group_add_rounded,
                size: 56,
                color: AppColors.textSecondary.withValues(alpha: 0.4)),
            const SizedBox(height: AppSpacing.md),
            Text('No emergency contacts yet',
                style: AppTextStyles.cardSubtitle),
            const SizedBox(height: AppSpacing.sm),
            Text(
              'Add trusted contacts so they can be alerted\nduring an emergency.',
              style: AppTextStyles.caption,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Contacts Picker Screen (WhatsApp-style) ──────────────────────────────────
class _ContactsPickerScreen extends StatefulWidget {
  const _ContactsPickerScreen();

  @override
  State<_ContactsPickerScreen> createState() => _ContactsPickerScreenState();
}

class _ContactsPickerScreenState extends State<_ContactsPickerScreen> {
  List<Contact> _deviceContacts = [];
  List<Contact> _filteredContacts = [];
  final Set<String> _selectedIds = {};
  bool _isLoading = true;
  bool _hasPermission = false;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadContacts();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredContacts = List.from(_deviceContacts);
      } else {
        _filteredContacts = _deviceContacts.where((c) {
          final name = (c.displayName ?? '').toLowerCase();
          final phone = c.phones.isNotEmpty ? c.phones.first.number : '';
          return name.contains(query) || phone.contains(query);
        }).toList();
      }
    });
  }

  Future<void> _loadContacts() async {
    try {
      // Request contacts permission using flutter_contacts v2 API
      final permissionStatus = await FlutterContacts.permissions.request(
        PermissionType.read,
      );
      if (permissionStatus != PermissionStatus.granted) {
        setState(() {
          _hasPermission = false;
          _isLoading = false;
        });
        return;
      }

      // Get contacts using flutter_contacts v2 API
      final contacts = await FlutterContacts.getAll(
        properties: {
          ContactProperty.name,
          ContactProperty.phone,
          ContactProperty.photoThumbnail,
        },
      );

      // Filter out contacts without phone numbers
      final validContacts = contacts.where((c) => c.phones.isNotEmpty).toList();

      setState(() {
        _deviceContacts = validContacts;
        _filteredContacts = validContacts;
        _hasPermission = true;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hasPermission = false;
      });
    }
  }

  void _toggleSelection(Contact contact) {
    final id = contact.id ?? '';
    if (id.isEmpty) return;
    setState(() {
      if (_selectedIds.contains(id)) {
        _selectedIds.remove(id);
      } else {
        _selectedIds.add(id);
      }
    });
  }

  void _confirmSelection() {
    final selected = _deviceContacts
        .where((c) => c.id != null && _selectedIds.contains(c.id))
        .toList();
    Navigator.pop(context, selected);
  }

  List<Contact> get _selectedContacts {
    return _deviceContacts
        .where((c) => c.id != null && _selectedIds.contains(c.id))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final selectedCount = _selectedIds.length;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded,
              color: AppColors.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Add Contacts',
              style: AppTextStyles.sectionTitle.copyWith(fontSize: 18),
            ),
            if (selectedCount > 0)
              Text(
                '$selectedCount selected',
                style: AppTextStyles.caption.copyWith(fontSize: 12),
              ),
          ],
        ),
        actions: [
          if (selectedCount > 0)
            TextButton(
              onPressed: () {
                setState(() {
                  if (selectedCount == _filteredContacts.length) {
                    _selectedIds.clear();
                  } else {
                    _selectedIds.addAll(_filteredContacts
                        .map((c) => c.id)
                        .where((id) => id != null)
                        .cast<String>());
                  }
                });
              },
              child: Text(
                selectedCount == _filteredContacts.length
                    ? 'Deselect all'
                    : 'Select all',
                style: AppTextStyles.buttonLabel.copyWith(
                  color: AppColors.primary,
                  fontSize: 14,
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.screenH,
              vertical: AppSpacing.sm,
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search contacts',
                hintStyle: AppTextStyles.cardSubtitle,
                filled: true,
                fillColor: AppColors.surface,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                  borderSide: BorderSide.none,
                ),
                prefixIcon: const Icon(Icons.search_rounded,
                    color: AppColors.textSecondary),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: AppSpacing.md,
                  vertical: AppSpacing.md,
                ),
              ),
            ),
          ),

          // Selected contacts chips (horizontal scroll)
          if (selectedCount > 0)
            Container(
              height: 80,
              padding:
                  const EdgeInsets.symmetric(horizontal: AppSpacing.screenH),
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _selectedContacts.length,
                itemBuilder: (context, index) {
                  final contact = _selectedContacts[index];
                  return _SelectedContactChip(
                    contact: contact,
                    onRemove: () => _toggleSelection(contact),
                  );
                },
              ),
            ),

          const Divider(color: AppColors.divider, height: 1),

          // Contacts list
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : !_hasPermission
                    ? _PermissionDeniedState(onRequest: _loadContacts)
                    : _filteredContacts.isEmpty
                        ? _EmptySearchState(query: _searchController.text)
                        : ListView.builder(
                            physics: const BouncingScrollPhysics(),
                            itemCount: _filteredContacts.length,
                            itemBuilder: (context, index) {
                              final contact = _filteredContacts[index];
                              final isSelected =
                                  _selectedIds.contains(contact.id);
                              return _ContactListTile(
                                contact: contact,
                                isSelected: isSelected,
                                onTap: () => _toggleSelection(contact),
                              );
                            },
                          ),
          ),
        ],
      ),
      floatingActionButton: selectedCount > 0
          ? FloatingActionButton.extended(
              onPressed: _confirmSelection,
              backgroundColor: AppColors.primary,
              icon: const Icon(Icons.check_rounded, color: Colors.white),
              label: Text(
                'Add ($selectedCount)',
                style: AppTextStyles.buttonLabel.copyWith(color: Colors.white),
              ),
            )
          : null,
    );
  }
}

// ─── Selected Contact Chip ────────────────────────────────────────────────────
class _SelectedContactChip extends StatelessWidget {
  const _SelectedContactChip({
    required this.contact,
    required this.onRemove,
  });

  final Contact contact;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final name = contact.displayName ?? 'Unknown';
    return Container(
      width: 64,
      margin: const EdgeInsets.only(right: AppSpacing.sm, top: AppSpacing.sm),
      child: Column(
        children: [
          Stack(
            children: [
              ContactAvatar(
                name: name,
                imageBytes: contact.photo?.thumbnail,
                radius: 24,
                color: Color(0xFF3D3D3D + (contact.hashCode % 0xFFFFFF)),
              ),
              Positioned(
                top: -4,
                right: -4,
                child: GestureDetector(
                  onTap: onRemove,
                  child: Container(
                    width: 20,
                    height: 20,
                    decoration: const BoxDecoration(
                      color: AppColors.error,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.close_rounded,
                      size: 12,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            name.split(' ').first,
            style: AppTextStyles.caption.copyWith(fontSize: 11),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

// ─── Contact List Tile ────────────────────────────────────────────────────────
class _ContactListTile extends StatelessWidget {
  const _ContactListTile({
    required this.contact,
    required this.isSelected,
    required this.onTap,
  });

  final Contact contact;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final phone = contact.phones.isNotEmpty ? contact.phones.first.number : '';
    final name = contact.displayName ?? 'Unknown';

    return ListTile(
      onTap: onTap,
      leading: ContactAvatar(
        name: name,
        imageBytes: contact.photo?.thumbnail,
        radius: 24,
        color: Color(0xFF3D3D3D + (contact.hashCode % 0xFFFFFF)),
      ),
      title: Text(
        name,
        style: AppTextStyles.cardTitle.copyWith(fontSize: 15),
      ),
      subtitle: Text(
        phone,
        style: AppTextStyles.cardSubtitle.copyWith(fontSize: 13),
      ),
      trailing: Checkbox(
        value: isSelected,
        onChanged: (_) => onTap(),
        activeColor: AppColors.primary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppRadius.sm),
        ),
      ),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: AppSpacing.screenH,
        vertical: 4,
      ),
    );
  }
}

// ─── Permission Denied State ──────────────────────────────────────────────────
class _PermissionDeniedState extends StatelessWidget {
  const _PermissionDeniedState({required this.onRequest});
  final VoidCallback onRequest;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.contact_page_outlined,
              size: 64,
              color: AppColors.textSecondary.withValues(alpha: 0.4),
            ),
            const SizedBox(height: AppSpacing.md),
            Text(
              'Contacts access needed',
              style: AppTextStyles.cardTitle,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(
              'Please allow access to your contacts to add emergency contacts.',
              style: AppTextStyles.caption,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: AppSpacing.lg),
            PrimaryButton(
              label: 'Grant Permission',
              onTap: onRequest,
              icon: Icons.settings_rounded,
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Empty Search State ───────────────────────────────────────────────────────
class _EmptySearchState extends StatelessWidget {
  const _EmptySearchState({required this.query});
  final String query;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.search_off_rounded,
              size: 56,
              color: AppColors.textSecondary.withValues(alpha: 0.4),
            ),
            const SizedBox(height: AppSpacing.md),
            Text(
              'No contacts found',
              style: AppTextStyles.cardTitle,
            ),
            const SizedBox(height: AppSpacing.sm),
            Text(
              'No results for "$query"',
              style: AppTextStyles.caption,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
