import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/services/auth_service.dart';
import '../../../../core/utils/app_feedback.dart';
import '../../../contacts/data/contacts_service.dart';
import '../../../contacts/presentation/screens/contacts_screen.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import '../../../../navigation/main_shell.dart';

class ContactsSetupScreen extends StatefulWidget {
  const ContactsSetupScreen({super.key});

  @override
  State<ContactsSetupScreen> createState() => _ContactsSetupScreenState();
}

class _ContactsSetupScreenState extends State<ContactsSetupScreen> {
  final ContactsService _contactsService = ContactsService();
  List<EmergencyContact> _contacts = [];
  bool _isLoading = true;
  bool _isSaving = false;
  final Set<String> _selectedForRemoval = {};

  @override
  void initState() {
    super.initState();
    _loadContacts();
  }

  Future<void> _loadContacts() async {
    try {
      final contacts = await _contactsService.fetchContacts();
      if (!mounted) return;
      setState(() => _contacts = contacts);
    } on ApiException catch (e) {
      _showError(e.message);
    } catch (_) {
      _showError('Could not load contacts.');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _onAddContact() async {
    final selectedContacts = await pickDeviceContacts(context);
    if (selectedContacts == null || selectedContacts.isEmpty) return;

    setState(() => _isSaving = true);
    try {
      final contacts =
          await _contactsService.addDeviceContacts(selectedContacts);
      if (!mounted) return;
      setState(() {
        _contacts = contacts;
        _selectedForRemoval.clear();
      });
    } on ApiException catch (e) {
      _showError(e.message);
    } catch (_) {
      _showError('Could not add contacts.');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Future<void> _removeSelectedContacts() async {
    if (_selectedForRemoval.isEmpty) return;

    setState(() => _isSaving = true);
    try {
      final contacts = await _contactsService.removeContacts(
        _selectedForRemoval.toList(),
      );
      if (!mounted) return;
      setState(() {
        _contacts = contacts;
        _selectedForRemoval.clear();
      });
    } on ApiException catch (e) {
      _showError(e.message);
    } catch (_) {
      _showError('Could not remove contacts.');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  void _toggleContact(String id) {
    setState(() {
      if (_selectedForRemoval.contains(id)) {
        _selectedForRemoval.remove(id);
      } else {
        _selectedForRemoval.add(id);
      }
    });
  }

  void _showError(String message) {
    if (!mounted) return;
    AppFeedback.showError(context, message);
  }

  void _onContinue() {
    // Navigate to Home — clear the entire navigation stack
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const MainShell()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    final hasSelection = _selectedForRemoval.isNotEmpty;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.only(
                top: topPadding + AppSpacing.lg,
                left: AppSpacing.screenH,
                right: AppSpacing.screenH,
                bottom: AppSpacing.md,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: AppColors.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: const Icon(Icons.group_rounded,
                        color: AppColors.primary, size: 28),
                  ),
                  const SizedBox(height: AppSpacing.lg),
                  Text('Add emergency\ncontacts.',
                      style: AppTextStyles.displayLarge.copyWith(
                        fontSize: 28,
                        height: 1.15,
                      )),
                  const SizedBox(height: AppSpacing.sm),
                  Text(
                    'These people will be alerted with your location the moment Voisa detects an emergency.',
                    style: AppTextStyles.body.copyWith(
                      color: AppColors.textSecondary,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.xl),

                  // Contact list or empty hint
                  if (_isLoading)
                    const Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: AppSpacing.xxl),
                        child: CircularProgressIndicator(),
                      ),
                    )
                  else if (_contacts.isEmpty)
                    _EmptyContactsHint()
                  else
                    ..._contacts.map((c) => Padding(
                          padding: const EdgeInsets.only(bottom: AppSpacing.md),
                          child: _SetupContactTile(
                            contact: c,
                            isSelected: _selectedForRemoval.contains(c.id),
                            onTap: () => _toggleContact(c.id),
                          ),
                        )),

                  const SizedBox(height: AppSpacing.lg),

                  // Add button
                  PrimaryButton(
                    label: _isSaving ? 'Saving...' : 'Add Contacts',
                    onTap: _isSaving ? () {} : _onAddContact,
                    icon: Icons.add,
                    isOutlined: true,
                    color: AppColors.primary,
                    textColor: AppColors.primary,
                    width: double.infinity,
                    height: 52,
                  ),
                  if (_contacts.isNotEmpty) ...[
                    const SizedBox(height: AppSpacing.md),
                    PrimaryButton(
                      label: hasSelection
                          ? 'Remove Selected (${_selectedForRemoval.length})'
                          : 'Select Contacts to Remove',
                      onTap: hasSelection ? _removeSelectedContacts : () {},
                      icon: Icons.delete_outline_rounded,
                      isOutlined: true,
                      color:
                          hasSelection ? AppColors.error : AppColors.navIconBg,
                      textColor:
                          hasSelection ? AppColors.error : AppColors.navIconBg,
                      width: double.infinity,
                      height: 52,
                    ),
                  ],
                ],
              ),
            ),
          ),

          // Bottom action
          Container(
            padding: EdgeInsets.only(
              left: AppSpacing.screenH,
              right: AppSpacing.screenH,
              top: AppSpacing.md,
              bottom: bottomPadding + AppSpacing.md,
            ),
            decoration: const BoxDecoration(
              color: AppColors.background,
              border:
                  Border(top: BorderSide(color: AppColors.divider, width: 0.8)),
            ),
            child: Column(
              children: [
                PrimaryButton(
                  label: 'Continue to Voisa',
                  onTap: _onContinue,
                  color: AppColors.primary,
                  width: double.infinity,
                  height: 52,
                ),
                const SizedBox(height: AppSpacing.sm),
                GestureDetector(
                  onTap: _onContinue,
                  child: Text(
                    'Skip for now',
                    style: AppTextStyles.body.copyWith(
                      color: AppColors.textSecondary,
                      fontSize: 14,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Empty hint ───────────────────────────────────────────────────────────────
class _EmptyContactsHint extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return VoisaCard(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Row(
        children: [
          const Icon(Icons.info_outline_rounded,
              color: AppColors.textSecondary, size: 22),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Text(
              'No contacts added yet. You can add trusted people now or skip this step for later.',
              style: AppTextStyles.caption.copyWith(height: 1.5),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Setup contact tile ───────────────────────────────────────────────────────
class _SetupContactTile extends StatelessWidget {
  const _SetupContactTile({
    required this.contact,
    required this.isSelected,
    required this.onTap,
  });

  final EmergencyContact contact;
  final bool isSelected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: VoisaCard(
        padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.md, vertical: AppSpacing.md),
        child: Row(
          children: [
            Checkbox(
              value: isSelected,
              onChanged: (_) => onTap(),
              activeColor: AppColors.primary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppRadius.sm),
              ),
            ),
            const SizedBox(width: AppSpacing.sm),
            ContactAvatar(
                name: contact.name, radius: 22, color: AppColors.primary),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(contact.name,
                      style: AppTextStyles.cardTitle.copyWith(fontSize: 16)),
                  Text(
                    '${contact.relation} · ${contact.phone}',
                    style: AppTextStyles.caption,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
