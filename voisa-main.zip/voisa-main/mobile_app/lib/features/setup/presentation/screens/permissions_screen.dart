import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import 'contacts_setup_screen.dart';

// Each permission step as data
class _PermissionStep {
  const _PermissionStep({
    required this.icon,
    required this.title,
    required this.reason,
    required this.buttonLabel,
    required this.permission,
  });
  final IconData icon;
  final String title;
  final String reason;
  final String buttonLabel;
  final Permission permission;
}

final _steps = [
  const _PermissionStep(
    icon: Icons.mic_rounded,
    title: 'Microphone access',
    reason:
        'Voisa listens for distress words like "help" to automatically trigger an emergency alert — even when you can\'t reach your phone.',
    buttonLabel: 'Allow Microphone',
    permission: Permission.microphone,
  ),
  const _PermissionStep(
    icon: Icons.location_on_rounded,
    title: 'Location access',
    reason:
        'Your real-time location is shared with emergency contacts the moment an alert is triggered, so help can reach you faster.',
    buttonLabel: 'Allow Location',
    permission: Permission.locationWhenInUse,
  ),
  const _PermissionStep(
    icon: Icons.notifications_rounded,
    title: 'Notifications',
    reason:
        'Receive instant alerts when a contact activates SOS or when Voisa detects a distress situation nearby.',
    buttonLabel: 'Allow Notifications',
    permission: Permission.notification,
  ),
];

class PermissionsScreen extends StatefulWidget {
  const PermissionsScreen({super.key});

  @override
  State<PermissionsScreen> createState() => _PermissionsScreenState();
}

class _PermissionsScreenState extends State<PermissionsScreen> {
  int _currentStep = 0;
  bool _isLoading = false;

  Future<void> _onAllow() async {
    final step = _steps[_currentStep];

    setState(() => _isLoading = true);

    PermissionStatus status;

    // Request the actual native iOS permission
    if (step.permission == Permission.locationWhenInUse) {
      // iOS requires WhenInUse first, then Always
      final whenInUseStatus = await Permission.locationWhenInUse.request();
      if (whenInUseStatus.isGranted) {
        // Try to upgrade to Always for background tracking
        final alwaysStatus = await Permission.locationAlways.request();
        status = alwaysStatus.isGranted ? alwaysStatus : whenInUseStatus;
      } else {
        status = whenInUseStatus;
      }
    } else {
      status = await step.permission.request();
    }

    setState(() => _isLoading = false);

    // Show settings dialog if permanently denied
    if (status.isPermanentlyDenied && mounted) {
      _showSettingsDialog(step);
      return;
    }

    // Move to next step regardless of result (granted or denied)
    if (_currentStep < _steps.length - 1) {
      setState(() => _currentStep++);
    } else {
      if (!mounted) return;

      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const ContactsSetupScreen()),
      );
    }
  }

  void _showSettingsDialog(_PermissionStep step) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppRadius.lg)),
        title: Text('Permission Required', style: AppTextStyles.sectionTitle),
        content: Text(
          '${step.title} was denied. Please enable it in Settings to use this feature.',
          style: AppTextStyles.body,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Cancel',
                style: AppTextStyles.buttonLabel
                    .copyWith(color: AppColors.textSecondary)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              openAppSettings();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(AppRadius.pill)),
            ),
            child: const Text('Open Settings'),
          ),
        ],
      ),
    );
  }

  void _onSkip() {
    if (_currentStep < _steps.length - 1) {
      setState(() => _currentStep++);
    } else {
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => const ContactsSetupScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    final step = _steps[_currentStep];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Padding(
        padding: EdgeInsets.only(
          top: topPadding + AppSpacing.lg,
          left: AppSpacing.screenH,
          right: AppSpacing.screenH,
          bottom: bottomPadding + AppSpacing.lg,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Step indicator dots
            Row(
              children: List.generate(_steps.length, (i) {
                final active = i == _currentStep;
                return Container(
                  width: active ? 24 : 8,
                  height: 8,
                  margin: const EdgeInsets.only(right: 6),
                  decoration: BoxDecoration(
                    color: active ? AppColors.primary : AppColors.surfaceDark,
                    borderRadius: BorderRadius.circular(AppRadius.pill),
                  ),
                );
              }),
            ),
            const Spacer(),

            // Icon
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: AppColors.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Icon(step.icon, color: AppColors.primary, size: 36),
            ),
            const SizedBox(height: AppSpacing.lg),

            Text(step.title,
                style: AppTextStyles.displayLarge.copyWith(fontSize: 28)),
            const SizedBox(height: AppSpacing.md),
            Text(
              step.reason,
              style: AppTextStyles.body.copyWith(
                color: AppColors.textSecondary,
                height: 1.6,
              ),
            ),
            const Spacer(),

            PrimaryButton(
              label: _isLoading ? 'Requesting...' : step.buttonLabel,
              onTap: _isLoading ? () {} : _onAllow,
              width: double.infinity,
              height: 52,
            ),
            const SizedBox(height: AppSpacing.md),
            Center(
              child: GestureDetector(
                onTap: _onSkip,
                child: Text(
                  'Skip for now',
                  style: AppTextStyles.body.copyWith(
                    color: AppColors.textSecondary,
                    fontSize: 14,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
