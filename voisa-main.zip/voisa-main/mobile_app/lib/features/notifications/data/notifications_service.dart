import '../../../core/services/api_client.dart';
import '../../../core/services/api_endpoints.dart';
import '../../../core/services/auth_service.dart';

class ActivityNotification {
  const ActivityNotification({
    required this.id,
    required this.name,
    required this.relation,
    required this.description,
    required this.status,
    this.locationDescription,
    this.isLive = false,
    this.lastUpdated,
  });

  final String id;
  final String name;
  final String relation;
  final String description;
  final String status;
  final String? locationDescription;
  final bool isLive;
  final String? lastUpdated;
}

class NotificationsService {
  NotificationsService({ApiClient? apiClient})
      : _apiClient = apiClient ??
            ApiClient(tokenProvider: AuthService.instance.getToken);

  final ApiClient _apiClient;

  Future<List<ActivityNotification>> getReceivedAlerts() async {
    final response = await _apiClient.get(
      ApiEndpoints.eventsSquadReceived,
      authenticated: true,
    );
    final data = response['data'] as Map<String, dynamic>? ?? {};
    final rawNotifications = data['notifications'];
    if (rawNotifications is! List) return const [];

    return rawNotifications
        .whereType<Map<String, dynamic>>()
        .map(_notificationFromJson)
        .toList(growable: false);
  }

  ActivityNotification _notificationFromJson(Map<String, dynamic> json) {
    final event = _asMap(json['eventId']);
    final sender = _asMap(json['senderId']);
    final eventOwner = _asMap(event['userId']);
    final senderName = _string(sender['name']) ??
        _string(eventOwner['name']) ??
        _string(sender['email']) ??
        'Emergency contact';
    final status = _string(event['status']) ?? _string(json['deliveryStatus']);
    final sentAt = _dateTime(json['sentAt']) ?? _dateTime(event['startTime']);
    final triggerType = _string(event['triggerType']);

    return ActivityNotification(
      id: _string(json['_id']) ?? _string(event['_id']) ?? '',
      name: senderName,
      relation: 'Contact',
      description: _descriptionFor(status, triggerType),
      status: status ?? 'notifying',
      locationDescription:
          _locationDescription(_asMap(event['locationSnapshot'])),
      isLive: _isLive(status),
      lastUpdated: _timeAgo(sentAt),
    );
  }

  Map<String, dynamic> _asMap(Object? value) {
    if (value is Map<String, dynamic>) return value;
    return const {};
  }

  String? _string(Object? value) {
    final text = value?.toString().trim();
    return text == null || text.isEmpty ? null : text;
  }

  DateTime? _dateTime(Object? value) {
    if (value == null) return null;
    return DateTime.tryParse(value.toString())?.toLocal();
  }

  String _descriptionFor(String? status, String? triggerType) {
    final trigger = triggerType == null ? 'alert' : '$triggerType alert';
    switch (status) {
      case 'resolved':
        return 'Resolved $trigger';
      case 'canceled':
      case 'false_alarm':
        return 'Canceled $trigger';
      case 'pending_confirmation':
        return 'Pending confirmation';
      case 'notification_partial_failure':
      case 'notifying':
      case 'active':
        return 'Emergency $trigger';
      default:
        return 'Safety update';
    }
  }

  bool _isLive(String? status) {
    return status == 'active' ||
        status == 'notifying' ||
        status == 'notification_partial_failure';
  }

  String? _locationDescription(Map<String, dynamic> location) {
    final lat = location['lat'];
    final lng = location['lng'];
    if (lat == null || lng == null) return null;
    return 'Last location: $lat, $lng';
  }

  String? _timeAgo(DateTime? time) {
    if (time == null) return null;
    final difference = DateTime.now().difference(time);
    if (difference.inMinutes < 1) return 'Just now';
    if (difference.inMinutes < 60) return '${difference.inMinutes} min ago';
    if (difference.inHours < 24) return '${difference.inHours} hr ago';
    return '${difference.inDays} d ago';
  }
}
