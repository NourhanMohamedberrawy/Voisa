import 'package:flutter/material.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/widgets/state_widgets.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import '../../data/notifications_service.dart';

// ─── Safety Status Indicators ─────────────────────────────────────────────────
enum SafetyStatus { safe, inTransit, needsAttention, emergency }

extension SafetyStatusExtension on SafetyStatus {
  String get label {
    switch (this) {
      case SafetyStatus.safe:
        return 'Safe';
      case SafetyStatus.inTransit:
        return 'In Transit';
      case SafetyStatus.needsAttention:
        return 'Needs Attention';
      case SafetyStatus.emergency:
        return 'Emergency';
    }
  }

  Color get color {
    switch (this) {
      case SafetyStatus.safe:
        return const Color(0xFF27AE60); // Green
      case SafetyStatus.inTransit:
        return const Color(0xFFF39C12); // Orange/Yellow
      case SafetyStatus.needsAttention:
        return const Color(0xFFE67E22); // Dark orange
      case SafetyStatus.emergency:
        return const Color(0xFFE74C3C); // Red
    }
  }

  IconData get icon {
    switch (this) {
      case SafetyStatus.safe:
        return Icons.check_circle_rounded;
      case SafetyStatus.inTransit:
        return Icons.directions_walk_rounded;
      case SafetyStatus.needsAttention:
        return Icons.warning_rounded;
      case SafetyStatus.emergency:
        return Icons.emergency_rounded;
    }
  }
}

// ─── Notification Models ──────────────────────────────────────────────────────
class ContactNotification {
  ContactNotification({
    required this.id,
    required this.name,
    required this.relation,
    required this.timeAgo,
    required this.safetyStatus,
    this.imageUrl,
    this.locationDescription,
    this.isLive = false,
    this.lastUpdated,
  });

  final String id;
  final String name;
  final String relation;
  final String timeAgo;
  final SafetyStatus safetyStatus;
  final String? imageUrl;
  final String? locationDescription;
  final bool isLive;
  final String? lastUpdated;

  factory ContactNotification.fromActivity(ActivityNotification notification) {
    return ContactNotification(
      id: notification.id,
      name: notification.name,
      relation: notification.relation,
      timeAgo: notification.description,
      safetyStatus: _statusFromBackend(notification.status),
      locationDescription: notification.locationDescription,
      isLive: notification.isLive,
      lastUpdated: notification.lastUpdated,
    );
  }

  static SafetyStatus _statusFromBackend(String status) {
    switch (status) {
      case 'resolved':
        return SafetyStatus.safe;
      case 'pending_confirmation':
        return SafetyStatus.needsAttention;
      case 'active':
      case 'notifying':
      case 'notification_partial_failure':
        return SafetyStatus.emergency;
      default:
        return SafetyStatus.inTransit;
    }
  }
}

// ─── Notifications Screen ─────────────────────────────────────────────────────
class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  final NotificationsService _notificationsService = NotificationsService();
  List<ContactNotification> _notifications = const [];
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadNotifications();
  }

  Future<void> _loadNotifications() async {
    if (mounted) {
      setState(() {
        _isLoading = true;
        _error = null;
      });
    }

    try {
      final notifications = await _notificationsService.getReceivedAlerts();
      if (!mounted) return;
      setState(() {
        _notifications = notifications
            .map(ContactNotification.fromActivity)
            .toList(growable: false);
        _isLoading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    if (_isLoading) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: VoisaLoadingView(message: 'Loading activity...'),
      );
    }

    if (_error != null) {
      return Scaffold(
        backgroundColor: AppColors.background,
        body: VoisaErrorView(message: _error, onRetry: _loadNotifications),
      );
    }

    if (_notifications.isEmpty) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: VoisaEmptyView(
          message: 'No safety activity yet.',
          icon: Icons.notifications_none_rounded,
        ),
      );
    }

    final sortedNotifications = List<ContactNotification>.from(_notifications)
      ..sort((a, b) {
        final statusPriority = {
          SafetyStatus.emergency: 0,
          SafetyStatus.needsAttention: 1,
          SafetyStatus.inTransit: 2,
          SafetyStatus.safe: 3,
        };
        return (statusPriority[a.safetyStatus] ?? 4)
            .compareTo(statusPriority[b.safetyStatus] ?? 4);
      });

    return Scaffold(
      backgroundColor: AppColors.background,
      body: RefreshIndicator(
        onRefresh: _loadNotifications,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(
            parent: BouncingScrollPhysics(),
          ),
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.only(
                  top: topPadding + AppSpacing.md,
                  left: AppSpacing.screenH,
                  right: AppSpacing.screenH,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Activity', style: AppTextStyles.displayLarge),
                        _LiveIndicator(),
                      ],
                    ),
                    const SizedBox(height: AppSpacing.sm),
                    Text(
                      '${_notifications.where((n) => n.safetyStatus == SafetyStatus.emergency).length} urgent',
                      style: AppTextStyles.caption.copyWith(
                        color: AppColors.error,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: AppSpacing.lg),
                  ],
                ),
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final n = sortedNotifications[index];
                  return Padding(
                    padding: const EdgeInsets.only(
                      left: AppSpacing.screenH,
                      right: AppSpacing.screenH,
                      bottom: AppSpacing.sm,
                    ),
                    child: _NotificationCard(
                      notification: n,
                      onViewDetails: () {
                        // TODO: navigate to detail
                      },
                      onTrackLocation: () {
                        // TODO: open map tracking
                      },
                      onRequestLocation: () {
                        // TODO: request location update
                      },
                    ),
                  );
                },
                childCount: sortedNotifications.length,
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.only(
                  top: AppSpacing.lg,
                  bottom: AppSpacing.xl + bottomPadding,
                ),
                child: Center(
                  child: TextButton(
                    onPressed: () {
                      // TODO: navigate to history screen
                    },
                    child: Text(
                      'View full history',
                      style: AppTextStyles.buttonLabel.copyWith(
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Notification Card ────────────────────────────────────────────────────────
class _NotificationCard extends StatelessWidget {
  const _NotificationCard({
    required this.notification,
    required this.onViewDetails,
    required this.onTrackLocation,
    required this.onRequestLocation,
  });

  final ContactNotification notification;
  final VoidCallback onViewDetails;
  final VoidCallback onTrackLocation;
  final VoidCallback onRequestLocation;

  bool get _isEmergency => notification.safetyStatus == SafetyStatus.emergency;
  bool get _needsAttention =>
      notification.safetyStatus == SafetyStatus.needsAttention;
  bool get _canTrack =>
      notification.safetyStatus == SafetyStatus.inTransit ||
      notification.isLive;

  @override
  Widget build(BuildContext context) {
    final statusColor = notification.safetyStatus.color;

    return Container(
      decoration: BoxDecoration(
        color: _isEmergency
            ? AppColors.error.withValues(alpha: 0.05)
            : AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: _isEmergency
            ? Border.all(
                color: AppColors.error.withValues(alpha: 0.3), width: 1.5)
            : null,
        boxShadow: _isEmergency
            ? [
                BoxShadow(
                  color: AppColors.error.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.md),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top row: Status badge + Live indicator + Time
            Row(
              children: [
                // Status indicator
                _StatusBadge(status: notification.safetyStatus),
                const Spacer(),
                // Live indicator
                if (notification.isLive) _LivePulse(),
                const SizedBox(width: AppSpacing.sm),
                // Last updated
                if (notification.lastUpdated != null)
                  Text(
                    notification.lastUpdated!,
                    style: AppTextStyles.caption.copyWith(
                      fontSize: 11,
                      color: _isEmergency
                          ? AppColors.error
                          : AppColors.textSecondary,
                      fontWeight:
                          _isEmergency ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),

            // Main content: Avatar + Name + Situation
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Status-colored avatar ring for emergency/attention
                Container(
                  decoration: _isEmergency || _needsAttention
                      ? BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: statusColor, width: 2),
                        )
                      : null,
                  child: ContactAvatar(
                    imageUrl: notification.imageUrl,
                    name: notification.name,
                    radius: 20,
                    color: statusColor.withValues(alpha: 0.2),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Name + relation
                      Row(
                        children: [
                          Text(
                            notification.name,
                            style: AppTextStyles.cardTitle.copyWith(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(width: AppSpacing.xs),
                          Text(
                            '• ${notification.relation}',
                            style: AppTextStyles.caption.copyWith(fontSize: 12),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      // Situation description
                      if (notification.locationDescription != null)
                        Text(
                          '${notification.timeAgo} • ${notification.locationDescription}',
                          style: AppTextStyles.body.copyWith(
                            fontSize: 13,
                            color: _isEmergency
                                ? AppColors.textPrimary
                                : AppColors.textSecondary,
                            fontWeight: _isEmergency
                                ? FontWeight.w500
                                : FontWeight.normal,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                    ],
                  ),
                ),
              ],
            ),

            // Action buttons
            const SizedBox(height: AppSpacing.md),
            _buildActions(),
          ],
        ),
      ),
    );
  }

  Widget _buildActions() {
    return Row(
      children: [
        if (_canTrack)
          Expanded(
            child: _ActionButton(
              icon: Icons.location_searching_rounded,
              label: 'Track Location',
              onTap: onTrackLocation,
              isPrimary: true,
              color: AppColors.primary,
            ),
          )
        else if (notification.safetyStatus == SafetyStatus.safe)
          Expanded(
            child: _ActionButton(
              icon: Icons.check_circle_outline_rounded,
              label: 'View Details',
              onTap: onViewDetails,
              isPrimary: false,
              color: AppColors.textSecondary,
            ),
          )
        else if (_needsAttention)
          Expanded(
            child: _ActionButton(
              icon: Icons.location_on_outlined,
              label: 'Request Location',
              onTap: onRequestLocation,
              isPrimary: true,
              color: AppColors.primary,
            ),
          )
        else if (_isEmergency)
          Expanded(
            child: _ActionButton(
              icon: Icons.emergency_rounded,
              label: 'View Emergency',
              onTap: onViewDetails,
              isPrimary: true,
              color: AppColors.error,
            ),
          ),
      ],
    );
  }
}

// ─── Status Badge ─────────────────────────────────────────────────────────────
class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.status});

  final SafetyStatus status;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: status.color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            status.icon,
            size: 12,
            color: status.color,
          ),
          const SizedBox(width: 4),
          Text(
            status.label,
            style: AppTextStyles.caption.copyWith(
              fontSize: 11,
              color: status.color,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Live Pulse Indicator ─────────────────────────────────────────────────────
class _LivePulse extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 6,
          height: 6,
          decoration: BoxDecoration(
            color: const Color(0xFF27AE60),
            borderRadius: BorderRadius.circular(3),
          ),
        ),
        const SizedBox(width: 4),
        Text(
          'LIVE',
          style: AppTextStyles.caption.copyWith(
            fontSize: 10,
            color: const Color(0xFF27AE60),
            fontWeight: FontWeight.w800,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }
}

// ─── Action Button ────────────────────────────────────────────────────────────
class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.isPrimary,
    required this.color,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isPrimary;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding:
            const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: 10),
        decoration: BoxDecoration(
          color: isPrimary ? color.withValues(alpha: 0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(AppRadius.pill),
          border: isPrimary ? null : Border.all(color: AppColors.divider),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(width: 6),
            Text(
              label,
              style: AppTextStyles.buttonLabel.copyWith(
                fontSize: 12,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Live Indicator (Header) ──────────────────────────────────────────────────
class _LiveIndicator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFF27AE60).withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(AppRadius.pill),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              color: const Color(0xFF27AE60),
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 6),
          Text(
            'Live Updates',
            style: AppTextStyles.caption.copyWith(
              fontSize: 11,
              color: const Color(0xFF27AE60),
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
