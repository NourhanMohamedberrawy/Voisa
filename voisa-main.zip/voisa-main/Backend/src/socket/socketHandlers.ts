import { Server, Socket } from 'socket.io';
import jwt from 'jsonwebtoken';
import mongoose from 'mongoose';
import { v4 as uuidv4 } from 'uuid';
import EmergencyEvent from '../models/EmergencyEvent';
import Notification from '../models/Notification';
import { analyzeAudio } from '../services/aiService';
import { triggerEmergencyAlert, resolveEmergencyEvent } from '../services/alertService';
import { sendCheckInPing } from '../services/fcmService';

// ─────────────────────────────────────────────────────────────────────────────
// WEBSOCKET HANDLERS
//
// Events Flutter SENDS:
//   join_session    — authenticate the WebSocket connection
//   audio_chunk     — audio after Porcupine detects keyword
//   checkin_response— user responded "I'm ok" to a check-in ping
//   gps_update      — GPS coordinates during active distress
//   cancel_sos      — user is safe / canceled
//   squad_ack       — squad member is responding
//
// Events Backend SENDS:
//   session_joined      — auth confirmed
//   auth_error          — bad/missing token
//   ai_result           — classification result
//   check_in            — AI was uncertain, asking user "are you ok?"
//   distress_confirmed  — AI confirmed distress, squad alerted
//   squad_responding    — a squad member acknowledged
//   emergency_alert     — sent to squad members
//   location_update     — live GPS sent to squad
//   emergency_resolved  — event ended
//   cancel_sos_result   — confirmation of cancellation
//   server_error        — unexpected error
// ─────────────────────────────────────────────────────────────────────────────

interface JwtPayload { userId: string; }

const activeDistressSessions = new Map<string, string>();
const checkInTimers = new Map<string, ReturnType<typeof setTimeout>>();

export const registerSocketHandlers = (io: Server): void => {
  io.on('connection', (socket: Socket) => {
    console.log(`  WS connect: ${socket.id}`);

    socket.on('join_session', (data: { token: string }) => {
      try {
        if (!data?.token) {
          socket.emit('auth_error', { message: 'No token provided' });
          return;
        }
        const decoded = jwt.verify(data.token, process.env.JWT_SECRET!) as JwtPayload;
        (socket as any).userId = decoded.userId;
        socket.join(`user_${decoded.userId}`);
        console.log(`  Session joined: ${decoded.userId}`);
        socket.emit('session_joined', {
          message: 'Connected to safety server',
          userId: decoded.userId,
          socketId: socket.id,
          timestamp: new Date().toISOString(),
        });
      } catch {
        socket.emit('auth_error', { message: 'Invalid or expired token' });
      }
    });

    socket.on('audio_chunk', async (data: {
      audioBase64: string;
      lat: number;
      lng: number;
      triggerType?: 'keyword' | 'scream' | 'manual' | 'shake';
      idempotencyKey?: string;
    }) => {
      const userId = (socket as any).userId as string | undefined;
      if (!userId) { socket.emit('auth_error', { message: 'Not authenticated' }); return; }

      if (activeDistressSessions.has(userId)) {
        socket.emit('ai_result', { result: 'already_active', message: 'Distress event already active' });
        return;
      }

      try {
        const aiResult = await analyzeAudio(data.audioBase64, userId);

        socket.emit('ai_result', {
          result: aiResult.result,
          confidence: aiResult.confidence,
          stressScore: aiResult.stressScore,
          model: aiResult.model,
          processingTimeMs: aiResult.processingTimeMs,
        });

        if (aiResult.result === 'uncertain') {
          console.log(`  Uncertain result for ${userId} — sending check-in`);
          socket.emit('check_in', {
            message: 'Are you ok? Tap to confirm or stay silent to trigger alert.',
            countdownSeconds: 15,
            aiConfidence: aiResult.confidence,
          });

          const { default: User } = await import('../models/User');
          const user = await User.findById(userId).select('fcmToken');
          if (user?.fcmToken) {
            await sendCheckInPing(user.fcmToken, 'pending-' + userId);
          }

          const timer = setTimeout(async () => {
            if (!activeDistressSessions.has(userId)) {
              console.log(`  Check-in timeout for ${userId} — auto-escalating`);
              await escalateToFullAlert(socket, io, userId, data, aiResult.confidence, aiResult.stressScore);
            }
            checkInTimers.delete(userId);
          }, 15000);

          checkInTimers.set(userId, timer);
          return;
        }

        if (aiResult.result === 'safe') {
          console.log(`   AI returned 'safe' for ${userId}`);
          return;
        }

        await escalateToFullAlert(socket, io, userId, data, aiResult.confidence, aiResult.stressScore);

      } catch (error) {
        console.error('audio_chunk error:', error);
        socket.emit('server_error', { message: 'Failed to process audio' });
      }
    });

    socket.on('checkin_response', (data: { response: 'safe' | 'sos' }) => {
      const userId = (socket as any).userId as string | undefined;
      if (!userId) return;

      const timer = checkInTimers.get(userId);
      if (timer) {
        clearTimeout(timer);
        checkInTimers.delete(userId);
      }

      if (data.response === 'sos') {
        socket.emit('server_error', { message: 'Manual SOS trigger — resend audio_chunk' });
      } else {
        socket.emit('cancel_sos_result', {
          success: true,
          status: 'canceled',
          message: 'Check-in confirmed — you are safe',
        });
      }
    });

    socket.on('gps_update', async (data: { lat: number; lng: number }) => {
      const userId = (socket as any).userId as string | undefined;
      if (!userId) return;

      const eventId = activeDistressSessions.get(userId);
      if (!eventId) return;

      try {
        const locationPoint = { lat: data.lat, lng: data.lng, timestamp: new Date() };
        await EmergencyEvent.findByIdAndUpdate(eventId, {
          $push: { locationPath: locationPoint },
        });

        const event = await EmergencyEvent.findById(eventId).select('squadNotified');
        if (event) {
          event.squadNotified.forEach((memberId) => {
            io.to(`user_${memberId.toString()}`).emit('location_update', {
              eventId,
              victimId: userId,
              lat: data.lat,
              lng: data.lng,
              timestamp: new Date().toISOString(),
            });
          });
        }
      } catch (error) {
        console.error('gps_update error:', error);
      }
    });

    socket.on('cancel_sos', async (data: { reason?: 'resolved' | 'canceled' | 'false_alarm' }) => {
      const userId = (socket as any).userId as string | undefined;
      if (!userId) return;

      const timer = checkInTimers.get(userId);
      if (timer) { clearTimeout(timer); checkInTimers.delete(userId); }

      const eventId = activeDistressSessions.get(userId);
      if (!eventId) {
        socket.emit('cancel_sos_result', { success: false, message: 'No active SOS session' });
        return;
      }

      try {
        const status = data?.reason || 'resolved';
        await resolveEmergencyEvent(eventId, userId, io, status as any);
        activeDistressSessions.delete(userId);
        socket.emit('cancel_sos_result', {
          success: true,
          eventId,
          status,
          message: 'SOS cancelled — squad notified you are safe',
        });
      } catch (error) {
        console.error('cancel_sos error:', error);
        socket.emit('server_error', { message: 'Failed to cancel SOS' });
      }
    });

    socket.on('squad_ack', async (data: { eventId: string; victimId: string }) => {
      const responderId = (socket as any).userId as string | undefined;
      if (!responderId) return;

      try {
        if (!mongoose.Types.ObjectId.isValid(data.eventId) || !mongoose.Types.ObjectId.isValid(data.victimId)) {
          socket.emit('server_error', { message: 'Invalid eventId or victimId' });
          return;
        }

        await Notification.findOneAndUpdate(
          {
            eventId: new mongoose.Types.ObjectId(data.eventId),
            recipientId: new mongoose.Types.ObjectId(responderId),
          },
          { acknowledged: true, acknowledgedAt: new Date(), deliveryStatus: 'delivered' }
        );

        const { default: User } = await import('../models/User');
        const responder = await User.findById(responderId).select('name');

        io.to(`user_${data.victimId}`).emit('squad_responding', {
          responderName: responder?.name || 'A squad member',
          responderId,
          eventId: data.eventId,
          message: `${responder?.name || 'A squad member'} is on their way!`,
          timestamp: new Date().toISOString(),
        });

        socket.emit('ack_confirmed', { message: 'Response logged. User has been notified.' });
        console.log(`  Squad ack: ${responder?.name} → event ${data.eventId}`);
      } catch (error) {
        console.error('squad_ack error:', error);
        socket.emit('server_error', { message: 'Failed to process acknowledgment' });
      }
    });

    socket.on('disconnect', (reason) => {
      const userId = (socket as any).userId;
      console.log(`  WS disconnect: ${socket.id}${userId ? ` (${userId})` : ''} — ${reason}`);
    });
  });

  console.log('  WebSocket handlers registered');
};

async function escalateToFullAlert(
  socket: Socket,
  io: Server,
  userId: string,
  data: { audioBase64: string; lat: number; lng: number; triggerType?: any; idempotencyKey?: string },
  aiConfidence: number,
  stressScore: number
) {
  const idempotencyKey = data.idempotencyKey || uuidv4();

  const alertResult = await triggerEmergencyAlert({
    userId,
    idempotencyKey,
    triggerType: data.triggerType || 'keyword',
    aiConfidence,
    stressScore,
    initialLat: data.lat,
    initialLng: data.lng,
    io,
  });

  activeDistressSessions.set(userId, alertResult.event._id.toString());

  socket.emit('distress_confirmed', {
    eventId: alertResult.event._id.toString(),
    squadAlertedCount: alertResult.squadAlertedCount,
    notificationSummary: alertResult.notificationSummary,
    wasIdempotentDuplicate: alertResult.wasIdempotentDuplicate,
    message: alertResult.squadAlertedCount > 0
      ? `Alert sent to ${alertResult.squadAlertedCount} squad member(s)`
      : 'Alert created but no squad members configured',
    timestamp: new Date().toISOString(),
  });
}
