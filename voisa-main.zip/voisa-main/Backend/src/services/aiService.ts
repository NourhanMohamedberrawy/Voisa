export interface AIAnalysisResult {
  result: 'distress' | 'safe' | 'uncertain';
  confidence: number;
  stressScore: number;
  model: string;
  processingTimeMs: number;
}

export const analyzeAudio = async (
  audioBase64: string,
  userId: string
): Promise<AIAnalysisResult> => {
  const startTime = Date.now();

  await new Promise((resolve) => setTimeout(resolve, 300));

  const processingTimeMs = Date.now() - startTime;

  const rand = Math.random();
  let result: 'distress' | 'safe' | 'uncertain';
  let confidence: number;

  if (rand < 0.70) {
    result = 'distress';
    confidence = parseFloat((0.81 + Math.random() * 0.18).toFixed(2));
  } else if (rand < 0.85) {
    result = 'uncertain';
    confidence = parseFloat((0.50 + Math.random() * 0.30).toFixed(2));
  } else {
    result = 'safe';
    confidence = parseFloat((0.60 + Math.random() * 0.35).toFixed(2));
  }

  const stressScore = result === 'distress'
    ? Math.round(70 + Math.random() * 29)
    : result === 'uncertain'
    ? Math.round(40 + Math.random() * 30)
    : Math.round(10 + Math.random() * 30);

  const mockResult: AIAnalysisResult = {
    result,
    confidence,
    stressScore,
    model: 'HuBERT-mock-v1',
    processingTimeMs,
  };

  console.log(
    `   AI [userId:${userId.substring(0,8)}]: ` +
    `${mockResult.result.toUpperCase()} ` +
    `(conf:${mockResult.confidence} stress:${mockResult.stressScore} ${mockResult.processingTimeMs}ms)`
  );

  return mockResult;
};
