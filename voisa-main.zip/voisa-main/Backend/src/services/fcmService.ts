import admin from 'firebase-admin';
import path from 'path';
import fs from 'fs';

let firebaseInitialized = false;

const initializeFirebase = (): void => {
  if (firebaseInitialized) return;
  const serviceAccountPath = path.resolve(
    process.env.FIREBASE_SERVICE_ACCOUNT_PATH || './firebase-service-account.json'
  );
  if (fs.existsSync(serviceAccountPath)) {
    try {
      const serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, 'utf8'));
      admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
      firebaseInitialized = true;
      console.log('   Firebase Admin SDK initialized');
    } catch (err) {
      console.warn('    Firebase init failed — running in mock mode:', err);
    }
  } else {
    console.warn(
      '    firebase-service-account.json not found — FCM running in MOCK mode.\n' +
      '   Push notifications will be logged to console only.'
    );
  }
};

initializeFirebase();

export interface FCMResult {
  messageId: string | null;
  success: boolean;
  providerResponse: string;
}

export const sendEmergencyAlert = async (
  fcmToken: string,
  victimName: string,
  eventId: string,
  lat: number,
  lng: number
): Promise<FCMResult> => {
  const title = `Emergency: ${victimName} needs help`;
  const body = `Location: ${lat.toFixed(5)}, ${lng.toFixed(5)} — Tap to track`;

  if (!firebaseInitialized) {
    console.log('\n  [FCM MOCK] Emergency alert:');
    console.log(`   Token: ${fcmToken.substring(0, 20)}...`);
    console.log(`   Title: ${title}`);
    console.log(`   Data: eventId=${eventId}\n`);
    return {
      messageId: 'mock-' + Date.now(),
      success: true,
      providerResponse: 'mock_mode',
    };
  }

  try {
    const messageId = await admin.messaging().send({
      token: fcmToken,
      notification: { title, body },
      data: {
        eventId,
        type: 'EMERGENCY_ALERT',
        victimName,
        lat: lat.toString(),
        lng: lng.toString(),
      },
      android: {
        priority: 'high',
        notification: {
          channelId: 'emergency_alerts',
          priority: 'max',
          defaultVibrateTimings: true,
          defaultSound: true,
        },
      },
      apns: {
        headers: { 'apns-priority': '10' },
        payload: { aps: { sound: 'default', badge: 1, contentAvailable: true } },
      },
    });
    return { messageId, success: true, providerResponse: messageId };
  } catch (error: any) {
    console.error(`  FCM failed for token ${fcmToken.substring(0, 20)}...:`, error?.message);
    return {
      messageId: null,
      success: false,
      providerResponse: error?.message || 'unknown_error',
    };
  }
};

export const sendCheckInPing = async (
  fcmToken: string,
  eventId: string
): Promise<FCMResult> => {
  if (!firebaseInitialized) {
    console.log(`  [FCM MOCK] Check-in ping for event ${eventId}`);
    return { messageId: 'mock-checkin-' + Date.now(), success: true, providerResponse: 'mock_mode' };
  }
  try {
    const messageId = await admin.messaging().send({
      token: fcmToken,
      data: { type: 'CHECK_IN_PING', eventId },
      android: { priority: 'high' },
      apns: { headers: { 'apns-priority': '10' } },
    });
    return { messageId, success: true, providerResponse: messageId };
  } catch (error: any) {
    return { messageId: null, success: false, providerResponse: error?.message || 'unknown_error' };
  }
};
