import mongoose from 'mongoose';
import { Server } from 'socket.io';
import User from '../models/User';
import EmergencyEvent, { IEmergencyEvent, EventStatus } from '../models/EmergencyEvent';
import Notification from '../models/Notification';
import { sendEmergencyAlert } from './fcmService';

const DEDUPLICATION_COOLDOWN_MS = 60 * 1000;

export interface TriggerAlertParams {
  userId: string;
  idempotencyKey: string;
  triggerType: 'keyword' | 'scream' | 'manual' | 'shake';
  aiConfidence: number;
  stressScore: number;
  initialLat: number;
  initialLng: number;
  io: Server;
}

export interface AlertResult {
  event: IEmergencyEvent;
  squadAlertedCount: number;
  notificationSummary: { total: number; sent: number; failed: number };
  wasIdempotentDuplicate: boolean;
}

export const triggerEmergencyAlert = async (
  params: TriggerAlertParams
): Promise<AlertResult> => {
  const { userId, idempotencyKey, triggerType, aiConfidence, stressScore, initialLat, initialLng, io } = params;

  const existingEvent = await EmergencyEvent.findOne({ idempotencyKey });
  if (existingEvent) {
    console.log(`♻️  Idempotent request — returning existing event ${existingEvent._id}`);
    return {
      event: existingEvent,
      squadAlertedCount: existingEvent.squadNotified.length,
      notificationSummary: existingEvent.notificationSummary,
      wasIdempotentDuplicate: true,
    };
  }

  const recentActive = await EmergencyEvent.findOne({
    userId: new mongoose.Types.ObjectId(userId),
    status: { $in: ['created', 'notifying', 'active', 'pending_confirmation'] },
    startTime: { $gte: new Date(Date.now() - DEDUPLICATION_COOLDOWN_MS) },
  });

  if (recentActive) {
    console.log(`    Duplicate active event blocked for user ${userId}`);
    return {
      event: recentActive,
      squadAlertedCount: recentActive.squadNotified.length,
      notificationSummary: recentActive.notificationSummary,
      wasIdempotentDuplicate: true,
    };
  }

  console.log(`\n   DISTRESS CONFIRMED [userId:${userId.substring(0,8)}]`);
  console.log(`   Trigger:${triggerType} Confidence:${aiConfidence} Stress:${stressScore}`);

  const event = await EmergencyEvent.create({
    userId: new mongoose.Types.ObjectId(userId),
    idempotencyKey,
    status: 'created' as EventStatus,
    triggerType,
    aiConfidence,
    startTime: new Date(),
    locationSnapshot: { lat: initialLat, lng: initialLng, timestamp: new Date() },
    locationPath: [{ lat: initialLat, lng: initialLng, timestamp: new Date() }],
    squadNotified: [],
    notificationSummary: { total: 0, sent: 0, failed: 0 },
  });

  console.log(`      Event created: ${event._id}`);

  await EmergencyEvent.findByIdAndUpdate(event._id, { status: 'notifying' });

  const victim = await User.findById(userId).populate<{
    squad: Array<{
      userId: { _id: mongoose.Types.ObjectId; name: string; email: string; fcmToken?: string };
      order: number;
      isPrimary: boolean;
      channels: string[];
      nickname?: string;
    }>;
  }>({
    path: 'squad.userId',
    select: 'name email fcmToken',
  });

  if (!victim) throw new Error(`User ${userId} not found`);

  if (victim.squad.length === 0) {
    await EmergencyEvent.findByIdAndUpdate(event._id, { status: 'active' });
    console.warn(`       No squad members configured`);
    return {
      event,
      squadAlertedCount: 0,
      notificationSummary: { total: 0, sent: 0, failed: 0 },
      wasIdempotentDuplicate: false,
    };
  }

  const sortedSquad = [...victim.squad].sort((a, b) => a.order - b.order);
  let sentCount = 0;
  let failedCount = 0;
  const squadIdsNotified: mongoose.Types.ObjectId[] = [];

  const notificationPromises = sortedSquad.map(async (member) => {
    const memberUser = member.userId;
    if (!memberUser || !memberUser._id) return;

    const fcmResult = memberUser.fcmToken
      ? await sendEmergencyAlert(
          memberUser.fcmToken,
          victim.name,
          event._id.toString(),
          initialLat,
          initialLng
        )
      : { messageId: null, success: false, providerResponse: 'no_fcm_token' };

    if (fcmResult.success) sentCount++;
    else failedCount++;

    await Notification.create({
      eventId: event._id,
      recipientId: memberUser._id,
      senderId: new mongoose.Types.ObjectId(userId),
      channel: 'fcm',
      fcmMessageId: fcmResult.messageId,
      deliveryStatus: fcmResult.success ? 'sent' : 'failed',
      retryCount: 0,
      maxRetries: 3,
      providerResponse: fcmResult.providerResponse,
    });

    squadIdsNotified.push(memberUser._id);

    io.to(`user_${memberUser._id.toString()}`).emit('emergency_alert', {
      eventId: event._id.toString(),
      victimName: victim.name,
      victimId: userId,
      lat: initialLat,
      lng: initialLng,
      aiConfidence,
      stressScore,
      timestamp: new Date().toISOString(),
      message: `${victim.name} needs help RIGHT NOW`,
    });

    console.log(`      Alerted: ${memberUser.name} (${fcmResult.success ? 'sent' : 'FAILED'})`);
  });

  await Promise.all(notificationPromises);

  const finalStatus: EventStatus =
    failedCount === 0 ? 'active' :
    sentCount === 0 ? 'active' :
    'notification_partial_failure';

  const summary = {
    total: sortedSquad.length,
    sent: sentCount,
    failed: failedCount,
  };

  await EmergencyEvent.findByIdAndUpdate(event._id, {
    status: finalStatus,
    squadNotified: squadIdsNotified,
    notificationSummary: summary,
  });

  console.log(`      Status:${finalStatus} sent:${sentCount} failed:${failedCount}\n`);

  return {
    event,
    squadAlertedCount: sentCount,
    notificationSummary: summary,
    wasIdempotentDuplicate: false,
  };
};

export const resolveEmergencyEvent = async (
  eventId: string,
  userId: string,
  io: Server,
  status: 'resolved' | 'canceled' | 'false_alarm' = 'resolved'
): Promise<void> => {
  const event = await EmergencyEvent.findByIdAndUpdate(
    eventId,
    { status, resolvedTime: new Date() },
    { new: true }
  ).populate<{ squadNotified: Array<{ _id: mongoose.Types.ObjectId }> }>(
    'squadNotified', '_id'
  );

  if (!event) return;

  event.squadNotified.forEach((member) => {
    io.to(`user_${member._id.toString()}`).emit('emergency_resolved', {
      eventId,
      status,
      resolvedBy: userId,
      message:
        status === 'resolved' ? 'User has confirmed they are safe' :
        status === 'canceled' ? 'User cancelled before squad was notified' :
        'False alarm — user is safe',
      timestamp: new Date().toISOString(),
    });
  });

  console.log(`   Event ${eventId} → ${status}`);
};
