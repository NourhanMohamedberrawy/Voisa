import bcrypt from 'bcrypt';
import nodemailer from 'nodemailer';

const CODE_TTL_MINUTES = 10;

export const generateVerificationCode = (): string =>
  Math.floor(100000 + Math.random() * 900000).toString();

export const hashVerificationCode = (code: string): Promise<string> =>
  bcrypt.hash(code, 10);

export const compareVerificationCode = (
  code: string,
  hash: string
): Promise<boolean> => bcrypt.compare(code, hash);

export const verificationExpiry = (): Date =>
  new Date(Date.now() + CODE_TTL_MINUTES * 60 * 1000);

export const sendVerificationEmail = async (
  to: string,
  code: string
): Promise<void> => {
  const host = process.env.SMTP_HOST;
  const port = process.env.SMTP_PORT ? Number(process.env.SMTP_PORT) : 587;
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  const from = process.env.SMTP_FROM || user;

  if (!host || !user || !pass || !from) {
    console.warn(
      `Email verification code for ${to}: ${code} ` +
      '(SMTP env vars missing, email not sent)'
    );
    return;
  }

  const transporter = nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
  });

  await transporter.sendMail({
    from,
    to,
    subject: 'Your Voisa verification code',
    text: `Your Voisa verification code is ${code}. It expires in ${CODE_TTL_MINUTES} minutes.`,
    html: `
      <p>Your Voisa verification code is:</p>
      <p style="font-size: 28px; font-weight: 700; letter-spacing: 4px;">${code}</p>
      <p>This code expires in ${CODE_TTL_MINUTES} minutes.</p>
    `,
  });
};
