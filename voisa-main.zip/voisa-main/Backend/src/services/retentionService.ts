import mongoose from 'mongoose';
import AudioSnippet from '../models/AudioSnippet';

export const runRetentionCleanup = async (): Promise<void> => {
  const db = mongoose.connection.db;
  if (!db) {
    console.warn('Retention cleanup: DB not ready');
    return;
  }

  console.log('  Running audio retention cleanup...');

  const expiredSnippets = await AudioSnippet.find({
    retentionExpiresAt: { $lte: new Date() },
    status: 'active',
  });

  if (expiredSnippets.length === 0) {
    console.log('  No expired snippets found');
    return;
  }

  const bucket = new (require('mongoose/node_modules/mongodb').GridFSBucket)(db, {
    bucketName: 'evidence_audio',
  });

  let deleted = 0;
  let failed = 0;

  for (const snippet of expiredSnippets) {
    try {
      await bucket.delete(snippet.gridFsFileId);

      await AudioSnippet.findByIdAndUpdate(snippet._id, {
        status: 'deleted',
        deletedAt: new Date(),
      });

      deleted++;
    } catch (err) {
      console.error(`Failed to delete GridFS file ${snippet.gridFsFileId}:`, err);
      await AudioSnippet.findByIdAndUpdate(snippet._id, { status: 'expired' });
      failed++;
    }
  }

  console.log(`  Retention cleanup done: ${deleted} deleted, ${failed} failed`);
};
