import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import connectDB from './config/db';
import authRoutes from './routes/auth';
import userRoutes from './routes/users';
import eventRoutes from './routes/events';
import { registerSocketHandlers } from './socket/socketHandlers';
import { runRetentionCleanup } from './services/retentionService';

const app = express();
app.use(express.json({ limit: '10mb' }));
//#######################################
// for test
import cors from 'cors';
app.use(cors({ origin: '*' }));
//#######################################
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
  maxHttpBufferSize: 10 * 1024 * 1024,
});
app.set('io', io);

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/events', eventRoutes);

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', message: 'SafeGuard AI Backend', timestamp: new Date().toISOString() });
});

registerSocketHandlers(io);

const PORT = parseInt(process.env.PORT || '3000', 10);

const startServer = async () => {
  await connectDB();

  await runRetentionCleanup();
  setInterval(runRetentionCleanup, 24 * 60 * 60 * 1000);

  httpServer.listen(PORT, () => {
    console.log(`\n   SafeGuard AI Backend running on http://localhost:${PORT}`);
    console.log(`   WebSocket ready on ws://localhost:${PORT}`);
    console.log(`   Health: http://localhost:${PORT}/health\n`);
    console.log('   REST Endpoints:');
    console.log('   POST /api/auth/register');
    console.log('   POST /api/auth/login');
    console.log('   GET  /api/users/me                    [auth]');
    console.log('   DELETE /api/users/me                  [auth]');
    console.log('   GET  /api/users/contacts              [auth]');
    console.log('   POST /api/users/contacts              [auth]');
    console.log('   DELETE /api/users/contacts            [auth]');
    console.log('   GET  /api/users/squad                 [auth]');
    console.log('   PUT  /api/users/fcm-token             [auth]');
    console.log('   PUT  /api/users/squad/add             [auth]');
    console.log('   PUT  /api/users/squad/remove          [auth]');
    console.log('   GET  /api/events                      [auth]');
    console.log('   POST /api/events/trigger              [auth]');
    console.log('   GET  /api/events/:id                  [auth]');
    console.log('   GET  /api/events/:id/location         [auth]');
    console.log('   POST /api/events/:id/cancel           [auth]');
    console.log('   GET  /api/events/squad/received       [auth]');
    console.log('   POST /api/events/sync                 [auth] ← offline queue');
    console.log('   POST /api/events/:id/audio-chunk      [auth]');
    console.log('   GET  /api/events/:id/audio-chunks     [auth]\n');
    console.log('   WebSocket Events:');
    console.log('   Flutter → Backend: join_session, audio_chunk, checkin_response,');
    console.log('                      gps_update, cancel_sos, squad_ack');
    console.log('   Backend → Flutter: session_joined, ai_result, check_in,');
    console.log('                      distress_confirmed, squad_responding,');
    console.log('                      emergency_alert, location_update,');
    console.log('                      emergency_resolved, cancel_sos_result\n');
  });
};

startServer();
export { io };
