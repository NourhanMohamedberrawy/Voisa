import mongoose, { Document, Schema } from 'mongoose';

export type SnippetPurpose = 'distress_detection' | 'evidence_recording';
export type SnippetStatus = 'active' | 'expired' | 'deleted';

export interface IAudioSnippet extends Document {
  eventId: mongoose.Types.ObjectId;
  userId: mongoose.Types.ObjectId;
  gridFsFileId: mongoose.Types.ObjectId;
  purpose: SnippetPurpose;
  durationSeconds: number;
  fileSizeBytes: number;
  mimeType: string;
  chunkIndex: number;
  status: SnippetStatus;
  retentionExpiresAt: Date;
  deletedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

const AudioSnippetSchema = new Schema<IAudioSnippet>(
  {
    eventId: {
      type: Schema.Types.ObjectId,
      ref: 'EmergencyEvent',
      required: true,
      index: true,
    },

    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },

    gridFsFileId: {
      type: Schema.Types.ObjectId,
      required: true,
    },

    purpose: {
      type: String,
      enum: ['distress_detection', 'evidence_recording'],
      required: true,
    },

    durationSeconds: {
      type: Number,
      required: true,
      min: 0,
    },

    fileSizeBytes: {
      type: Number,
      required: true,
      min: 0,
    },

    mimeType: {
      type: String,
      default: 'audio/wav',
    },

    chunkIndex: {
      type: Number,
      default: 0,
    },

    status: {
      type: String,
      enum: ['active', 'expired', 'deleted'],
      default: 'active',
      index: true,
    },

    retentionExpiresAt: {
      type: Date,
      default: () => new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      index: true,
    },

    deletedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

AudioSnippetSchema.index({ retentionExpiresAt: 1, status: 1 });

export default mongoose.model<IAudioSnippet>('AudioSnippet', AudioSnippetSchema);
