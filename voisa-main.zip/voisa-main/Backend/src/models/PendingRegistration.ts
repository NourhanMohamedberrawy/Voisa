import mongoose, { Document, Schema } from 'mongoose';

export interface IPendingRegistration extends Document {
  name: string;
  email: string;
  passwordHash: string;
  verificationCodeHash: string;
  verificationExpiresAt: Date;
  createdAt: Date;
  updatedAt: Date;
}

const PendingRegistrationSchema = new Schema<IPendingRegistration>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 50,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      match: /^\S+@\S+\.\S+$/,
    },
    passwordHash: {
      type: String,
      required: true,
    },
    verificationCodeHash: {
      type: String,
      required: true,
    },
    verificationExpiresAt: {
      type: Date,
      required: true,
      index: { expires: 0 },
    },
  },
  { timestamps: true }
);

export default mongoose.model<IPendingRegistration>(
  'PendingRegistration',
  PendingRegistrationSchema
);
