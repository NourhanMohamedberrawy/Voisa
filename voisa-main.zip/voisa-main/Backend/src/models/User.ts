import mongoose, { Document, Schema } from 'mongoose';
import bcrypt from 'bcrypt';

export interface ISquadMember {
  userId: mongoose.Types.ObjectId;
  order: number;
  isPrimary: boolean;
  channels: ('fcm' | 'sms')[];
  nickname?: string;
  isValid: boolean;
}

export interface IEmergencyContact {
  name: string;
  phone: string;
  relation: string;
  deviceContactId?: string;
  createdAt: Date;
}

export interface IUser extends Document {
  name: string;
  email: string;
  passwordHash: string;
  isEmailVerified: boolean;
  fcmToken?: string;
  emergencyContacts: IEmergencyContact[];
  squad: ISquadMember[];
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

const SquadMemberSchema = new Schema<ISquadMember>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    order: {
      type: Number,
      default: 1,
      min: 1,
      max: 5,
    },
    isPrimary: {
      type: Boolean,
      default: false,
    },
    channels: {
      type: [String],
      enum: ['fcm', 'sms'],
      default: ['fcm'],
    },
    nickname: {
      type: String,
      default: null,
      maxlength: 30,
    },
    isValid: {
      type: Boolean,
      default: true,
    },
  },
  { _id: false }
);

const EmergencyContactSchema = new Schema<IEmergencyContact>(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 80,
    },
    phone: {
      type: String,
      required: true,
      trim: true,
      maxlength: 30,
    },
    relation: {
      type: String,
      required: true,
      trim: true,
      default: 'Contact',
      maxlength: 30,
    },
    deviceContactId: {
      type: String,
      default: null,
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { _id: true }
);

const UserSchema = new Schema<IUser>(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
      minlength: [2, 'Name must be at least 2 characters'],
      maxlength: [50, 'Name cannot exceed 50 characters'],
    },

    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email address'],
    },

    passwordHash: {
      type: String,
      required: [true, 'Password is required'],
    },

    isEmailVerified: {
      type: Boolean,
      default: false,
    },

    fcmToken: {
      type: String,
      default: null,
    },

    emergencyContacts: {
      type: [EmergencyContactSchema],
      default: [],
    },

    squad: {
      type: [SquadMemberSchema],
      default: [],
      validate: {
        validator: (v: ISquadMember[]) => v.length <= 5,
        message: 'Squad cannot exceed 5 members',
      },
    },

    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

UserSchema.pre('save', async function (next) {
  if (!this.isModified('passwordHash')) return next();
  if (/^\$2[aby]\$\d{2}\$/.test(this.passwordHash)) return next();
  const salt = await bcrypt.genSalt(12);
  this.passwordHash = await bcrypt.hash(this.passwordHash, salt);
  next();
});

UserSchema.methods.comparePassword = async function (
  candidatePassword: string
): Promise<boolean> {
  return bcrypt.compare(candidatePassword, this.passwordHash);
};

UserSchema.set('toJSON', {
  transform: (_doc, ret) => {
    delete (ret as any).passwordHash;
    return ret;
  },
});

export default mongoose.model<IUser>('User', UserSchema);
