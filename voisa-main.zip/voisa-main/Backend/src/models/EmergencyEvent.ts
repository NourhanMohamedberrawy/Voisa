import mongoose, { Document, Schema } from 'mongoose';

export type EventStatus =
  | 'created'
  | 'notifying'
  | 'active'
  | 'notification_partial_failure'
  | 'pending_confirmation'
  | 'resolved'
  | 'canceled'
  | 'false_alarm';

export type TriggerType = 'keyword' | 'scream' | 'manual' | 'shake';

export interface ILocationPoint {
  lat: number;
  lng: number;
  timestamp: Date;
}

export interface IEmergencyEvent extends Document {
  userId: mongoose.Types.ObjectId;
  idempotencyKey: string;
  status: EventStatus;
  triggerType: TriggerType;
  aiConfidence?: number;
  startTime: Date;
  resolvedTime?: Date;
  locationSnapshot: ILocationPoint;
  locationPath: ILocationPoint[];
  audioFileId?: mongoose.Types.ObjectId;
  squadNotified: mongoose.Types.ObjectId[];
  notificationSummary: {
    total: number;
    sent: number;
    failed: number;
  };
  createdAt: Date;
  updatedAt: Date;
}

const LocationPointSchema = new Schema<ILocationPoint>(
  {
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
    timestamp: { type: Date, default: Date.now },
  },
  { _id: false }
);

const EmergencyEventSchema = new Schema<IEmergencyEvent>(
  {
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },

    idempotencyKey: {
      type: String,
      required: true,
      unique: true,
    },

    status: {
      type: String,
      enum: [
        'created',
        'notifying',
        'active',
        'notification_partial_failure',
        'pending_confirmation',
        'resolved',
        'canceled',
        'false_alarm',
      ],
      default: 'created',
      index: true,
    },

    triggerType: {
      type: String,
      enum: ['keyword', 'scream', 'manual', 'shake'],
      required: true,
    },

    aiConfidence: {
      type: Number,
      min: 0,
      max: 1,
      default: null,
    },

    startTime: {
      type: Date,
      default: Date.now,
      index: true,
    },

    resolvedTime: {
      type: Date,
      default: null,
    },

    locationSnapshot: {
      type: LocationPointSchema,
      required: true,
    },

    locationPath: {
      type: [LocationPointSchema],
      default: [],
    },

    audioFileId: {
      type: Schema.Types.ObjectId,
      default: null,
    },

    squadNotified: [
      {
        type: Schema.Types.ObjectId,
        ref: 'User',
      },
    ],

    notificationSummary: {
      total: { type: Number, default: 0 },
      sent: { type: Number, default: 0 },
      failed: { type: Number, default: 0 },
    },
  },
  {
    timestamps: true,
  }
);

EmergencyEventSchema.index({ userId: 1, status: 1 });

export default mongoose.model<IEmergencyEvent>('EmergencyEvent', EmergencyEventSchema);
