import mongoose, { Document, Schema } from 'mongoose';

export interface INotification extends Document {
  eventId: mongoose.Types.ObjectId;
  recipientId: mongoose.Types.ObjectId;
  senderId: mongoose.Types.ObjectId;
  channel: 'fcm' | 'sms' | 'websocket';
  sentAt: Date;
  acknowledged: boolean;
  acknowledgedAt?: Date;
  fcmMessageId?: string;
  deliveryStatus: 'sent' | 'delivered' | 'failed' | 'retrying';
  retryCount: number;
  maxRetries: number;
  providerResponse?: string;
  createdAt: Date;
  updatedAt: Date;
}

const NotificationSchema = new Schema<INotification>(
  {
    eventId: {
      type: Schema.Types.ObjectId,
      ref: 'EmergencyEvent',
      required: true,
      index: true,
    },

    recipientId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },

    senderId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    channel: {
      type: String,
      enum: ['fcm', 'sms', 'websocket'],
      default: 'fcm',
    },

    sentAt: {
      type: Date,
      default: Date.now,
    },

    acknowledged: {
      type: Boolean,
      default: false,
    },

    acknowledgedAt: {
      type: Date,
      default: null,
    },

    fcmMessageId: {
      type: String,
      default: null,
    },

    deliveryStatus: {
      type: String,
      enum: ['sent', 'delivered', 'failed', 'retrying'],
      default: 'sent',
    },

    retryCount: {
      type: Number,
      default: 0,
    },

    maxRetries: {
      type: Number,
      default: 3,
    },

    providerResponse: {
      type: String,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

NotificationSchema.index({ eventId: 1, deliveryStatus: 1 });
NotificationSchema.index({ recipientId: 1, sentAt: -1 });

export default mongoose.model<INotification>('Notification', NotificationSchema);
