import { Response, Router } from 'express';
import mongoose from 'mongoose';
import { protect, AuthRequest } from '../middleware/auth';
import AudioSnippet from '../models/AudioSnippet';
import EmergencyEvent from '../models/EmergencyEvent';
import Notification from '../models/Notification';
import PendingRegistration from '../models/PendingRegistration';
import User from '../models/User';

const router = Router();
router.use(protect);

router.get('/me', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const user = await User.findById(req.user!.userId)
      .populate('squad.userId', 'name email isActive')
      .select('-passwordHash');

    if (!user) { res.status(404).json({ success: false, message: 'User not found' }); return; }
    res.status(200).json({ success: true, data: { user } });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.put('/fcm-token', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { fcmToken } = req.body;
    if (!fcmToken) { res.status(400).json({ success: false, message: 'fcmToken is required' }); return; }
    await User.findByIdAndUpdate(req.user!.userId, { fcmToken });
    res.status(200).json({ success: true, message: 'FCM token updated' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.get('/contacts', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const user = await User.findById(req.user!.userId).select('emergencyContacts');
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    res.status(200).json({
      success: true,
      data: { contacts: user.emergencyContacts },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.post('/contacts', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { contacts } = req.body;

    if (!Array.isArray(contacts) || contacts.length === 0) {
      res.status(400).json({ success: false, message: 'contacts must be a non-empty array' });
      return;
    }

    const user = await User.findById(req.user!.userId).select('emergencyContacts');
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    for (const contact of contacts) {
      const name = `${contact.name || ''}`.trim();
      const phone = `${contact.phone || ''}`.trim();
      const relation = `${contact.relation || 'Contact'}`.trim() || 'Contact';
      const deviceContactId = contact.deviceContactId ? `${contact.deviceContactId}` : undefined;

      if (!name || !phone) continue;

      const alreadyExists = user.emergencyContacts.some((existing) =>
        existing.phone.replace(/\s+/g, '') === phone.replace(/\s+/g, '')
      );

      if (!alreadyExists) {
        user.emergencyContacts.push({
          name,
          phone,
          relation,
          deviceContactId,
          createdAt: new Date(),
        } as any);
      }
    }

    await user.save();

    res.status(200).json({
      success: true,
      message: 'Emergency contacts updated',
      data: { contacts: user.emergencyContacts },
    });
  } catch (error) {
    console.error('Add contacts error:', error);
    res.status(500).json({ success: false, message: 'Server error while adding contacts' });
  }
});

router.delete('/contacts', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { contactIds } = req.body;

    if (!Array.isArray(contactIds) || contactIds.length === 0) {
      res.status(400).json({ success: false, message: 'contactIds must be a non-empty array' });
      return;
    }

    const user = await User.findById(req.user!.userId).select('emergencyContacts');
    if (!user) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    const removeSet = new Set(contactIds.map((id) => `${id}`));
    user.emergencyContacts = user.emergencyContacts.filter(
      (contact: any) => !removeSet.has(contact._id.toString())
    ) as any;
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Emergency contacts removed',
      data: { contacts: user.emergencyContacts },
    });
  } catch (error) {
    console.error('Remove contacts error:', error);
    res.status(500).json({ success: false, message: 'Server error while removing contacts' });
  }
});

router.delete('/me', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = new mongoose.Types.ObjectId(req.user!.userId);
    const user = await User.findById(userId).select('email');

    if (!user) {
      res.status(404).json({ success: false, message: 'User not found' });
      return;
    }

    await Promise.all([
      User.updateMany({}, { $pull: { squad: { userId } } }),
      EmergencyEvent.deleteMany({ userId }),
      Notification.deleteMany({ $or: [{ senderId: userId }, { recipientId: userId }] }),
      AudioSnippet.deleteMany({ userId }),
      PendingRegistration.deleteMany({ email: user.email }),
      User.deleteOne({ _id: userId }),
    ]);

    res.status(200).json({ success: true, message: 'Account deleted' });
  } catch (error) {
    console.error('Account deletion error:', error);
    res.status(500).json({ success: false, message: 'Server error while deleting account' });
  }
});

router.put('/squad/add', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { email, isPrimary, channels, nickname } = req.body;
    const currentUserId = req.user!.userId;

    if (!email) { res.status(400).json({ success: false, message: 'Email is required' }); return; }

    const targetUser = await User.findOne({ email: email.toLowerCase() });
    if (!targetUser) { res.status(404).json({ success: false, message: 'No user with that email' }); return; }
    if (targetUser._id.toString() === currentUserId) {
      res.status(400).json({ success: false, message: 'Cannot add yourself' });
      return;
    }

    const currentUser = await User.findById(currentUserId);
    if (!currentUser) { res.status(404).json({ success: false, message: 'User not found' }); return; }

    const alreadyInSquad = currentUser.squad.some(m => m.userId.toString() === targetUser._id.toString());
    if (alreadyInSquad) { res.status(409).json({ success: false, message: 'Already in squad' }); return; }
    if (currentUser.squad.length >= 5) { res.status(400).json({ success: false, message: 'Squad max 5 members' }); return; }

    const newOrder = currentUser.squad.length + 1;

    await User.findByIdAndUpdate(currentUserId, {
      $push: {
        squad: {
          userId: targetUser._id,
          order: newOrder,
          isPrimary: isPrimary || newOrder === 1,
          channels: channels || ['fcm'],
          nickname: nickname || null,
          isValid: true,
        },
      },
    });

    res.status(200).json({
      success: true,
      message: `${targetUser.name} added to squad`,
      data: { addedUser: { _id: targetUser._id, name: targetUser.name, email: targetUser.email } },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.put('/squad/remove', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { userId: targetUserId } = req.body;
    if (!targetUserId || !mongoose.Types.ObjectId.isValid(targetUserId)) {
      res.status(400).json({ success: false, message: 'Valid userId is required' });
      return;
    }
    await User.findByIdAndUpdate(req.user!.userId, {
      $pull: { squad: { userId: new mongoose.Types.ObjectId(targetUserId) } },
    });
    res.status(200).json({ success: true, message: 'Squad member removed' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.get('/squad', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const user = await User.findById(req.user!.userId)
      .populate('squad.userId', 'name email isActive');
    if (!user) { res.status(404).json({ success: false, message: 'User not found' }); return; }
    res.status(200).json({
      success: true,
      data: { squad: user.squad, squadCount: user.squad.length },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

export default router;
