import { Response, Router } from 'express';
import mongoose from 'mongoose';
import { GridFSBucket } from 'mongoose/node_modules/mongodb';
import { Server } from 'socket.io';
import { protect, AuthRequest } from '../middleware/auth';
import EmergencyEvent from '../models/EmergencyEvent';
import Notification from '../models/Notification';
import AudioSnippet from '../models/AudioSnippet';
import { resolveEmergencyEvent, triggerEmergencyAlert } from '../services/alertService';

const router = Router();
router.use(protect);

router.get('/', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { status } = req.query;
    const filter: Record<string, unknown> = {
      userId: new mongoose.Types.ObjectId(req.user!.userId),
    };
    if (status) filter.status = status;

    const events = await EmergencyEvent.find(filter)
      .sort({ startTime: -1 })
      .select('-locationPath')
      .lean();

    res.status(200).json({ success: true, data: { events, count: events.length } });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.get('/squad/received', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const notifications = await Notification.find({
      recipientId: new mongoose.Types.ObjectId(req.user!.userId),
    })
      .sort({ sentAt: -1 })
      .populate({
        path: 'eventId',
        select: 'status triggerType startTime resolvedTime aiConfidence locationSnapshot notificationSummary',
        populate: { path: 'userId', select: 'name email' },
      })
      .populate('senderId', 'name email')
      .lean();

    res.status(200).json({ success: true, data: { notifications, count: notifications.length } });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.post('/trigger', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { idempotencyKey, triggerType, lat, lng } = req.body;

    if (!idempotencyKey || !triggerType || lat === undefined || lng === undefined) {
      res.status(400).json({
        success: false,
        message: 'idempotencyKey, triggerType, lat, lng are required',
      });
      return;
    }

    if (!['keyword', 'scream', 'manual', 'shake'].includes(triggerType)) {
      res.status(400).json({ success: false, message: 'Invalid triggerType' });
      return;
    }

    const latitude = Number(lat);
    const longitude = Number(lng);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
      res.status(400).json({ success: false, message: 'lat and lng must be valid numbers' });
      return;
    }

    const io = req.app.get('io') as Server;
    const result = await triggerEmergencyAlert({
      userId: req.user!.userId,
      idempotencyKey,
      triggerType,
      aiConfidence: triggerType === 'manual' ? 1 : 0.95,
      stressScore: triggerType === 'manual' ? 100 : 90,
      initialLat: latitude,
      initialLng: longitude,
      io,
    });

    res.status(result.wasIdempotentDuplicate ? 200 : 201).json({
      success: true,
      message: result.squadAlertedCount > 0
        ? `Alert sent to ${result.squadAlertedCount} squad member(s)`
        : 'Alert created but no squad members configured',
      data: result,
    });
  } catch (error) {
    console.error('Alert trigger error:', error);
    res.status(500).json({ success: false, message: 'Server error during alert trigger' });
  }
});

router.get('/:id', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id as string)) {
      res.status(400).json({ success: false, message: 'Invalid event ID' });
      return;
    }

    const event = await EmergencyEvent.findById(id)
      .populate('squadNotified', 'name email')
      .lean();

    if (!event) { res.status(404).json({ success: false, message: 'Event not found' }); return; }
    if (event.userId.toString() !== req.user!.userId) {
      res.status(403).json({ success: false, message: 'Access denied' });
      return;
    }

    const notifications = await Notification.find({ eventId: id })
      .populate('recipientId', 'name email')
      .select('recipientId sentAt acknowledged acknowledgedAt deliveryStatus retryCount channel')
      .lean();

    res.status(200).json({ success: true, data: { event, notifications } });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.get('/:id/location', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id as string)) {
      res.status(400).json({ success: false, message: 'Invalid event ID' });
      return;
    }

    const event = await EmergencyEvent.findById(id)
      .select('userId locationPath locationSnapshot startTime resolvedTime status')
      .lean();

    if (!event) { res.status(404).json({ success: false, message: 'Event not found' }); return; }
    if (event.userId.toString() !== req.user!.userId) {
      res.status(403).json({ success: false, message: 'Access denied' });
      return;
    }

    res.status(200).json({
      success: true,
      data: {
        eventId: id,
        status: event.status,
        locationSnapshot: event.locationSnapshot,
        locationPath: event.locationPath,
        pointCount: event.locationPath.length,
        startTime: event.startTime,
        resolvedTime: event.resolvedTime,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

router.post('/:id/cancel', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id as string)) {
      res.status(400).json({ success: false, message: 'Invalid event ID' });
      return;
    }

    const event = await EmergencyEvent.findById(id).select('userId');
    if (!event) { res.status(404).json({ success: false, message: 'Event not found' }); return; }
    if (event.userId.toString() !== req.user!.userId) {
      res.status(403).json({ success: false, message: 'Access denied' });
      return;
    }

    const status = ['resolved', 'canceled', 'false_alarm'].includes(reason)
      ? reason
      : 'false_alarm';
    const io = req.app.get('io') as Server;
    await resolveEmergencyEvent(id as string, req.user!.userId, io, status);

    res.status(200).json({
      success: true,
      message: 'Alert cancellation sent',
      data: { eventId: id, status },
    });
  } catch (error) {
    console.error('Alert cancel error:', error);
    res.status(500).json({ success: false, message: 'Server error during alert cancellation' });
  }
});

router.post('/sync', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { idempotencyKey, triggerType, lat, lng, timestamp, audioBase64 } = req.body;

    if (!idempotencyKey || !triggerType || lat === undefined || lng === undefined) {
      res.status(400).json({ success: false, message: 'idempotencyKey, triggerType, lat, lng are required' });
      return;
    }

    const existing = await EmergencyEvent.findOne({ idempotencyKey });
    if (existing) {
      res.status(200).json({
        success: true,
        message: 'Event already processed (idempotent)',
        data: { event: existing, wasAlreadyProcessed: true },
      });
      return;
    }

    const event = await EmergencyEvent.create({
      userId: new mongoose.Types.ObjectId(req.user!.userId),
      idempotencyKey,
      status: 'created',
      triggerType,
      startTime: timestamp ? new Date(timestamp) : new Date(),
      locationSnapshot: { lat, lng, timestamp: new Date() },
      locationPath: [{ lat, lng, timestamp: new Date() }],
      squadNotified: [],
      notificationSummary: { total: 0, sent: 0, failed: 0 },
    });

    res.status(201).json({
      success: true,
      message: 'Queued event synced successfully',
      data: { event, wasAlreadyProcessed: false },
    });
  } catch (error) {
    console.error('Offline sync error:', error);
    res.status(500).json({ success: false, message: 'Server error during sync' });
  }
});

router.post('/:id/audio-chunk', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const { audioBase64, chunkIndex, durationSeconds } = req.body;

    if (!mongoose.Types.ObjectId.isValid(id as string)) {
      res.status(400).json({ success: false, message: 'Invalid event ID' });
      return;
    }
    if (!audioBase64) { res.status(400).json({ success: false, message: 'audioBase64 is required' }); return; }
    if (chunkIndex === undefined) { res.status(400).json({ success: false, message: 'chunkIndex is required' }); return; }

    const event = await EmergencyEvent.findById(id);
    if (!event) { res.status(404).json({ success: false, message: 'Event not found' }); return; }
    if (event.userId.toString() !== req.user!.userId) { res.status(403).json({ success: false, message: 'Access denied' }); return; }
    if (event.status !== 'active' && event.status !== 'notifying' && event.status !== 'notification_partial_failure') {
      res.status(400).json({ success: false, message: `Cannot upload audio for a ${event.status} event` });
      return;
    }

    let audioBuffer: Buffer;
    try {
      audioBuffer = Buffer.from(audioBase64, 'base64');
    } catch {
      res.status(400).json({ success: false, message: 'Invalid base64 audio data' });
      return;
    }

    const db = mongoose.connection.db;
    if (!db) { res.status(500).json({ success: false, message: 'DB not ready' }); return; }

    const bucket = new GridFSBucket(db as any, { bucketName: 'evidence_audio' });
    const filename = `evidence_${id}_chunk${chunkIndex}_${Date.now()}.wav`;

    const uploadStream = bucket.openUploadStream(filename, {
      metadata: { eventId: id, userId: req.user!.userId, chunkIndex, uploadedAt: new Date() },
    });

    const fileId = await new Promise<mongoose.Types.ObjectId>((resolve, reject) => {
      uploadStream.on('finish', () => resolve(uploadStream.id as mongoose.Types.ObjectId));
      uploadStream.on('error', reject);
      uploadStream.end(audioBuffer);
    });

    const snippet = await AudioSnippet.create({
      eventId: new mongoose.Types.ObjectId(id as string),
      userId: new mongoose.Types.ObjectId(req.user!.userId),
      gridFsFileId: fileId,
      purpose: 'evidence_recording',
      durationSeconds: durationSeconds || 0,
      fileSizeBytes: audioBuffer.length,
      chunkIndex,
    });

    if (chunkIndex === 0) {
      await EmergencyEvent.findByIdAndUpdate(id, { audioFileId: fileId });
    }

    console.log(`    Evidence audio stored: ${filename} (${(audioBuffer.length / 1024).toFixed(1)} KB)`);

    res.status(201).json({
      success: true,
      message: 'Audio chunk stored successfully',
      data: {
        fileId: fileId.toString(),
        snippetId: snippet._id.toString(),
        filename,
        chunkIndex,
        sizeBytes: audioBuffer.length,
        retentionExpiresAt: snippet.retentionExpiresAt,
      },
    });
  } catch (error) {
    console.error('Audio chunk upload error:', error);
    res.status(500).json({ success: false, message: 'Failed to store audio chunk' });
  }
});

router.get('/:id/audio-chunks', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id as string)) {
      res.status(400).json({ success: false, message: 'Invalid event ID' });
      return;
    }

    const event = await EmergencyEvent.findById(id).select('userId');
    if (!event) { res.status(404).json({ success: false, message: 'Event not found' }); return; }
    if (event.userId.toString() !== req.user!.userId) { res.status(403).json({ success: false, message: 'Access denied' }); return; }

    const snippets = await AudioSnippet.find({
      eventId: new mongoose.Types.ObjectId(id as string),
      status: 'active',
    }).sort({ chunkIndex: 1 }).lean();

    res.status(200).json({
      success: true,
      data: {
        eventId: id,
        chunks: snippets.map(s => ({
          snippetId: s._id,
          fileId: s.gridFsFileId,
          chunkIndex: s.chunkIndex,
          durationSeconds: s.durationSeconds,
          sizeBytes: s.fileSizeBytes,
          retentionExpiresAt: s.retentionExpiresAt,
          createdAt: s.createdAt,
        })),
        totalChunks: snippets.length,
        totalDurationMinutes: (snippets.reduce((s, c) => s + c.durationSeconds, 0) / 60).toFixed(1),
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

export default router;
