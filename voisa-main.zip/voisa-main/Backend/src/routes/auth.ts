import { Request, Response, Router } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import PendingRegistration, { IPendingRegistration } from '../models/PendingRegistration';
import User from '../models/User';
import {
  compareVerificationCode,
  generateVerificationCode,
  hashVerificationCode,
  sendVerificationEmail,
  verificationExpiry,
} from '../services/emailVerificationService';

const router = Router();

const generateToken = (userId: string): string => {
  const secret = process.env.JWT_SECRET!;
  const expiresIn = process.env.JWT_EXPIRES_IN || '7d';

  return jwt.sign({ userId }, secret, { expiresIn } as jwt.SignOptions);
};

const createAndSendVerificationCode = async ({
  email,
  name,
  passwordHash,
}: {
  email: string;
  name: string;
  passwordHash: string;
}): Promise<IPendingRegistration> => {
  const code = generateVerificationCode();
  const pending = await PendingRegistration.findOneAndUpdate(
    { email: email.toLowerCase() },
    {
      name,
      email: email.toLowerCase(),
      passwordHash,
      verificationCodeHash: await hashVerificationCode(code),
      verificationExpiresAt: verificationExpiry(),
    },
    { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
  );

  await sendVerificationEmail(email, code);
  return pending;
};

const userResponse = (user: any) => ({
  _id: user._id,
  name: user.name,
  email: user.email,
  squad: user.squad,
  isActive: user.isActive,
  isEmailVerified: user.isEmailVerified,
  createdAt: user.createdAt,
});

router.post('/register', async (req: Request, res: Response): Promise<void> => {
  try {
    const { name, email, password } = req.body;

    // ── Validate input ────────────────────────────────────────────────────────
    if (!name || !email || !password) {
      res.status(400).json({
        success: false,
        message: 'Please provide name, email, and password',
      });
      return;
    }

    if (password.length < 8) {
      res.status(400).json({
        success: false,
        message: 'Password must be at least 8 characters',
      });
      return;
    }

    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      res.status(409).json({
        success: false,
        message: 'An account with this email already exists',
      });
      return;
    }

    await createAndSendVerificationCode({
      name,
      email,
      passwordHash: await bcrypt.hash(password, 12),
    });

    res.status(202).json({
      success: true,
      message: 'Verification code sent. Complete verification to create your account.',
      data: { requiresVerification: true, email: email.toLowerCase() },
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during registration',
    });
  }
});

router.post('/login', async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({
        success: false,
        message: 'Please provide email and password',
      });
      return;
    }

    const user = await User.findOne({ email: email.toLowerCase() }).select(
      '+passwordHash'
    );

    if (!user) {
      const pending = await PendingRegistration.findOne({
        email: email.toLowerCase(),
      });

      if (pending) {
        const isPendingPasswordCorrect = await bcrypt.compare(
          password,
          pending.passwordHash
        );

        if (isPendingPasswordCorrect) {
          await createAndSendVerificationCode({
            email: pending.email,
            name: pending.name,
            passwordHash: pending.passwordHash,
          });
          res.status(403).json({
            success: false,
            message: 'Please verify your email. A new code was sent.',
            data: { requiresVerification: true, email: pending.email },
          });
          return;
        }
      }

      res.status(401).json({
        success: false,
        message: 'Invalid email or password',
      });
      return;
    }

    const isPasswordCorrect = await user.comparePassword(password);

    if (!isPasswordCorrect) {
      res.status(401).json({
        success: false,
        message: 'Invalid email or password',
      });
      return;
    }

    const token = generateToken(user._id.toString());

    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        user: userResponse(user),
        token,
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during login',
    });
  }
});

router.post('/verify-email', async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, code } = req.body;

    if (!email || !code) {
      res.status(400).json({ success: false, message: 'Email and code are required' });
      return;
    }

    if (!/^\d{6}$/.test(code)) {
      res.status(400).json({ success: false, message: 'Code must be 6 digits' });
      return;
    }

    const existingUser = await User.findOne({ email: email.toLowerCase() });
    if (existingUser) {
      res.status(200).json({
        success: true,
        message: 'Email is already verified',
        data: { user: userResponse(existingUser), token: generateToken(existingUser._id.toString()) },
      });
      return;
    }

    const pending = await PendingRegistration.findOne({
      email: email.toLowerCase(),
    });

    if (!pending) {
      res.status(404).json({ success: false, message: 'No pending registration found. Please sign up again.' });
      return;
    }

    if (pending.verificationExpiresAt.getTime() < Date.now()) {
      res.status(400).json({ success: false, message: 'Verification code expired. Please resend a code.' });
      return;
    }

    const isCodeCorrect = await compareVerificationCode(
      code,
      pending.verificationCodeHash
    );

    if (!isCodeCorrect) {
      res.status(400).json({ success: false, message: 'Invalid verification code' });
      return;
    }

    const user = await User.create({
      name: pending.name,
      email: pending.email,
      passwordHash: pending.passwordHash,
      isEmailVerified: true,
    });

    await PendingRegistration.deleteOne({ _id: pending._id });

    res.status(200).json({
      success: true,
      message: 'Email verified successfully',
      data: { user: userResponse(user), token: generateToken(user._id.toString()) },
    });
  } catch (error) {
    console.error('Email verification error:', error);
    res.status(500).json({ success: false, message: 'Server error during email verification' });
  }
});

router.post('/resend-verification-code', async (req: Request, res: Response): Promise<void> => {
  try {
    const { email } = req.body;

    if (!email) {
      res.status(400).json({ success: false, message: 'Email is required' });
      return;
    }

    const user = await User.findOne({ email: email.toLowerCase() });
    if (user) {
      res.status(200).json({ success: true, message: 'Email is already verified' });
      return;
    }

    const pending = await PendingRegistration.findOne({
      email: email.toLowerCase(),
    });

    if (!pending) {
      res.status(404).json({ success: false, message: 'No pending registration found. Please sign up again.' });
      return;
    }

    await createAndSendVerificationCode({
      email: pending.email,
      name: pending.name,
      passwordHash: pending.passwordHash,
    });

    res.status(200).json({
      success: true,
      message: 'Verification code resent',
    });
  } catch (error) {
    console.error('Resend verification error:', error);
    res.status(500).json({ success: false, message: 'Server error while resending verification code' });
  }
});

export default router;
