from helpme_detector import HelpMeDetector
from http.server import HTTPServer, BaseHTTPRequestHandler
import threading
import json

ACCESS_KEY = "4Fkb/lEgOXsTlQNHXUBChCKa23t+ACHTO7gtwkUYS415CyRQ7bw+Kg=="
KEYWORD_PATH = r"help_me.ppn"

detector = HelpMeDetector(
    access_key=ACCESS_KEY,
    keyword_path=KEYWORD_PATH,
    device_index=1,
    sensitivity=0.9
)

detector.start()
print("Listening for 'help me'...")

class Handler(BaseHTTPRequestHandler):

    def do_GET(self):
        if self.path == '/status':
            triggered = detector.triggered
            if triggered:
                detector.reset()   # auto-reset after Flutter reads it
            body = json.dumps({"triggered": triggered}).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    # Silence the default request logs
    def log_message(self, format, *args):
        pass

server = HTTPServer(('0.0.0.0', 8888), Handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
print("HTTP server on http://0.0.0.0:8888/status")

import time
while True:
    if detector.triggered:
        print("HELP ME DETECTED!")
        detector.reset()
    time.sleep(0.1)