import queue
import numpy as np
import sounddevice as sd
import pvporcupine
import threading


class HelpMeDetector:

    def __init__(self, access_key, keyword_path, device_index=None, sensitivity=0.6):

        self.porcupine = pvporcupine.create(
            access_key=access_key,
            keyword_paths=[keyword_path],
            sensitivities=[sensitivity],
        )

        self.device_index = device_index
        dev = sd.query_devices(device_index)

        self.mic_sr = int(dev["default_samplerate"])
        self.blocksize = int(self.mic_sr * 0.05)

        self.q = queue.Queue()
        self.acc16 = np.zeros((0,), dtype=np.int16)

        self.frame_len = self.porcupine.frame_length
        self.target_sr = self.porcupine.sample_rate

        self.stream = None

        # NEW
        self.running = False
        self.triggered = False


    def _resample(self, x, src_sr, dst_sr):

        if src_sr == dst_sr:
            return x

        n_src = len(x)
        n_dst = int(round(n_src * dst_sr / src_sr))

        src_idx = np.linspace(0, n_src - 1, num=n_dst)

        x0 = np.floor(src_idx).astype(int)
        x1 = np.minimum(x0 + 1, n_src - 1)

        w = src_idx - x0

        return (1 - w) * x[x0] + w * x[x1]


    def _audio_callback(self, indata, frames, time_info, status):

        self.q.put(indata.copy())


    def start(self):

        self.running = True

        self.stream = sd.InputStream(
            device=self.device_index,
            channels=1,
            samplerate=self.mic_sr,
            blocksize=self.blocksize,
            dtype="int16",
            callback=self._audio_callback,
        )

        self.stream.start()

        # start detection thread
        threading.Thread(target=self._detect_loop, daemon=True).start()


    def _detect_loop(self):

        while self.running:

            chunk = self.q.get()[:, 0]

            x = chunk.astype(np.float32) / 32768.0

            y = self._resample(x, self.mic_sr, self.target_sr)

            y16 = np.clip(y * 32768, -32768, 32767).astype(np.int16)

            self.acc16 = np.concatenate([self.acc16, y16])

            while self.acc16.shape[0] >= self.frame_len:

                frame = self.acc16[:self.frame_len]
                self.acc16 = self.acc16[self.frame_len:]

                if self.porcupine.process(frame) >= 0:
                    self.triggered = True


    def reset(self):
        self.triggered = False


    def stop(self):

        self.running = False

        if self.stream:
            self.stream.stop()
            self.stream.close()

        self.porcupine.delete()