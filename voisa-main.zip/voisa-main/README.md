# Voisa Emergency App

Voisa is a graduation project focused on emergency safety and rapid response.

## Project Goal
The application helps users in dangerous situations through:
- SOS emergency activation
- emergency contact communication
- live location support
- AI-assisted distress detection

## Team Roles
- Frontend / UI-UX / Flutter: Mohammed
- AI Model Engineer: [Name]
- Backend Developer: [Name]
- Database Architect: [Name]

## Project Structure
- `mobile_app/` Flutter mobile application
- `backend/` backend services and APIs
- `ai_prototypes/` AI and detection prototypes
- `docs/` shared documentation

## Current Status
- Frontend MVP is implemented
- Initial UI screens are ready
- Next phase is backend, database, and AI integration

## Setup
### Mobile App
```bash
cd mobile_app
flutter pub get
flutter run
