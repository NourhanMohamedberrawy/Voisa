# Integration Contract

## Home Screen Data

The frontend currently needs:

### User

- `id`
- `name`
- `profileImageUrl`

### Active Alert

- `alertId`
- `contactName`
- `contactRelation`
- `status`
- `voiceClipUrl`
- `locationLatitude`
- `locationLongitude`
- `timestamp`

### Emergency Contacts

- `contactId`
- `name`
- `phone`
- `relation`
- `photoUrl`

## SOS Event

When SOS is triggered, the system should support:

- creating an alert
- notifying emergency contacts
- storing alert history
- optionally attaching voice/audio context
- optionally attaching location data

## AI Distress Detection Output

The AI module should eventually provide something like:

- `detected`: true/false
- `source`: voice/manual/model
- `confidence`: number
- `timestamp`
- `triggerPhrase`: optional
