# Setup Guide

## Frontend

```bash
cd mobile_app
flutter pub get
flutter run
```

For a physical iPhone, point the app at your computer's LAN IP instead of
`localhost`:

```bash
flutter run \
  --dart-define=VOISA_API_BASE_URL=http://YOUR_MAC_LAN_IP:3000 \
  --dart-define=VOISA_DETECTOR_BASE_URL=http://YOUR_MAC_LAN_IP:8888
```

## Backend Email Verification

Signup creates a 6-digit email verification code. To send it by email, add SMTP
settings to `Backend/.env`:

```env
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=your_smtp_username
SMTP_PASS=your_smtp_password
SMTP_FROM="Voisa <no-reply@example.com>"
```

If these variables are missing, the backend logs the verification code to the
terminal so local development can still continue.
