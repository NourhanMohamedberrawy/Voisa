# Team Workflow

## Branching Rule

Do not work directly on `main`.

Each team member creates their own branch:

- `feature/frontend-home-polish`
- `feature/backend-sos-api`
- `feature/database-schema`
- `feature/ai-distress-trigger`

## Merge Rule

Before merging to `main`:

1. push your branch
2. open a pull request
3. let at least one teammate review if possible
4. merge only after checking it does not break the project

## Communication Rule

If you change:

- shared models
- API response structure
- database fields
- AI output format

you must update the docs and tell the team.

## Main Principle

No silent breaking changes.
